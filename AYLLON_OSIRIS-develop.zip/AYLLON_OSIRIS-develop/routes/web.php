<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\StudyController;
use App\Http\Controllers\TaskController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Traits\LangHelper;
use App\Http\Controllers\LegalNoticeController;
use App\Http\Controllers\WorkspaceController;
use App\Http\Controllers\UploadController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\SidebarController;
use App\Http\Controllers\PeopleController;
use App\Http\Controllers\CookieController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\DiaryEntryController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\IaController;

/*****************************************************
 *  HOW TO SETUP ROUTES WITH THE LANGHELPER TRAIT    *
 *  --- - -- -- -- -- -- -- -- -- -- -- -- - ---     *
 * First call the localeHandler() function to check  *
 * if the locale passed by the route is available    *
 * and then set the Locale in case it changed.       *
 *                                                   *
 * Then pass the translations as a prop to Vue using *
 * the getTranslation() function, give it the file   *
 * name of the translations file you want.           *
 *                                                   *
 * Lastly on the view add {{translations.x}} to set  *
 * the translation you want to use in each tag that  *
 * uses text.                                        *
 *****************************************************/

//PUBLIC
Route::get('/{locale?}', [\App\Http\Controllers\HomeController::class, 'index'])->where('locale', '[a-z]{2}')->name('home');
Route::get('/contact/{locale?}', [ContactController::class, 'showContact'])->where('locale', '[a-z]{2}')->name('contact');
Route::post('/addContact', [ContactController::class, 'index'])->name("addContact");
Route::get('/about/{locale?}', [AboutController::class, 'index'])->where('locale', '[a-z]{2}')->name('about');
Route::get('/cookie/{locale?}', [CookieController::class, 'index'])->where('locale', '[a-z]{2}')->name('cookie');
Route::get('/terms/{locale?}', [LegalNoticeController::class, 'index'])->where('locale', '[a-z]{2}')->name('terms');

//LANGUAGE CHANGE
Route::post('/lang_change', [LangHelper::class, 'change'])->name('lang_change');

//DASHBOARD
Route::get('/dashboard/{locale?}', [DashboardController::class, 'index'])->middleware(['auth'])->name('dashboard');

    //CONTACTS
Route::get('/people/{locale?}', [PeopleController::class, 'index'])->middleware(['auth', 'verified'])->where('locale', '[a-z]{2}')->name('people');
Route::post('/people2', [PeopleController::class, 'peopleform'])->middleware(['auth', 'verified'])->where('locale', '[a-z]{2}')->name('people.store');
Route::delete('/people/delete/{id}', [PeopleController::class, 'destroypeople'])->name('people.destroypeople');

    //STUDY
Route::get('/study/{locale?}', [StudyController::class, 'index'])->middleware(["auth"])->where('locale', '[a-z]{2}')->name("study");

    //DIARY
Route::get('/diary/{locale?}', [DiaryEntryController::class, 'index'])->middleware(["auth"])->where('locale', '[a-z]{2}')->name('diary');
Route::get('/diary', [DiaryEntryController::class, 'diary'])->middleware(["auth"])->name('diary');
Route::post('/diary', [DiaryEntryController::class, 'store'])->middleware(['auth'])->name('diary.store');
Route::get('/diary/entries', [DiaryEntryController::class, 'getEntries'])->middleware(["auth"])->name('diary.entries');
Route::delete('/diary/delete/{id}', [DiaryEntryController::class, 'destroy'])->name('diary.delete');
Route::get('/diary/{id}/{locale?}', [DiaryEntryController::class, 'show'])->where('locale', '[a-z]{2}')->name('diary.show');
Route::put('/diary/{id}', [DiaryEntryController::class, 'update'])->name('diary.update');

    //TASKS
Route::get('/tasks/{locale?}', [TaskController::class, 'showTasks'])->where('locale', '[a-z]{2}')->name('tasks.index');
Route::get('/tasks/create/{locale?}', [TaskController::class, 'showCreateForm'])->where('locale', '[a-z]{2}')->name('tasks.create');
Route::post('/tasks/{locale?}', [TaskController::class, 'store'])->where('locale', '[a-z]{2}')->name('tasks.store');
Route::get('/tasks/{task}', [TaskController::class, 'destroy'])->name('tasks.destroy');
Route::get('/getTasks', [TaskController::class, 'getTasks'])->name('tasks.getTasks');

//IA
Route::get('/IA', [IaController::class, 'index']);
Route::post('/generar-texto', [IaController::class, 'generarTexto']);

    //WORKSPACE
Route::get('/workspace/{locale?}', [WorkspaceController::class, 'index'])->middleware(['auth'])->where('locale', '[a-z]{2}')->name('workspace');
Route::get('/upload/{locale?}', [UploadController::class, 'index'])->middleware(['auth'])->where('locale', '[a-z]{2}')->name('upload');
Route::post('/upload', [UploadController::class, 'file'])->middleware(['auth', 'verified'])->where('locale', '[a-z]{2}')->name('upload.file');
Route::get('/pdf/{documentName}', [WorkspaceController::class, 'showPdf'])->middleware(['auth', 'verified'])->name('pdf');
Route::post('/searchfile', [WorkspaceController::class, 'searchPdf'])->middleware(['auth'])->name('search.pdfs');
Route::delete('/deletefile/{documentName}', [WorkspaceController::class, 'deletePDF'])->middleware(['auth', 'verified'])->name('deletefile');
Route::get('/allFiles', [WorkspaceController::class, 'getPDFS'])->middleware(['auth', 'verified'])->name('allFiles');

//PROFILE
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});
Route::post('/profile', [ProfileController::class, 'update'])->middleware(["auth"])->name('profile.update');
Route::get('/register/{locale?}', [RegisteredUserController::class, 'create'])->where('locale', '[a-z]{2}')->name('register');
Route::post('/register', [RegisteredUserController::class, 'store'])->name('adduser');;
Route::get('/login/{locale?}', [AuthenticatedSessionController::class, 'create'])->where('locale', '[a-z]{2}')->name('login');
Route::post('/generate', [RegisteredUserController::class, 'generate'])->middleware(['auth', App\Http\Middleware\Admin::class])->name('generate');
Route::post('/deleteuser', [RegisteredUserController::class, 'delete'])->middleware(['auth', App\Http\Middleware\Admin::class])->name('deleteuser');
//ASYNC ACCESSES TO DATA
    //USERS LIST
Route::get('/usersall', function () { return \App\Models\User::all()->toJson(); })->middleware(['auth', App\Http\Middleware\Admin::class])->name('usersall');
    //CONTACT LIST
Route::get('/loadContacts', [ContactController::class, "loadContacts"])->middleware(['auth', App\Http\Middleware\Admin::class])->name('loadContacts');
    //DELETE MESSAGE
Route::post('/deleteMessage', [ContactController::class, 'delete'])->middleware(['auth', App\Http\Middleware\Admin::class])->name('deleteMessage');
//Route::get('/usersmanage/{managerID}', function (int $managerID) {/*THIS MUST RETURN ALL USERS THAT A MANAGER HAS*/})->middleware(['auth', App\Http\Middleware\Manager::class])->name('usersmanage');

    //DATA NUMBERS ADMIN
    Route::post('/stats', [\App\Http\Controllers\ApiController::class, 'stats'])->middleware(['auth', App\Http\Middleware\Admin::class])->name('stats');
    //DATA NUMBERS MANAGER

    //INCREMENT STUDIES
    Route::get('/incrementstudies', [\App\Http\Controllers\StudyController::class, 'incrementStudied'])->middleware(['auth'])->name('incrementstudies');
//ADMIN
Route::get('/admin', [AdminController::class, 'index'])->middleware(["auth", App\Http\Middleware\Admin::class])->name('admin');
Route::get('/admin/translations/{locale?}', [AdminController::class, 'translations'])->where('locale', '[a-z]{2}')->middleware(["auth", App\Http\Middleware\Admin::class])->name('admin.translations');
Route::post('/admin/translations/save', [AdminController::class, 'saveTranslations'])->middleware(['auth', App\Http\Middleware\Admin::class])->name('admin.translations.save');

require __DIR__ . '/auth.php';
