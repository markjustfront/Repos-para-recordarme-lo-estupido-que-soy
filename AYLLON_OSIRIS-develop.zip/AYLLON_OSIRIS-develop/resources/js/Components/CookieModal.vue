<template>
  <div v-if="showCookiePopup" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
    <div class="bg-white p-6 rounded shadow-lg w-full md:w-1/2 lg:w-1/3 mx-4">
      <h2 class="text-xl font-bold mb-4">{{ translations.cookies_title }}</h2>
      <p class="mb-4 text-justify">
        {{ translations.cookies_text }}
        <br>
        <a @click="redirectToCookiesPage" class="text-blue-500 underline">{{ translations.more_info }}</a>
      </p>
      <div class="flex justify-end">
        <button @click="acceptCookies" class="flex items-center bg-mark text-black px-4 py-2 rounded mr-2">{{ translations.accept }}</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';

const showCookiePopup = ref(false);

onMounted(() => {
    const cookiesAccepted = localStorage.getItem('cookiesAccepted');
    if (!cookiesAccepted) {
        showCookiePopup.value = true;
    }
});

const acceptCookies = () => {
    localStorage.setItem('cookiesAccepted', 'true');
    showCookiePopup.value = false;
};

const redirectToCookiesPage = () => {
    showCookiePopup.value = false;
    window.location.href = route('cookie');
};

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});
</script>