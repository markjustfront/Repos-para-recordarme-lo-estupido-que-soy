<script setup>
import { ref, computed } from 'vue';
import axios from 'axios';
import { marked } from 'marked';

const props = defineProps({
    translations: {
        required: true,
        type: Object,
    },
});

const modalOpen = ref(false);
const texto = ref('');
const cargando = ref(false);
const respuesta = ref('');

const generarTexto = async (tipo) => {
    if (!texto.value.trim()) {
        alert('Escribe un texto primero');
        return;
    }

    cargando.value = true;
    respuesta.value = '';

    try {
        const response = await axios.post('/generar-texto', {
            texto: texto.value,
            tipo: tipo,
        });

        if (response.data.error) {
            respuesta.value = response.data.error;
        } else {
            respuesta.value = response.data.respuesta || 'No hay respuesta';
        }
    } catch (error) {
        respuesta.value = 'Error al generar el texto.';
    } finally {
        cargando.value = false;
    }
};

// Property for change the widht of the modal
const modalWidth = computed(() => {
    return respuesta.value.length > 300 ? 'w-[40rem]' : 'w-96';
});
</script>

<template>
    <div>
        <button
            @click="modalOpen = true"
            class="ai-button z-50 transition duration-300"
            :class="{ hidden: modalOpen }"
        >
            <img
                src="../../../public/images/image-removebg-preview-removebg-preview.png"
                alt="AI Button"
            />
        </button>

        <div
            v-if="modalOpen"
            class="fixed inset-0 z-[9999] flex items-center justify-center bg-black bg-opacity-50"
        >
            <div
                :class="[
                    'modal-content relative z-[10000] rounded-lg bg-white p-6 shadow-lg',
                    modalWidth,
                ]"
            >
                <button
                    @click="modalOpen = false"
                    class="absolute right-2 top-2 text-gray-500 transition hover:text-gray-800"
                >
                    <i class="fas fa-times"></i>
                </button>

                <h2 class="mb-4 text-center text-lg font-bold text-gray-800">
                    {{translations.ai_whatis}}
                </h2>

                <textarea
                    v-model="texto"
                    class="w-full rounded border p-2 focus:ring focus:ring-blue-300"
                    rows="4"
                    :placeholder="translations.ai_writehere"
                ></textarea>

                <div class="mt-4 flex justify-center gap-4">
                    <button
                        @click="generarTexto('resumen')"
                        class="rounded bg-primary px-4 py-2 text-white transition"
                    >
                        {{translations.ai_short}}
                    </button>
                    <button
                        @click="generarTexto('plan_estudio')"
                        class="rounded bg-mark px-4 py-2 text-black transition"
                    >
                        {{translations.ai_studyplan}}
                    </button>
                </div>

                <div v-if="cargando" class="mt-4 text-center text-gray-500">
                    {{translations.ai_generating}}
                </div>

                <div
                    v-if="respuesta"
                    class="mt-4 rounded border bg-gray-50 p-3 text-center"
                >
                    <strong>{{translations.ai_response}}</strong>
                    <p class="mt-2" v-html="marked(respuesta)"></p>
                </div>

                <div v-if="respuesta" class="mt-4 flex justify-center">
                    <button
                        @click="modalOpen = false"
                        class="rounded bg-red-500 px-4 py-2 text-white"
                    >
                        {{translations.ai_close}}
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>
