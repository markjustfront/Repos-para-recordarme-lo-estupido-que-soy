<script setup>
import { onMounted, ref } from 'vue';

const model = defineModel({
    type: String,
    required: true,
});

const input = ref(null);

onMounted(() => {
    if (input.value.hasAttribute('autofocus')) {
        input.value.focus();
    }
});

defineExpose({ focus: () => input.value.focus() });
</script>

<template>
    <input
        class="rounded-md border-gray-300 shadow-sm focus:border-mark focus:ring-mark dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:focus:border-mark dark:focus:ring-mark"
        v-model="model"
        ref="input"
    />
</template>
