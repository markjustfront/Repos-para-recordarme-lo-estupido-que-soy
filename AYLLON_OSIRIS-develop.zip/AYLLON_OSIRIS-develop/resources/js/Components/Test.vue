<template>
    <div>
      <h1>Osiris</h1>
    </div>
</template>
