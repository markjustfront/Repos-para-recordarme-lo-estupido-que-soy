<script setup>
const props = defineProps({
    bgColor: {
        type: String,
        required: true,
    },
    textColor: {
        type: String,
        required: true,
    },
    title: {
        type: String,
        required: true,
    },
    number: {
        type: Number,
        required: true,
    },
});
</script>

<template>
    <div
        class="mx-auto max-h-36 min-h-36 w-full rounded-md p-4 shadow-md"
        v-bind:class="props.bgColor + ' ' + props.textColor"
    >
        <h3 class="text-left font-headers text-lg md:text-2xl">{{ props.title }}</h3>
        <p class="text-right font-headers text-xl md:text-6xl">{{ props.number }}</p>
    </div>
</template>
