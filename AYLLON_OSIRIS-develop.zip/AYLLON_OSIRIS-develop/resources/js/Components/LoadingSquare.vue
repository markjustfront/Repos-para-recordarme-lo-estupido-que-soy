<script setup>

</script>

<template>
    <div class="min-h-14 min-w-14 max-h-14 max-w-14 rounded-sm bg-mark load-animation my-auto mx-auto"></div>
</template>
