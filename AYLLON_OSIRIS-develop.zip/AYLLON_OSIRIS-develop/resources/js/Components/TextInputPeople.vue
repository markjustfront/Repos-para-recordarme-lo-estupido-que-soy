<script setup>
import { onMounted, ref } from 'vue';

const model = defineModel({
    type: String,
    required: true,
});

const input = ref(null);

onMounted(() => {
    if (input.value.hasAttribute('autofocus')) {
        input.value.focus();
    }
});

defineExpose({ focus: () => input.value.focus() });
</script>

<template>
    
    <input
       class="bg-gray-50 border border-gray-300 text-black-900 text-sm rounded-lg 
       focus:ring-blue-500 focus:border-blue-500 block w-60 inline-flex 
         "
        v-model="model"
        ref="input"
        
    />

    <!-- <input
       class="bg-gray-50 border border-gray-300 text-black-900 text-sm rounded-lg 
       focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:border-gray-600 
       dark:placeholder-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500 "
        v-model="model"
        ref="input"
        
    /> -->
</template>