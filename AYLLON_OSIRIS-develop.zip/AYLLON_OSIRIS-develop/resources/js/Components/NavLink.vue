<script setup>
import { computed } from 'vue';
import { Link } from '@inertiajs/vue3';

const props = defineProps({
    href: {
        type: String,
        required: true,
    },
    active: {
        type: Boolean,
    },
});

const classes = computed(() =>
    props.active
        ? 'inline-flex items-center mx-1 p-3 text-lg md:text-3xl font-headers leading-5 text-white focus:outline-none focus:border-mark transition-shadow duration-300 ease-in-out bg-primary rounded-2xl border-b-2 border-mark drop-shadow-md'
        : 'inline-flex items-center mx-1 p-3 text-lg md:text-3xl font-headers leading-5 text-white focus:outline-none focus:border-mark transition-shadow duration-300 ease-in-out bg-primary rounded-2xl hover:border-b-2 hover:border-mark drop-shadow-md',
);
</script>

<template>
    <Link :href="href" :class="classes">
        <slot />
    </Link>
</template>
