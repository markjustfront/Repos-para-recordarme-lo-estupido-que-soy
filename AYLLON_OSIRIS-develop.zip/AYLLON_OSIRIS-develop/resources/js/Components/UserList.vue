<script setup>
import axios from 'axios';
import { ref } from 'vue';
import LoadingSquare from '@/Components/LoadingSquare.vue';
const props = defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
    userid: {
        type: Number,
        required: true,
    },
});

const users = ref();
let loaded = ref(false);
const getAllUsers = () => {
    axios
        .get('/usersall')
        .then(function (response) {
            users.value = response.data;
            loaded.value = true;
        })
        .catch(function (error) {
            console.log(error);
        });
};

if (props.isAdmin) {
    getAllUsers();
} else {
    axios
        .get('/usersmanage/' + props.userid)
        .then(function (response) {
            users.value = response.data;
        })
        .catch(function (error) {
            console.log(error);
        });
}

const generateUser = () => {
    axios.get('https://randomuser.me/api/').then(function (response) {
        let newUser = {
            firstname: '',
            lastname: '',
            email: '',
            password: '',
        };
        console.log(response.data);
        newUser.firstname = response.data.results[0].name.first;
        newUser.lastname = response.data.results[0].name.last;
        newUser.email = response.data.results[0].email;
        newUser.password = 'TestPassword0101';

        axios
            .post('/generate', {
                firstname: newUser.firstname,
                lastname: newUser.lastname,
                email: newUser.email,
                password: newUser.password,
                password_confirmation: newUser.password,
            })
            .then(function () {
                getAllUsers();
            });
    });
};

function deleteUser(userId) {
    axios
        .post('/deleteuser', {
            userid: userId,
        })
        .then(function () {
            getAllUsers();
        });
};
</script>

<template>
    <div class="mx-auto w-full bg-white p-2">
        <div class="flex flex-row justify-between">
            <h2 class="font-headers text-3xl text-primary">
                {{ translations.users }}
            </h2>
            <button
                v-if="isAdmin"
                @click="generateUser"
                class="rounded-md bg-secondary p-2 text-center text-black transition-colors duration-300 ease-in-out hover:bg-terciary"
            >
                {{ translations.generate }}
            </button>
        </div>
        <div class="mt-2 max-h-52 overflow-y-scroll" v-if="loaded">
            <div
                v-for="user in users"
                class="flex flex-row items-center justify-around border-b border-primary p-2 text-xl"
                v-bind:class="user.id === userid ? 'bg-mark' : ''"
            >
                <p class="min-w-52 max-w-52 break-all">{{ user.firstname }}</p>
                <p class="min-w-52 max-w-52 break-all">{{ user.lastname }}</p>
                <a :href="'mailto:' + user.email" aria-label="email" class="min-w-52 max-w-52 break-all text-sm">{{ user.email }}</a>
                <p
                    v-if="isAdmin && user.role === '0'"
                    class="min-w-52 max-w-52 break-all"
                >
                    {{ translations.admin }}
                </p>
                <p
                    v-if="isAdmin && user.role === '1'"
                    class="min-w-52 max-w-52 break-all"
                >
                    {{ translations.manager }}
                </p>
                <p
                    v-if="isAdmin && user.role === '2'"
                    class="min-w-52 max-w-52 break-all"
                >
                    {{ translations.user }}
                </p>
                <button
                    @click="deleteUser(user.id)"
                    v-if="isAdmin && user.id !== userid"
                    class="rounded-md bg-red-600 p-2 text-white transition-colors duration-300 ease-in-out hover:bg-red-900"
                    aria-label="delete user"
                >
                    <i class="fa fa-trash"></i>
                </button>
            </div>
        </div>
        <div v-if="!loaded" class="w-full min-h-52 flex justify-center align-middle">
            <LoadingSquare></LoadingSquare>
        </div>
    </div>
</template>
