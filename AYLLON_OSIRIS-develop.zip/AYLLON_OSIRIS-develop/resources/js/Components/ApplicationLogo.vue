<template>
    <img src="/detailed-logo.png" alt="imagen logo" class="inset-0 static">
</template>
