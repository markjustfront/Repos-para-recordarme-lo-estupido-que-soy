<script setup>
import axios from 'axios';
import { ref } from 'vue';
import LoadingSquare from '@/Components/LoadingSquare.vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});

const loaded = ref(false);
const contacts = ref();

const getContacts = () => {
    axios.get('/loadContacts').then(function (response) {
        contacts.value = response.data;
        loaded.value = true;
    });
};

function deleteMessage(messageId) {
    axios
        .post('/deleteMessage', {
            id: messageId,
        })
        .then(function () {
            getContacts();
        });
}

getContacts();
</script>

<template>
    <h2
        class="w-full rounded-md border-b-4 border-primary p-2 font-headers text-3xl text-primary"
    >
        {{ translations.messages }}
    </h2>
    <div class="mt-2 max-h-96 overflow-y-scroll" v-if="loaded">
        <div
            v-for="contact in contacts"
            class="flex w-full flex-row justify-between border-b border-primary"
        >
            <div class="w-2/3">
                <p class="font-bold text-primary">
                    <a
                        :href="'mailto:' + contact.email"
                        aria-label="Mail to contacts"
                        >{{ contact.email }}</a
                    >
                </p>
                <p class="text-[#3e8088]">{{ contact.name }}</p>
                <p class="break-all text-black">{{ contact.message }}</p>
            </div>
            <div class="w-1/3 p-2">
                <button
                    @click="deleteMessage(contact.id)"
                    aria-label="delete message"
                    class="ms-2 w-5/6 rounded-md bg-red-600 p-2 text-center text-white transition-colors duration-300 ease-in-out hover:bg-red-800"
                >
                    <i class="fa fa-trash"></i>
                </button>
            </div>
        </div>
    </div>
    <div v-if="!loaded" class="w-full min-h-52 flex justify-center align-middle">
        <LoadingSquare></LoadingSquare>
    </div>
</template>
