<script setup>
defineProps({
    value: {
        type: String,
    },
});
</script>

<template>
    <label class="inline-block text-sm font-headers text-gray-700 text-gray-900 border-r-8 border-transparent">
        <span v-if="value">{{ value }}</span>
        <span v-else><slot /></span>
    </label>
</template>
