<script setup>
import { Head } from '@inertiajs/vue3';
import AdminSidebar from '@/Layouts/AdminSidebar.vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    modifiableTranslations: {
        type: Object,
        required: true,
    },
    csrf_token: {
        required: true,
    },
});
</script>

<template>
    <Head :title="translations.title"></Head>
    <AdminSidebar :translations="translations">
        <div class="w-5/6 mx-auto shadow-md bg-white rounded-md my-auto min-h- p-2 mt-3 hidden md:block">
            <form class="h-full" action="/admin/translations/save" method="post">
                <input type="hidden" name="_token" :value="csrf_token">
                <table class="w-5/6 mx-auto h-full border-collapse">
                    <thead class="w-full mx-auto bg-primary h-10">
                        <tr class="w-full font-headers text-white p-4 text-xl">
                            <th>{{translations.key}}</th>
                            <th>ES</th>
                            <th>EN</th>
                            <th>CA</th>
                        </tr>
                    </thead>
                    <tbody class="h-full mt-4 w-full text-center">
                        <tr v-for="(translation , index) in modifiableTranslations.es" :key="index" class="mt-1  border-2 border-primary">
                            <td class="font-bold">{{ index }}</td>
                            <td><label :for="'es_' + index" class="hidden">change {{index}} in spanish</label><input type="text" :name="'es_' + index" :id="'es_' + index" :value="modifiableTranslations.es[index]"></td>
                            <td><label :for="'en_' + index" class="hidden">change {{index}} in english</label><input type="text" :name="'en_' + index" :id="'en_' + index" :value="modifiableTranslations.en[index]"></td>
                            <td><label :for="'ca_' + index" class="hidden">change {{index}} in catalan</label><input type="text" :name="'ca_' + index" :id="'ca_' + index" :value="modifiableTranslations.ca[index]"></td>
                        </tr>
                    </tbody>
                </table>
                <div class="mx-auto flex w-5/6 flex-row justify-end">
                    <button type="submit" class="rounded-md bg-mark p-2 hover:bg-[#ffcd4d] mt-5 ease-in-out transition-colors duration-300">
                        {{translations.save}}
                    </button>
                </div>
            </form>
        </div>
        <h1 class="md:hidden font-headers text-4xl text-black w-4/5 mt-28 mx-auto bg-white rounded-md shadow-md p-2">
            {{ translations.open_in_pc }}
        </h1>
    </AdminSidebar>
</template>

