<script setup>
import { Head } from '@inertiajs/vue3';
import AdminSidebar from '@/Layouts/AdminSidebar.vue';
import UserList from '@/Components/UserList.vue';
import ContactsLoad from '@/Components/ContactsLoad.vue';
import StatBlock from '@/Components/StatBlock.vue';
import axios from 'axios';
import { reactive } from 'vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    userid: {
        type: Number,
        required: true,
    },
});

const stats = reactive({
    files: null,
    tasks: null,
    users: null,
    managers: null,
    studied: null,
    contacts: null,
});

axios
    .post('/stats', {
        admin: true,
    })
    .then(function (response) {
        let info = response.data;
        stats.files = info.files;
        stats.tasks = info.tasks;
        stats.users = info.users;
        stats.managers = info.managers;
        stats.studied = info.studied;
        stats.contacts = info.contacts;
    });
</script>

<template>
    <Head :title="translations.adminpanel"></Head>
    <AdminSidebar :translations="translations" class="bg-notwhite">
        <h1 class="ml-3 mt-3 font-headers text-2xl md:text-5xl">
            {{ translations.adminpanel }}
        </h1>
        <div
            class="mx-auto mt-5 max-h-72 min-h-72 w-4/5 rounded-xl bg-white p-2 shadow-md"
        >
            <UserList
                :userid="userid"
                :is-admin="true"
                :translations="translations"
            ></UserList>
        </div>
        <div class="mx-auto flex w-4/5 flex-col md:flex-row justify-between">
            <div
                class="mt-5 max-h-[32rem] min-h-[32rem] w-full md:w-1/3 rounded-xl bg-white p-2 shadow-md"
            >
                <ContactsLoad :translations="translations"></ContactsLoad>
            </div>
            <div class="md:ms-5 mt-5 w-full md:w-2/3 grid-cols-2 gap-2 p-2 hidden md:grid">
                <StatBlock
                    title="Files:"
                    :number="stats.files"
                    text-color="text-white"
                    bg-color="bg-primary"
                ></StatBlock>
                <StatBlock
                    title="Active tasks:"
                    :number="stats.tasks"
                    text-color="text-black"
                    bg-color="bg-mark"
                ></StatBlock>
                <StatBlock
                    title="Users:"
                    :number="stats.users"
                    text-color="text-black"
                    bg-color="bg-secondary"
                ></StatBlock>
                <StatBlock
                    title="Managers:"
                    :number="stats.managers"
                    text-color="text-white"
                    bg-color="bg-primary"
                ></StatBlock>
                <StatBlock
                    title="Times studied:"
                    :number="stats.studied"
                    text-color="text-black"
                    bg-color="bg-mark"
                ></StatBlock>
                <StatBlock
                    title="Contacts:"
                    :number="stats.contacts"
                    text-color="text-black"
                    bg-color="bg-secondary"
                ></StatBlock>
            </div>
        </div>
    </AdminSidebar>
</template>
