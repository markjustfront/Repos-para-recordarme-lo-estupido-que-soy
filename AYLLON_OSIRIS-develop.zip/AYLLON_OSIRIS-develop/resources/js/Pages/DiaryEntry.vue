<script setup>
import { Head } from '@inertiajs/vue3'
import { Inertia } from '@inertiajs/inertia'
import Sidebar from '@/Layouts/Sidebar.vue'
import { QuillEditor } from '@vueup/vue-quill'
import 'quill/dist/quill.snow.css'
import { ref, onMounted, computed } from 'vue'
import axios from 'axios'

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

// Reactive variables to handle diary entries and UI state
const entryTitle = ref('')
const entryContent = ref('')
const editorKey = ref(0)
const allEntries = ref([])
const recentEntries = ref([])
const titleError = ref('')
const contentError = ref('')
const showConfirmModal = ref(false)
const showEntryModal = ref(false)
const activeEntries = ref([])
const selectedEntry = ref(null)
const selectedEntryIndex = ref(0)
const hasPreviousEntry = computed(() => selectedEntryIndex.value > 0)
const hasNextEntry = computed(() => selectedEntryIndex.value < activeEntries.value.length - 1)
const showAllEntriesModal = ref(false)

// Variables for edit mode
const isEditing = ref(false)
const editingEntryId = ref(null)

// Fetch all diary entries from API
const loadAllEntries = async () => {
    try {
        const response = await axios.get(route('diary.entries'))
        allEntries.value = response.data.entries
        recentEntries.value = allEntries.value.slice(0, 5)
    } catch (error) {
        console.error('Error fetching entries:', error)
    }
}

onMounted(() => {
    loadAllEntries()
})

// Open a specific diary entry
const openDiaryPost = (entryId) => {
    Inertia.get(route('diary.show', { id: entryId }))
}

// Open modal for viewing diary entries
const openEntryModal = (entries, index) => {
    activeEntries.value = entries
    selectedEntryIndex.value = index
    selectedEntry.value = entries[index]
    showAllEntriesModal.value = false
    showEntryModal.value = true
}

// Navigate to the previous diary entry
const previousEntry = () => {
    if (hasPreviousEntry.value) {
        selectedEntryIndex.value--
        selectedEntry.value = activeEntries.value[selectedEntryIndex.value]
    }
}

// Navigate to the next diary entry
const nextEntry = () => {
    if (hasNextEntry.value) {
        selectedEntryIndex.value++
        selectedEntry.value = activeEntries.value[selectedEntryIndex.value]
    }
}

// Validate input before saving an entry
const confirmSaveEntry = () => {
    titleError.value = ''
    contentError.value = ''
    if (!entryTitle.value.trim()) titleError.value = translations.error_title
    if (!entryContent.value.trim()) contentError.value = translations.error_content
    if (!titleError.value && !contentError.value) showConfirmModal.value = true
}

// Submit or update a diary entry
const submitEntry = async () => {
    showConfirmModal.value = false;
    if (isEditing.value) {
        try {
            const response = await axios.put(route('diary.update', { id: editingEntryId.value }), {
                title: entryTitle.value,
                content: entryContent.value,
            });
            const updatedEntry = response.data.entry;
            
            // Update entry list
            const index = allEntries.value.findIndex(e => e.id === updatedEntry.id);
            if (index !== -1) {
                allEntries.value[index] = updatedEntry;
            }
            recentEntries.value = allEntries.value.slice(0, 5);
            
            // Update currently selected entry if applicable
            if (selectedEntry.value && selectedEntry.value.id === updatedEntry.id) {
                selectedEntry.value = updatedEntry;
            }
            
            // Reset edit mode and clear form
            editingEntryId.value = null;
            isEditing.value = false;
            entryTitle.value = '';
            entryContent.value = '';
            editorKey.value++;
        } catch (error) {
            console.error(error);
        }
    } else {
        // Create a new entry
        try {
            const response = await axios.post(route('diary.store'), {
                title: entryTitle.value,
                content: entryContent.value,
            });
            allEntries.value.unshift(response.data.entry);
            recentEntries.value = allEntries.value.slice(0, 5);
            entryTitle.value = '';
            entryContent.value = '';
            editorKey.value++;
        } catch (error) {
            console.error(error);
        }
    }
}

// Delete a diary entry
const deleteEntry = async (entryId) => {
    try {
        await axios.delete(route('diary.delete', { id: entryId }))
        await loadAllEntries()
        showEntryModal.value = false
    } catch (error) {
        console.error('Error deleting entry:', error)
    }
}

// Open modal to view all entries
const openAllEntriesModal = () => {
    showAllEntriesModal.value = true
}

// Load entry into the form for editing
const editEntry = (entry) => {
    entryTitle.value = entry.title;
    entryContent.value = entry.content;
    editingEntryId.value = entry.id;
    isEditing.value = true;
    showEntryModal.value = false;
}
</script>

<template>
    <Head :title="translations.diary" />
    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <div class="flex justify-center bg-notwhite items-start min-h-screen bg-not px-8">
            <div class="flex flex-col lg:flex-row w-full max-w-6xl mt-10 gap-12">
                <section
                    class="flex-1 bg-white shadow-lg rounded-2xl border border-notwhite p-8 min-h-[85vh] max-h-80 flex flex-col"
                    aria-label="Create new Diary Entry">
                    <label for="entryTitle" class="sr-only">
                        {{ translations.placeholder }}
                    </label>
                    <input id="entryTitle" v-model="entryTitle" type="text" :placeholder="translations.placeholder"
                        class="w-full p-4 border border-gray-500 rounded-lg text-lg focus:ring-2 focus:outline-none"
                        aria-required="true" />
                    <div class="border border-gray-500 rounded-lg shadow-sm overflow-hidden flex-grow mt-4">
                        <label for="entryContent" class="sr-only">
                            {{ translations.placeholder }}
                        </label>
                        <QuillEditor :key="editorKey" id="entryContent" v-model:content="entryContent"
                            content-type="html" theme="snow" class="h-full break-words whitespace-pre-wrap"
                            aria-required="true" />
                    </div>

                    <div class="flex justify-center mt-8">
                        <button @click="confirmSaveEntry"
                            class="bg-[#286067] text-white py-3 px-10 rounded-lg hover:bg-secondary transition-all text-lg font-semibold shadow-md focus:outline-none focus:ring-2"
                            aria-label="Save Entry">
                            {{ translations.Save }}
                        </button>
                    </div>
                </section>

                <aside
                    class="w-full lg:w-1/3 bg-white shadow-lg rounded-2xl border border-notwhite p-6 max-h-[50vh] flex flex-col"
                    aria-label="Últimas Entradas">
                    <h1 class="text-lg font-bold text-white bg-[#286067] p-3 rounded-md text-center" role="heading"
                        aria-level="2">
                        {{ translations.Last }}
                    </h1>
                    <ul class="text-gray-800 mt-4 space-y-3 flex-grow overflow-y-auto">
                        <li v-for="(entry, index) in recentEntries" :key="entry.id"
                            class="border-b pb-2 text-gray-700 cursor-pointer hover:text-secondary"
                            @click="openEntryModal(recentEntries, index)">
                            {{ entry.title.length > 30 ? entry.title.substring(0, 30) + '...' : entry.title }}
                        </li>
                    </ul>
                    <button
                        class="mt-auto bg-[#286067] text-white py-3 px-6 rounded-lg w-full text-lg font-medium shadow-md focus:outline-none focus:ring-2"
                        aria-label="Ver todas las entradas" @click="openAllEntriesModal">
                        {{ translations.See }}
                    </button>
                </aside>
            </div>
        </div>
    </Sidebar>

    <!-- Modal of confirmation -->
    <div v-if="showConfirmModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white p-6 rounded shadow-lg w-full md:w-1/2 lg:w-1/3 mx-4">
            <h2 class="text-xl font-bold mb-4">
                {{ translations.confirmti }}
            </h2>
            <p class="mb-4 text-justify">
                {{ translations.confirmte }}
            </p>
            <div class="flex justify-end">
                <button @click="showConfirmModal = false" class="bg-[#286067] text-white px-4 py-2 rounded mr-2">
                    {{ translations.cancel }}
                </button>
                <button @click="submitEntry" class="bg-mark text-black px-4 py-2 rounded">
                    {{ translations.accept }}
                </button>
            </div>
        </div>
    </div>

    <!-- Modal for every entry -->
    <div v-if="showAllEntriesModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white p-6 rounded shadow-lg w-full md:w-3/4 lg:w-1/2 mx-4 max-h-[80vh] overflow-y-auto">
            <h2 class="text-xl font-bold mb-4 text-center">
                {{ translations.allEntriesTitle }}
            </h2>
            <ul class="space-y-3 text-gray-800">
                <li v-for="(entry, index) in allEntries" :key="entry.id"
                    class="border-b pb-2 text-gray-700 cursor-pointer hover:text-secondary"
                    @click="openEntryModal(allEntries, index)">
                    {{ entry.title }}
                </li>
            </ul>
            <div class="flex justify-end mt-4">
                <button @click="showAllEntriesModal = false"
                    class="bg-[#286067] text-white px-4 py-2 rounded hover:bg-secondary transition-all">
                    {{ translations.close }}
                </button>
            </div>
        </div>
    </div>

    <!-- Modal to view the entry -->
    <div v-if="showEntryModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div class="relative bg-white p-6 rounded shadow-lg w-full md:w-2/3 lg:w-1/2 xl:w-1/3 mx-4 max-h-[80vh] overflow-y-auto">
            <button @click="editEntry(selectedEntry)" class="absolute top-4 right-4 bg-secondary text-black px-3 py-1 rounded">
                {{ translations.edit }}
            </button>
            <h2 class="text-xl font-bold mb-4 truncate max-w-full overflow-hidden whitespace-nowrap">
                {{ selectedEntry.title && selectedEntry.title.length > 50
                    ? selectedEntry.title.substring(0, 50) + '...'
                    : selectedEntry.title
                }}
            </h2>
            <div class="mb-4 text-justify max-h-[50vh] overflow-y-auto p-2 border rounded w-full max-w-full break-words whitespace-pre-wrap">
                <div v-html="selectedEntry.content"></div>
            </div>

            <div class="hidden md:flex justify-between items-center mt-4">
                <button :disabled="!hasPreviousEntry" @click="previousEntry"
                     class="bg-[#286067] text-white px-4 py-2 rounded hover:bg-mark hover:text-black transition-all mr-2 disabled:opacity-50">
                    <span class="sr-only">{{ translations.previous }}</span>
                    <i class="fas fa-arrow-left"></i>
                </button>

                <div class="flex">
                    <button @click="showEntryModal = false" class="bg-primary text-white px-4 py-2 rounded mr-2">
                        {{ translations.close }}
                    </button>

                    <button @click="openDiaryPost(selectedEntry.id)"
                        class="bg-mark text-black px-4 py-2 rounded mr-2">
                        {{ translations.open }}
                    </button>

                    <button @click="deleteEntry(selectedEntry.id)" class="bg-red-600 text-white px-4 py-2 rounded">
                        {{ translations.delete }}
                    </button>
                </div>

                <button :disabled="!hasNextEntry" @click="nextEntry"
                    class="bg-[#286067] text-white px-4 py-2 rounded hover:bg-mark hover:text-black transition-all ml-2 disabled:opacity-50">
                    <span class="sr-only">{{ translations.next }}</span>
                    <i class="fas fa-arrow-right"></i>
                </button>
            </div>

            <div class="flex flex-col md:hidden gap-2 mt-4">
                <div class="flex justify-center gap-2">
                    <button @click="showEntryModal = false" class="w-full bg-primary text-white px-4 py-2 rounded">
                        {{ translations.close }}
                    </button>

                    <button @click="openDiaryPost(selectedEntry.id)"
                        class="w-full bg-mark text-black px-4 py-2 rounded">
                        {{ translations.open }}
                    </button>

                    <button @click="deleteEntry(selectedEntry.id)" class="w-full bg-red-600 text-white px-4 py-2 rounded">
                        {{ translations.delete }}
                    </button>
                </div>

                <div class="flex justify-between">
                    <button :disabled="!hasPreviousEntry" @click="previousEntry"
                        class="w-[48px] h-[40px] flex items-center justify-center bg-[#286067] text-white rounded hover:bg-mark hover:text-black transition-all disabled:opacity-50">
                        <span class="sr-only">{{ translations.previous }}</span>
                        <i class="fas fa-arrow-left"></i>
                    </button>

                    <button :disabled="!hasNextEntry" @click="nextEntry"
                        class="w-[48px] h-[40px] flex items-center justify-center bg-[#286067] text-white rounded hover:bg-mark hover:text-black transition-all disabled:opacity-50">
                        <span class="sr-only">{{ translations.next }}</span>
                        <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<style>
.ql-editor {
    word-break: break-word;
    overflow-wrap: break-word;
    white-space: pre-wrap;
}
</style>
