<script setup>
import { Head } from '@inertiajs/vue3';
import Sidebar from '@/Layouts/Sidebar.vue';
import { useForm } from '@inertiajs/vue3';
import { Inertia } from '@inertiajs/inertia';
import { ref } from 'vue';
import InputLabel from '@/Components/InputLabel.vue';
import TextInput from '@/Components/TextInput.vue';

const props = defineProps({
    tasks: { type: Object, default: () => ({}) }, // Default to an empty object
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

const form = useForm({
    title: null,
    importance: 1, // Default importance
    description: null,
    start_time: null,
    end_time: null,
});

const addTask = () => {
    form.post(route('tasks.store'), {
        onSuccess: () => {
            form.reset();
            Inertia.visit(route('tasks.index'));
        },
    });
};
</script>

<template>
    <Head :title="translations.title" />
    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <div class="h-min min-h-screen bg-notwhite p-4">
            <h1 class="ms-2 mt-5 font-headers text-5xl text-black">{{translations.addTask}}</h1>
            <div class="mx-auto mt-3 md:mt-20 flex w-11/12 flex-col md:flex-row justify-between">
                <div class="md:w-1/4">
                    <h2 class="text-3xl text-black">
                        {{translations.subtitle}}
                    </h2>
                    <form
                        @submit.prevent="addTask"
                        class="mt-3 flex flex-col items-center rounded-md"
                    >
                        <div class="mx-auto w-full rounded-md bg-[#286067] p-4 shadow-md">
                            <InputLabel
                                for="title"
                                :value="translations.tasktitle"
                                class="text-white"
                            ></InputLabel>
                            <br />
                            <TextInput
                                class="mx-auto w-full"
                                v-model="form.title"
                                id="title"
                                name="title"
                            ></TextInput>
                        </div>
                        <div
                            class="mx-auto mt-2 w-full rounded-md bg-secondary p-4 shadow-md"
                        >
                            <InputLabel
                                for="description"
                                :value="translations.description"
                            ></InputLabel>
                            <br />
                            <textarea
                                class="mx-auto w-full rounded-md border-gray-300 shadow-sm focus:border-mark focus:ring-mark dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:focus:border-mark dark:focus:ring-mark"
                                v-model="form.description"
                                id="description"
                                name="description"
                            ></textarea>
                        </div>
                        <div class="flex flex-col mx-auto mt-2 w-full rounded-md bg-terciary p-4 shadow-md">
                            <div>
                                <InputLabel
                                    for="start"
                                    :value="translations.start_time"
                                ></InputLabel>
                                <br />
                                <input
                                    type="date"
                                    class="mx-auto w-full rounded-md border-gray-300 shadow-sm focus:border-mark focus:ring-mark dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:focus:border-mark dark:focus:ring-mark"
                                    v-model="form.start_time"
                                    id="start"
                                    name="start"
                                />
                            </div>
                            <div>
                                <InputLabel
                                    for="end"
                                    :value="translations.end_time"
                                ></InputLabel>
                                <br />
                                <input
                                    class="mx-auto w-full rounded-md border-gray-300 shadow-sm focus:border-mark focus:ring-mark dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:focus:border-mark dark:focus:ring-mark"
                                    type="date"
                                    v-model="form.end_time"
                                    id="end"
                                    name="end"
                                />
                            </div>
                        </div>
                        <button
                            type="submit"
                            class="mb-1 mt-2 rounded bg-[#286067] px-6 py-3 text-sm font-bold uppercase text-white shadow-md outline-none transition-all duration-150 ease-linear hover:bg-secondary hover:shadow-lg focus:outline-none"
                        >
                            {{ translations.addTask }}
                        </button>
                    </form>
                </div>

                <img src="/images/task.png" alt="task image" class="hidden md:block min-w-[950px]"/>
            </div>
        </div>
    </Sidebar>
</template>
