<script setup>
import { Head } from '@inertiajs/vue3';
import Sidebar from '@/Layouts/Sidebar.vue';
import axios from 'axios';
import { ref } from 'vue';
import { Inertia } from '@inertiajs/inertia';

const props = defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

if (props.tasks && props.tasks.data) {
    props.tasks.data.forEach((task) => {
        task.isOpen = ref(false);
    });
} else {
    console.log('Tasks data is not available');
}

const tasks = ref(null);
const refresh = () => {
    axios.get('/getTasks').then(function (response) {
        tasks.value = response.data.tasks;
    });
};

refresh();

const finishTask = (taskId) => {
    axios.get(route('tasks.destroy', taskId), {}).then(function () {
        refresh();
    });
};
</script>

<template>
    <Head :title="translations.title" />
    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <div class="h-min min-h-screen bg-notwhite p-4">
            <h1 class="ms-2 mt-5 font-headers text-5xl text-black">{{translations.tasks}}</h1>
            <div class="mx-auto grid w-4/5 grid-cols-1 gap-5 md:grid-cols-3 mt-5">
                <div
                    v-for="task in tasks"
                    class="rounded-md bg-white shadow-md"
                >
                    <div
                        class="rounded-b-none rounded-t-lg bg-primary text-3xl p-2 text-white"
                    >
                        {{ task.title }}
                    </div>
                    <div class="rounded-t-none rounded-b-lg bg-terciary p-2 min-h-36 max-h-36 break-all overflow-x-hidden overflow-y-auto flex flex-col">
                        <p>{{ task.description }}</p>
                        <p class="mt-auto mb-0.5  text-sm">{{translations.from}} {{task.start_time}} {{translations.to}} {{task.end_time}}</p>
                        <button @click="finishTask(task.id)" class="bg-red-500 hover:bg-red-800 hover:text-white transition-colors duration-300 ease-in-out text-black rounded-md">{{translations.finish}}</button>
                    </div>
                </div>
            </div>
        </div>
    </Sidebar>
</template>
