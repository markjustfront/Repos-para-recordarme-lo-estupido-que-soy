<script setup>
import { Head } from '@inertiajs/vue3';
import Templates from '@/Layouts/Templates.vue';
import Fancybox from '@/Components/Fancybox.vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});
</script>

<template>
    <Head :title="translations.about" />
    <Templates :translations="translations">
        <div class="flex min-h-screen flex-col justify-center bg-notwhite">
            <!-- About Us Section -->
            <section class="flex flex-col items-center pb-24 pt-6 text-center">
                <h1 class="mb-6 font-headers text-5xl font-bold text-black">
                    {{ translations.title }}
                </h1>
                <h2 class="mb-10 font-headers text-3xl font-medium text-black">
                    {{ translations.team }}
                </h2>
                <div
                    class="mx-auto grid w-full max-w-7xl grid-cols-1 gap-16 md:grid-cols-3 lg:grid-cols-5"
                >
                    <div
                        v-for="(member, index) in translations.team_members"
                        v-bind:key="index"
                        class="flex w-full flex-col items-center rounded-lg bg-white p-6 font-main transition-transform duration-300 hover:scale-110 hover:bg-terciary hover:text-black hover:shadow-xl"
                    >
                        <Fancybox :options="{Carousel: {infinite: false}}"
                            class="flex h-28 w-28 items-center justify-center overflow-hidden rounded-full bg-gray-200 md:h-36 md:w-36"
                        >
                            <a :href="member.image" data-fancybox="gallery" aria-label="fancybox link">
                                <img
                                    :src="member.image"
                                    alt="Team member"
                                    class="h-full w-full object-cover"
                                />
                            </a>

                        </Fancybox>
                        <p class="mt-4 text-lg font-medium md:text-xl">
                            {{ member.name }}
                        </p>
                        <p
                            class="mt-2 text-center text-sm md:text-base"
                            v-if="member.description"
                        >
                            {{ member.description }}
                        </p>
                    </div>
                </div>

                <p class="mt-16 font-headers text-6xl font-bold text-[#b98500]">
                    Osiris
                </p>

                <div class="mb-3">
                    <div
                        class="font-body mb-10 mt-16 max-w-7xl items-center rounded-lg bg-white p-6 text-justify text-sm font-medium text-black md:text-base"
                        alt="About Us"
                    >
                        {{ translations.about_text }}
                    </div>
                </div>
            </section>
        </div>
    </Templates>
</template>

<script>
export default {
    name: 'About',
};
</script>
