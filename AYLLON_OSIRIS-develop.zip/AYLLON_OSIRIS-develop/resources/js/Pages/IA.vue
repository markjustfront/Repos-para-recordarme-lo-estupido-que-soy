<script setup>
import axios from 'axios';
import { ref, computed } from 'vue';
import { marked } from 'marked';

const texto = ref('');
const cargando = ref(false);
const respuesta = ref('');

const generarTexto = async (tipo) => {
  if (!texto.value.trim()) {
    alert('Escribe un texto primero');
    return;
  }

  cargando.value = true;
  respuesta.value = '';

  try {
    const response = await axios.post('/generar-texto', {
      texto: texto.value,
      tipo: tipo
    });

    respuesta.value = response.data.respuesta || 'No hay respuesta';
  } catch (error) {
    respuesta.value = error.response?.data?.error || 'Error al generar el texto.';
  } finally {
    cargando.value = false;
  }
};

const htmlResponse = computed(() => marked(respuesta.value || ''));
</script>

<template>
  <div class="max-w-lg mx-auto bg-white p-6 rounded-lg shadow">
    <h2 class="text-lg font-bold text-gray-800 mb-4">📄 Procesar Texto con IA</h2>

    <textarea
      v-model="texto"
      class="w-full border rounded p-2 focus:ring focus:ring-blue-300"
      rows="4"
      placeholder="Escribe tu texto aquí..."
    ></textarea>

    <div class="flex space-x-4 mt-4">
      <button
        @click="generarTexto('resumen')"
        class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
      >
        📝 Resumir
      </button>
      <button
        @click="generarTexto('plan_estudio')"
        class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition"
      >
        📚 Plan de Estudio
      </button>
    </div>

    <div v-if="cargando" class="mt-4 text-gray-500">
      ⏳ Generando respuesta...
    </div>

    <div v-if="respuesta" class="mt-4 p-3 border rounded bg-gray-50">
      <strong>🧠 Respuesta:</strong>
      <div class="mt-2" v-html="htmlResponse"></div>
    </div>
  </div>
</template>
