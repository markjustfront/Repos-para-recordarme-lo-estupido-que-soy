<script setup>
import { Head } from '@inertiajs/vue3';
import { Inertia } from '@inertiajs/inertia';
import Sidebar from '@/Layouts/Sidebar.vue';
import { ref, onMounted, computed } from 'vue';
import axios from 'axios';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    entry: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

const allEntries = ref([]);
const recentEntries = ref([]);
const showAllEntriesModal = ref(false);
const activeEntries = ref([]);
const selectedEntry = ref(null);
const selectedEntryIndex = ref(0);
const showEntryModal = ref(false);
const hasPreviousEntry = computed(() => selectedEntryIndex.value > 0);
const hasNextEntry = computed(
    () => selectedEntryIndex.value < activeEntries.value.length - 1,
);

const loadAllEntries = async () => {
    try {
        const response = await axios.get(route('diary.entries'));
        allEntries.value = response.data.entries;
        recentEntries.value = allEntries.value.slice(0, 5);
    } catch (error) {
        console.error(translations.errorLoading, error);
    }
};

onMounted(() => {
    loadAllEntries();
});

const openAllEntriesModal = () => {
    showAllEntriesModal.value = true;
};

const openEntryModal = (entries, index) => {
    activeEntries.value = entries;
    selectedEntryIndex.value = index;
    selectedEntry.value = entries[index];
    showAllEntriesModal.value = false;
    showEntryModal.value = true;
};

const previousEntry = () => {
    if (hasPreviousEntry.value) {
        selectedEntryIndex.value--;
        selectedEntry.value = activeEntries.value[selectedEntryIndex.value];
    }
};

const nextEntry = () => {
    if (hasNextEntry.value) {
        selectedEntryIndex.value++;
        selectedEntry.value = activeEntries.value[selectedEntryIndex.value];
    }
};

const openDiaryPost = (entryId) => {
    Inertia.get(route('diary.show', { id: entryId }));
};

const deleteEntry = async (entryId) => {
    try {
        await axios.delete(route('diary.delete', { id: entryId }));
        await loadAllEntries();
        showEntryModal.value = false;
    } catch (error) {
        console.error(translations.errorDeleting, error);
    }
};
</script>

<template>
    <Head :title="entry.title" />

    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <div
            class="flex min-h-screen items-start justify-center bg-notwhite px-8"
        >
            <div
                class="mt-10 flex w-full max-w-6xl flex-col gap-12 lg:flex-row"
            >
                <section
                    class="flex max-h-[85vh] min-h-[85vh] flex-1 flex-col overflow-hidden rounded-2xl border border-notwhite bg-white p-8 shadow-lg"
                    aria-label="Diary Entry"
                >
                    <h1 class="mb-4 text-2xl font-bold">
                        {{ entry.title }}
                    </h1>
                    <div class="diary-content">
                        <div v-html="entry.content"></div>
                    </div>
                </section>

                <aside
                    class="flex max-h-[50vh] w-full flex-col rounded-2xl border border-notwhite bg-white p-6 shadow-lg lg:w-1/3"
                    aria-label="Últimas Entradas"
                >
                    <h1
                        class="rounded-md bg-[#286067] p-3 text-center text-lg font-bold text-white"
                    >
                        {{ translations.Last }}
                    </h1>

                    <ul
                        class="mt-4 flex-grow space-y-3 overflow-y-auto text-gray-800"
                    >
                        <li
                            v-for="(entry, index) in recentEntries"
                            :key="entry.id"
                            class="cursor-pointer border-b pb-2 text-gray-700 hover:text-secondary"
                            @click="openEntryModal(recentEntries, index)"
                        >
                            {{
                                entry.title.length > 30
                                    ? entry.title.substring(0, 30) + '...'
                                    : entry.title
                            }}
                        </li>
                    </ul>

                    <button
                        class="mt-auto w-full rounded-lg bg-[#286067] px-6 py-3 text-lg font-medium text-white shadow-md focus:outline-none focus:ring-2"
                        @click="openAllEntriesModal"
                    >
                        {{ translations.See }}
                    </button>
                </aside>
            </div>
        </div>
    </Sidebar>

    <div
        v-if="showAllEntriesModal"
        class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
    >
        <div
            class="mx-4 max-h-[80vh] w-full overflow-y-auto rounded bg-white p-6 shadow-lg md:w-3/4 lg:w-1/2"
        >
            <h2 class="mb-4 text-center text-xl font-bold">
                {{ translations.allEntriesTitle }}
            </h2>
            <ul class="space-y-3 text-gray-800">
                <li
                    v-for="(entry, index) in allEntries"
                    :key="entry.id"
                    class="cursor-pointer border-b pb-2 text-gray-700 hover:text-secondary"
                    @click="openEntryModal(allEntries, index)"
                >
                    {{ entry.title }}
                </li>
            </ul>
            <div class="mt-4 flex justify-end">
                <button
                    @click="showAllEntriesModal = false"
                    class="rounded bg-[#286067] px-4 py-2 text-white transition-all hover:bg-secondary"
                >
                    {{ translations.close }}
                </button>
            </div>
        </div>
    </div>

    <div
        v-if="showEntryModal"
        class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
    >
        <div
            class="content mx-4 max-h-[85vh] w-full overflow-y-auto rounded bg-white p-6 shadow-lg md:w-1/2 lg:w-1/3"
        >
            <h2 class="mb-4 text-xl font-bold">
                {{ selectedEntry.title }}
            </h2>

            <div class="modal-text">
                <div v-html="selectedEntry.content"></div>
            </div>

            <div class="mt-4 flex items-center justify-between">
                <button
                    :disabled="!hasPreviousEntry"
                    @click="previousEntry"
                    class="rounded bg-[#286067] px-4 py-2 text-white transition-all hover:bg-mark disabled:opacity-50"
                >
                    <i class="fas fa-arrow-left"></i>
                </button>

                <div class="flex">
                    <button
                        @click="showEntryModal = false"
                        class="mr-2 rounded bg-primary px-4 py-2 text-white"
                    >
                        {{ translations.close }}
                    </button>

                    <button
                        @click="openDiaryPost(selectedEntry.id)"
                        class="mr-2 rounded bg-mark px-4 py-2 text-black"
                    >
                        {{ translations.open }}
                    </button>

                    <button
                        @click="deleteEntry(selectedEntry.id)"
                        class="rounded bg-red-600 px-4 py-2 text-white"
                    >
                        {{ translations.delete }}
                    </button>
                </div>

                <button
                    :disabled="!hasNextEntry"
                    @click="nextEntry"
                    class="rounded bg-[#286067] px-4 py-2 text-white transition-all hover:bg-mark disabled:opacity-50"
                >
                    <i class="fas fa-arrow-right"></i>
                </button>
            </div>
        </div>
    </div>
</template>

<style scoped>
.diary-content,
.modal-text {
    max-height: 65vh;
    overflow-y: auto;
    padding: 10px;
    border: 1px solid #fff;
    background-color: #fff;
    word-break: break-word;
    overflow-wrap: break-word;
    white-space: pre-wrap;
}

:deep(.diary-content h1),
:deep(.modal-text h1) {
    font-size: 2.5rem !important;
    font-weight: bold;
}

:deep(.diary-content h2),
:deep(.modal-text h2) {
    font-size: 2rem !important;
    font-weight: bold;
}

:deep(.diary-content h3),
:deep(.modal-text h3) {
    font-size: 1.75rem !important;
    font-weight: bold;
}
</style>
