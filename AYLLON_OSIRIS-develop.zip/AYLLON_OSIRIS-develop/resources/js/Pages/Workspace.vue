<script setup>
import { Head, useForm } from '@inertiajs/vue3';
import Sidebar from '@/Layouts/Sidebar.vue';
import { onMounted, ref } from 'vue';
import 'vue-search-input/dist/styles.css';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
import axios from 'axios';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

onMounted(() => {
    props.pdfs.forEach((pdf) => {
        loadFirstPage(pdf); // Calling the function
    });
});

const props = defineProps({
    translations: {
        type: Object,
        required: true,
    },
    pdfs: {
        type: Object,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

var childPDF = ref(props.pdfs);

const refresh = () => {
    axios.get('/allFiles').then(function (response) {
        childPDF.value = response.data;
    });
};
function readFile(pdf) {
    const url = pdf.route;

    window.open(url);
}
function deleteFile(pdf) {
    axios.delete('/deletefile/' + pdf.name).then(function () {
        refresh();
    });
}

function search() {
    let text = document.getElementById('search').value;
    if (text.length >= 3 || text.length === 0) {
        //axios
        axios
            .post('/searchfile', {
                params: {
                    search: text,
                },
            })
            .then(function (response) {
                childPDF.value = response.data;
                response.data.forEach((pdf) => {
                    loadFirstPage(pdf); // Calling the function
                });
            })
            .catch(function (error) {
                console.log(error);
            });
    }
}
const loadFirstPage = (pdf) => {
    const canvasId = `canvas-${pdf.id}`; // id PDF

    const url = pdf.route;

    // disseny PDF
    pdfjsLib.getDocument(url).promise.then((pdfDoc) => {
        pdfDoc.getPage(1).then((page) => {
            // page
            const scale = 0.5;
            const viewport = page.getViewport({ scale });

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.height = viewport.height;
            canvas.width = viewport.width;

            const renderContext = {
                canvasContext: ctx,
                viewport: viewport,
            };
            page.render(renderContext).promise.then(() => {
                // imagen
                const img = canvas.toDataURL();

                const imgElement = document.getElementById(canvasId);
                imgElement.src = img;
            });
        });
    });
};
</script>

<template>
    <Head :title="translations.workspace" />

    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <h1
            class="my-8 ms-8 block justify-items-start font-headers text-black md:text-4xl"
        >
            {{ translations.workspace }}
        </h1>

        <div class="flex w-full flex-row justify-center">
            <input
                aria-label="search bar"
                type="text"
                @input="search"
                id="search"
                :placeholder="translations.search"
                class="w-1/2 rounded-md bg-terciary text-black"
            />
        </div>

        <div
            class="mx-auto grid w-full grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
        >
            <div
                v-for="pdf in childPDF"
                class="mx-auto mb-6 mt-8 w-4/5 max-w-72 overflow-hidden rounded bg-white shadow-lg md:max-w-2xl"
            >
                <img
                    :id="'canvas-' + pdf.id"
                    class="mx-auto mt-6 h-auto max-h-96 min-h-96 max-w-lg"
                    alt="PDF"
                />

                <div class="px-6 py-4">
                    <div class="mb-2 text-center text-xl font-bold">
                        {{ pdf.fake_name }}
                    </div>
                </div>

                <div class="mx-auto flex w-4/5 flex-row justify-between p-2">
                    <button
                        @click="deleteFile(pdf)"
                        aria-label="delete file"
                        class="mb-8 rounded-md border border-transparent bg-red-500 px-6 py-3 text-white hover:bg-red-800 active:bg-primary dark:hover:bg-secondary"
                    >
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </button>
                    <button
                        @click="readFile(pdf)"
                        aria-label="read file"
                        class="mb-8 rounded-md border border-transparent bg-[#286067] px-8 py-3 text-white hover:bg-secondary hover:text-black active:bg-primary dark:hover:bg-secondary"
                    >
                        {{ translations.read }}
                    </button>
                </div>
            </div>
        </div>
    </Sidebar>
</template>
