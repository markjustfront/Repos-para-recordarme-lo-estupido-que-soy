<script setup>
import { Head, useForm } from '@inertiajs/vue3';
import Sidebar from '@/Layouts/Sidebar.vue';

const form = useForm({
    file: '',
});

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

const submit = () => {
    form.post(route('upload.file'), {
        onFinish: () => form.reset('password'),
    });
};
</script>

<template>
    <Head :title="translations.upload" />
    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <form
            @submit.prevent="submit"
            enctype="multipart/form-data"
            class="flex w-full flex-col items-center px-4 sm:px-8"
        >
            <h1
                class="my-8 ms-8 block grid justify-items-start font-headers text-2xl text-4xl text-gray-700 text-gray-900 sm:text-3xl md:text-4xl"
            >
                {{ translations.upload }}
            </h1>

            <img
                class="mx-auto h-auto max-w-xs sm:max-w-sm md:max-w-md lg:max-w-lg"
                src="/images/Upload.png"
                alt="image description"
            />

            <label for="file" class="hidden">Upload file</label>
            <!-- Upload file  -->
            <input
                type="file"
                name="file"
                id="file" accept="application/pdf"
                class="text-md mx-auto mt-14 w-3/5 cursor-pointer rounded-xl bg-primary py-0 font-headers font-medium text-white shadow-md file:mr-4 file:cursor-pointer file:border-0 file:bg-terciary file:px-4 file:py-3 file:hover:bg-secondary"
                @input="form.file = $event.target.files[0]"
            />

            <div
                class="mt-6 flex w-full flex-col items-center justify-center gap-4 sm:flex-row sm:gap-6"
            >
                <button
                    aria-label="upload file"
                    class="gap-2” flex items-center justify-items-center rounded-md border border-transparent bg-mark px-6 px-8 py-3 text-black active:bg-mark dark:hover:bg-terciary"
                    :class="{ 'opacity-25': form.processing }"
                    :disabled="form.processing"
                >
                    <i class="fa fa-upload" aria-hidden="true"></i>
                </button>
            </div>
        </form>
    </Sidebar>
</template>

<script>
export default {
    name: 'Upload',
};
</script>
