<script setup>
import { Head } from '@inertiajs/vue3';
import Templates from '@/Layouts/Templates.vue';
import { useForm } from '@inertiajs/vue3';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});

const form = useForm({
    name: null,
    email: null,
    message: null,
});

//Validate form 
const addContact = () => {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;
    const nameErr = document.getElementById("name-error");
    const emailErr = document.getElementById("email-error");
    const messageErr = document.getElementById("message-error");
    nameErr.textContent = "";
    emailErr.textContent = "";
    messageErr.textContent = "";

    let isValid = true;
    if (name === "" || /\d/.test(name)) {
        nameErr.textContent = "Please enter your name properly.";
        isValid = false;
    }
    if (email === "" || !email.includes("@") || !email.includes(".")) {
        emailErr.textContent = "Please enter a valid email address.";
        isValid = false;
    }
    if (message === "" || /\d/.test(name)) {
        messageErr.textContent = "Please write your message.";
        isValid = false;
    }
    if (isValid){
        form.post(route('addContact'), {
            onSuccess: () => form.reset(),
        });
    }

};
</script>

<template>
    <Head :title="translations.contact" />
    <Templates :translations="translations">
        <div class="min-h-screen bg-notwhite flex flex-col md:flex-row justify-between items-center p-4">
            <img
                class="mx-auto block max-w-1/4"
                alt="Osiris Logo"
                src="/images/Contact.png"
            />
            <div class="p-5 md:w-1/3">
                <form
                    class="mx-auto mt-5 items-center"
                    @submit.prevent="addContact"
                >
                    <div class="mb-3 pt-0">
                        <label for="name">{{ translations.name }}</label>
                        <input type="text" v-model="form.name" placeholder="John" id="name" name="name"
                            class="relative w-full rounded border-0 bg-gray-200 px-3 py-3 text-sm text-gray-600 placeholder-gray-400 shadow outline-none focus:outline-none focus:ring"
                            required
                        />
                        <span id="name-error" class="error-message text-red-500 text-[10px]"></span>
                    </div>
                    <!-- Email -->
                    <div class="mb-3 pt-0">
                        <label for="email">{{ translations.email }}</label>
                        <input
                            type="email" v-model="form.email" placeholder="john@doe.co" id="email" name="email"
                            class="relative w-full rounded border-0 bg-gray-200 px-3 py-3 text-sm text-gray-600 placeholder-gray-400 shadow outline-none focus:outline-none focus:ring"
                            required
                        />
                        <span id="email-error" class="error-message text-red-500 text-[10px]"></span>
                    </div>
                    <!-- Message -->
                    <div class="mb-3 pt-0">
                        <label for="message">{{ translations.message }}</label>
                        <input
                            type="text" v-model="form.message" placeholder="Bli bli bla bla blu" id="message" name="message"
                            class="relative w-full rounded border-0 bg-gray-200 px-3 py-3 text-sm text-gray-600 placeholder-gray-400 shadow outline-none focus:outline-none focus:ring min-h-6"
                            required
                        />
                        <span id="message-error" class="error-message text-red-500 text-[10px]"></span>
                    </div>
                    <!-- Submit button -->
                    <div class="mb-3 pt-0">
                        <button
                            class="mb-1 mr-1 rounded bg-primary px-6 py-3 text-sm font-bold uppercase text-white shadow outline-none transition-all duration-150 ease-linear hover:bg-secondary hover:shadow-lg focus:outline-none"
                            type="submit"
                            :disabled="form.processing"
                        >
                            {{ translations.submit }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </Templates>
</template>
