<script setup>
import DeleteUserForm from './Partials/DeleteUserForm.vue';
import UpdatePasswordForm from './Partials/UpdatePasswordForm.vue';
import UpdateProfileInformationForm from './Partials/UpdateProfileInformationForm.vue';
import { Head } from '@inertiajs/vue3';
import Sidebar from '@/Layouts/Sidebar.vue';
import { reactive } from 'vue';

const state = reactive({
    option: 'info',
});

defineProps({
    mustVerifyEmail: {
        type: Boolean,
    },
    status: {
        type: String,
    },
    translations: {
        type: Object,
        required: true,
    },
});
</script>

<template>
    <Head :title="translations.title" />

    <Sidebar :translations="translations">
        <div class="min-h-screen h-min bg-gray-200 py-12 w-full">
            <div class="flex flex-col md:flex-row w-full md:justify-between h-full">
                <div class="bg-white rounded-md shadow-md text-black w-3/4 md:w-1/5 mx-auto md:mx-0 md:ms-8 p-4 md:h-40 flex flex-row md:flex-col justify-center">
                    <div class="w-full hover:bg-gray-300 p-2 rounded-md cursor-pointer transition-colors duration-300 break-all" :class="state.option === 'info' ? 'bg-gray-100' : 'bg-white'" @click="state.option='info'">{{translations.edit}}</div>
                    <div class="w-full hover:bg-gray-300 p-2 rounded-md cursor-pointer transition-colors duration-300 break-all" :class="state.option === 'update' ? 'bg-gray-100' : 'bg-white'" @click="state.option='update'">{{translations.update_password}}</div>
                    <div class="w-full hover:bg-gray-300 p-2 rounded-md cursor-pointer transition-colors duration-300 break-all" :class="state.option === 'delete' ? 'bg-gray-100' : 'bg-white'" @click="state.option='delete'">{{translations.delete_account}}</div>
                </div>
                <div class="w-3/4 md:me-8 mx-auto md:mx-0 mt-5 md:mt-0">
                    <div class="mx-auto w-full rounded-md bg-white p-4 shadow-md" v-if="state.option === 'info'">
                        <UpdateProfileInformationForm
                            :must-verify-email="mustVerifyEmail"
                            :status="status"
                            :translations="translations"
                        />
                    </div>
                    <div class="mx-auto w-full rounded-md bg-white p-4 shadow-md" v-if="state.option === 'update'">
                        <UpdatePasswordForm :translations="translations"/>
                    </div>
                    <div class="mx-auto w-full rounded-md bg-white p-4 shadow-md" v-if="state.option === 'delete'">
                        <DeleteUserForm :translations="translations"/>
                    </div>
                </div>
            </div>

        </div>

    </Sidebar>
</template>
