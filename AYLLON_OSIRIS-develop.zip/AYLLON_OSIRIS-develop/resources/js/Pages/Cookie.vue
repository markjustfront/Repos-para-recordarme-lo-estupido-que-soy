<script setup>
import { Head } from '@inertiajs/vue3';
import Templates from '@/Layouts/Templates.vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});
</script>

<template>
    <Head :title="translations.cookies_title" />

    <Templates :translations="translations">
        <section v-html="translations.cookies_policy" class="w-3/4 mx-auto py-10"></section>
    </Templates>
</template>

<script>
export default {
    name: 'Cookies',
};
</script>
