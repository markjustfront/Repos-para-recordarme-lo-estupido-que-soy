<script setup>
import Sidebar from '@/Layouts/Sidebar.vue';
import { Head } from '@inertiajs/vue3';
import { reactive } from 'vue';
import AiModalButton from '@/Components/AiModalButton.vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

const state = reactive({
    started: false,
    paused: false,
    timing: 'normal',
    timer: 1500000,
    minutes: '25',
    seconds: '00',
    series: 1,
});

let interval;
let iterations = 0;
let hasStarted = false;

const start = () => {
    if (hasStarted === false) {
        axios.get('/incrementstudies');
        hasStarted = true;
    }
    state.started = true;
    interval = setInterval(() => {
        if (state.timer <= 0) {
            clearInterval(interval);
            playChime();
            if (state.series !== 0) {
                if (iterations === 4) {
                    state.timing = 'long';
                    state.timer = 900000;
                    startLongBreak();
                } else {
                    state.timing = 'short';
                    state.timer = 300000;
                    startBreak();
                }
            } else {
                state.started = false;
                state.paused = false;
                state.timing = 'normal';
                state.timer = 1500000;
                state.minutes = '25';
                state.seconds = '00';
                state.series = 1;
            }
        } else {
            state.timer -= 1000;
            calcTimer();
        }
    }, 1000);
};

const startBreak = () => {
    interval = setInterval(() => {
        if (state.timer <= 0) {
            playChime();
            clearInterval(interval);
            iterations++;
            state.timing = 'normal';
            state.timer = 1500000;
            state.series--;
            start();
        } else {
            state.timer -= 1000;
            calcTimer();
        }
    }, 1000);
};

const startLongBreak = () => {
    interval = setInterval(() => {
        if (state.timer <= 0) {
            playChime();
            clearInterval(interval);
            iterations = 0;
            state.timing = 'normal';
            state.timer = 1500000;
            start();
        } else {
            state.timer -= 1000;
            calcTimer();
        }
    }, 1000);
};

const pause = () => {
    if (state.paused) {
        state.paused = false;
        if (state.timing === 'normal') {
            start();
        } else if (start.timing === 'short') {
            startBreak();
        } else {
            startLongBreak();
        }
    } else {
        state.paused = true;
        clearInterval(interval);
    }
};

const stop = () => {
    state.paused = false;
    state.started = false;
    state.seconds = '00';
    state.minutes = '25';
    state.timing = 'normal';
    state.timer = 1500000;
    clearInterval(interval);
};

const playChime = () => {
    let audio = new Audio('/sounds/chime.mp3');
    audio.play();
};

const calcTimer = () => {
    state.minutes = Math.floor(state.timer / 60000);
    state.seconds = Math.floor((state.timer % 60000) / 1000);

    state.minutes = String(state.minutes).padStart(2, '0');
    state.seconds = String(state.seconds).padStart(2, '0');
};
</script>

<template>

    <Head :title="state.minutes + ' : ' + state.seconds"></Head>
    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <div class="mx-auto mt-5 flex h-1/2 min-h-36 w-3/4 flex-col items-center justify-center rounded-md bg-primary shadow-md p-4">
            <label v-if="!state.started" for="series" class="text-white text-2xl">{{ translations.series }}</label>
            <input type="number" name="series" id="series" v-model="state.series" value="1" v-if="!state.started"
                min="1" max="3" class="mb-3 w-1/4 rounded-md bg-terciary text-black" />
            <h1 class="font-headers text-4xl md:text-6xl tracking-wide text-white transition-all ease-in-out">
                {{ state.minutes }} : {{ state.seconds }}
            </h1>
            <button @click="start" v-if="!state.started"
                class="mt-10 w-1/3 md:w-1/4 rounded-xl bg-lime-500 p-3 text-black hover:bg-green-400" aria-label="Start timer">
                <i class="fa-regular fa-circle-play"></i>
                {{ translations.start }}
            </button>
            <div v-if="state.started" class="mt-10 flex w-full flex-row justify-center rounded-xl p-3">
                <button class="me-1 w-1/4 rounded-xl bg-amber-400 p-3 text-black hover:bg-yellow-300" @click="pause"
                    v-if="!state.paused" aria-label="Pause timer">
                    <i class="fa-regular fa-circle-pause"></i> {{ translations.pause }}
                </button>
                <button class="me-1 w-1/4 rounded-xl bg-lime-500 p-3 text-black hover:bg-green-400" @click="pause"
                    v-if="state.paused" aria-label="Resume timer">
                    <i class="fa-regular fa-circle-play"></i> {{ translations.resume }}
                </button>
                <button class="ms-1 w-1/4 rounded-xl bg-[#b60000] p-3 text-white hover:bg-red-500" @click="stop"
                    aria-label="Stop timer">
                    <i class="fa-regular fa-circle-stop"></i> {{ translations.stop }}
                </button>
            </div>
        </div>
        <div class="mx-auto mt-5 h-auto w-3/4 rounded-md bg-terciary text-black p-3 text-justify shadow-md">
            {{ translations.pomodoro }}
        </div>
        <AiModalButton :translations="translations" class="flex justify-center mt-5"></AiModalButton>
    </Sidebar>
</template>

<style lang="scss">
@import '../../../node_modules/@fortawesome/fontawesome-free/css/all.css';
</style>
