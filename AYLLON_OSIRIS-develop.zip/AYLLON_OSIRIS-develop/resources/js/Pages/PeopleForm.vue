<script setup>
import { Head, useForm } from '@inertiajs/vue3';
import Sidebar from '@/Layouts/Sidebar.vue';
import InputLabel from '@/Components/InputLabel.vue';
import TextInputPeople from '@/Components/TextInputPeople.vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

const form = useForm({
    name: '',
    lastname: '',
    birthday: '',
    relationship: '',
    description: '',
    image: '',
});


//Validation form 
const submit = () => {
    const name = document.getElementById("name").value;
    const lastname = document.getElementById("lastname").value;
    const birthday = document.getElementById("birthday").value;
    const relationship = document.getElementById("relationship").value;
    const description = document.getElementById("description").value;
    const nameErr = document.getElementById("name-error");
    const lastnameErr = document.getElementById("lastname-error");
    const birthdayErr = document.getElementById("birthday-error");
    const relationshipErr = document.getElementById("relationship-error");
    const descriptionErr = document.getElementById("description-error");
    nameErr.textContent = "";
    lastnameErr.textContent = "";
    birthdayErr.textContent = "";
    birthdayErr.textContent = "";
    relationshipErr.textContent = "";
    descriptionErr.textContent = "";

    let isValid = true;

    if (name === "" || /\d/.test(name)) {
        nameErr.textContent = "Please enter your name properly.";
        isValid = false;
    }
    if (lastname === "" || /\d/.test(lastname)) {
        lastnameErr.textContent = "Please enter your lastname properly.";
        isValid = false;
    }
    if (description === "" || /\d/.test(description)) {
        descriptionErr.textContent = "Please write your description .";
        isValid = false;
    }
    if (birthday === "") {
        birthdayErr.textContent = "Please enter your birthday.";
        isValid = false;
    }
    if (relationship === "") {
        relationshipErr.textContent = "Please select your relationship";
        isValid = false;
    }
    if (isValid) {
        form.post(route('people.store'), {
            onFinish: () => form.reset('password'),
        });
    }
};
</script>

<template>

    <Head :title="translations.peopletitle"></Head>
    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <form @submit.prevent="submit" enctype="multipart/form-data">
            <div
                class="mx-auto mt-20 w-4/5 overflow-hidden rounded-lg bg-terciary p-2 px-7 py-8 shadow-md dark:bg-terciary">
                <div>
                    <div class="mb-5 flex flex-col md:flex-row items-center justify-between align-middle">
                        <div>
                            <InputLabel for="name">{{
                                translations.inputname
                                }}</InputLabel>
                            <TextInputPeople id="name" type="text" class="mx-auto mt-1 block w-3/4" v-model="form.name"
                                required autofocus autocomplete="name" :placeholder="translations.placeholdername" />
                            <span id="name-error" class="error-message text-red-500 text-[10px]"></span>
                        </div>
                        <div>
                            <InputLabel for="lastname">{{
                                translations.inputlastname
                                }}</InputLabel>
                            <TextInputPeople id="lastname" type="text" class="mx-auto mt-1 block w-3/4"
                                v-model="form.lastname" required autofocus autocomplete="lastname"
                                :placeholder="translations.placeholderlastname" />
                            <span id="lastname-error" class="error-message text-red-500 text-[10px]"></span>
                        </div>
                        <div>
                            <InputLabel for="birthday">{{
                                translations.inputbirthday
                                }}</InputLabel>
                            <TextInputPeople id="birthday" type="date" min="01-01" max="31-12"
                                class="mx-auto mt-1 block w-3/4" v-model="form.birthday" required autofocus
                                autocomplete="birthday" />
                            <span id="birthday-error" class="error-message text-red-500 text-[10px]"></span>
                        </div>
                        <div>
                            <InputLabel for="relationship">{{
                                translations.inputrelation
                                }}</InputLabel>
                            <select id="relationship" v-model="form.relationship"
                                class="text-black-900 w-64 rounded-lg border border-gray-300 bg-gray-50 text-sm focus:ring-blue-500">
                                <option>{{ translations.option1 }}</option>
                                <option>{{ translations.option2 }}</option>
                                <option>{{ translations.option3 }}</option>
                                <option>{{ translations.option4 }}</option>
                            </select>
                            <span id="relationship-error" class="error-message text-red-500 text-[10px]"></span>
                        </div>
                    </div>
                    <!-- Description -->
                    <div class="mb-5">
                        <InputLabel for="description">{{
                            translations.inputdescription
                            }}</InputLabel>
                        <textarea id="description" rows="3"
                            class="block w-full rounded-lg border border-gray-300 bg-gray-50 p-2.5 text-sm text-gray-900 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-600 dark:placeholder-gray-400 dark:focus:border-blue-500 dark:focus:ring-blue-500"
                            :placeholder="translations.placeholderdescription" v-model="form.description">
                        </textarea>
                        <span id="description-error" class="error-message text-red-500 text-[10px]"></span>
                    </div>

                    <!-- Image -->
                    <div class="mb-5">
                        <InputLabel for="image">{{
                            translations.inputimage
                            }}</InputLabel>
                        <input
                            class="dark:text-black-400 w-100 block cursor-pointer rounded-lg border border-gray-300 bg-gray-50 text-sm text-gray-900 focus:outline-none dark:border-gray-600 dark:bg-mark"
                            aria-describedby="user_avatar_help" id="image" name="image" type="file" accept="image/png"
                            @input="form.image = $event.target.files[0]" />
                    </div>
                    <!-- Button  -->
                    <div>
                        <button type="submit"
                            class="float-right items-center rounded-md border border-transparent bg-[#286067] px-3 py-2 text-xs font-semibold uppercase tracking-widest text-white">
                            {{ translations.submitpeople }}
                        </button>
                        <!-- </Link> -->
                    </div>
                </div>
            </div>
        </form>
    </Sidebar>
</template>
