<script setup>
import { Head } from '@inertiajs/vue3';
import Templates from '@/Layouts/Templates.vue';
import { Link } from '@inertiajs/vue3';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});
</script>
<!-- Progress -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/nprogress/0.2.0/nprogress.min.css" />

<template>
    <Head :title="translations.home" />
    <Templates :translations="translations">
        <div class="min-h-screen">
            <!-- DESKTOP AND TABLET HOME CONTAINER -->
            <div class="home-container mb-10 hidden h-[630px] w-full md:block">
                <div class="flex w-3/4 h-full flex-row justify-between items-center mx-auto">
                    <div class="me-20 flex flex-col">
                        <h1 class="font-headers text-4xl lg:text-5xl text-black me-16">
                            <span class="underline decoration-mark">{{translations.join}}</span> <span class="bg-primary hover:bg-secondary hover:text-mark transition-colors ease-in-out duration-300 text-white p-1 rounded-lg shadow-lg block mt-2 text-center homeResponsive:inline homeResponsive:mt-0">Osiris</span>
                        </h1>
                        <div class="me-3 mt-10 flex flex-row justify-end">
                            <Link :href="route('register')" class="bg-sky-700 hover:bg-sky-400 transition-colors ease-in-out duration-300 rounded-2xl text-white shadow-lg me-10 p-3 text-xl xl:text-2xl font-headers align-middle">{{translations.register}}</Link>
                            <Link :href="route('login')" class="bg-sky-700 hover:bg-sky-400 transition-colors ease-in-out duration-300 rounded-2xl text-white shadow-lg p-3 text-xl xl:text-2xl font-headers align-middle">{{translations.login}}</Link>
                        </div>
                    </div>
                    <div>
                        <img src="/images/home-main.png" alt="Girl sitted in a pc">
                    </div>
                </div>
            </div>
            <!-- MOBILE HOME CONTAINER -->
            <div class="md:hidden w-4/5 mx-auto bg-terciary rounded-lg shadow-lg flex flex-col justify-center mt-4 p-4">
                <h1 class="font-headers text-black text-5xl text-center mb-4">Osiris</h1>
                <Link :href="route('register')" class="bg-sky-400 transition-colors ease-in-out duration-300 rounded-2xl text-white shadow-lg p-3 text-2xl font-headers align-middle w-2/3 mx-auto text-center mb-5">{{translations.register}}</Link>
                <Link :href="route('login')" class="bg-sky-400 transition-colors ease-in-out duration-300 rounded-2xl text-white shadow-lg p-3 text-2xl font-headers align-middle w-2/3 mx-auto text-center">{{translations.login}}</Link>
            </div>
            <!-- SEPARATOR -->
            <div class="min-h-2 w-5/6 rounded-3xl border-b-2 border-mark mx-auto bg-mark mt-3 mb-3"></div>
            <!-- CONTENT -->
            <div class="mx-auto mb-10 mt-5 w-5/6">
                <h2 class="font-headers text-3xl text-black lg:text-4xl">
                    {{ translations.whatis }}
                </h2>
                <div class="card rounded-xl shadow-lg text-md lg:text-lg text-justify text-balance mt-3 p-5">
                    {{ translations.description }}
                </div>
                <br>
                <br>
            </div>
        </div>
    </Templates>
</template>

<script>
export default {
    name: 'Home',
};
</script>
