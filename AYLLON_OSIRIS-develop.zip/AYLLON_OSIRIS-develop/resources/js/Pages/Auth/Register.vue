<script setup>
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInputRegister from '@/Components/TextInputRegister.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import Templates from '@/Layouts/Templates.vue';

const form = useForm({
    firstname: '',
    lastname: '',
    email: '',
    password: '',
    password_confirmation: '',
    password_error:'',
});

const props = defineProps({
    translations: {
        type: Object,
        required: true,
    },
});

const submit = () => {
    const password = form.password;
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    let passwordErr = document.getElementById("password-error");

    if (!regex.test(password)) {
        passwordErr = "La contraseña debe tener al menos 8 caracteres, una letra mayúscula, una letra minúscula y un número.";
        form.password_error=passwordErr;
        return ; 
    } else {
        passwordErr = "";
    }
    
    form.post(route('adduser'), {
        onFinish: () => console.log("queso"),
    });
};

</script>


<template>
    <Head :title="translations.register" />
    <Templates :translations="translations">
        <!-- Title -->
        <h1 class="block font-headers text-gray-700 text-gray-900 grid justify-items-center my-8 text-4xl">
            {{ translations.register }}
        </h1>

        <form @submit.prevent="submit">
            <div
                class="mt-10 w-3/4 md:w-1/2 overflow-hidden bg-terciary px-10 py-10 shadow-md rounded-lg dark:bg-terciary mx-auto ">
                <div class="bg-terciary text-center">
                    <!-- First name -->
                    <div>
                        <InputLabel for="firstname" :value="translations.firstname" />
                        <TextInputRegister id="firstname" type="text" class="mt-1 block w-3/4 mx-auto"
                            v-model="form.firstname" required autofocus autocomplete="firstname" />
                        <InputError class="mt-2" :message="form.errors.name" />
                    </div>
                    <!-- Last name -->
                    <div class="mt-4">
                        <InputLabel for="lastname" :value="translations.lastname" />
                        <TextInputRegister id="lastname" type="text" class="mt-1 block w-3/4 mx-auto"
                            v-model="form.lastname" required autofocus autocomplete="lastname" />
                        <InputError class="mt-2" :message="form.errors.name" />
                    </div>
                    <!-- Email -->
                    <div class="mt-4">
                        <InputLabel for="email" :value="translations.email" />
                        <TextInputRegister id="email" type="email" class="mt-1 block w-3/4 mx-auto" v-model="form.email"
                            required autocomplete="username" />
                        <InputError class="mt-2" :message="form.errors.email" />
                    </div>
                    <!-- Password -->
                    <div class="mt-4">
                        <InputLabel for="password" :value="translations.password" />
                        <TextInputRegister id="password" type="password" class="mt-1 block w-3/4 mx-auto"
                            v-model="form.password" required autocomplete="new-password" @input="validatePassword" />
                        <InputError class="mt-2" :message="form.errors.password" />
                        <span id ="password-error"class="error-message text-red-500 text-[10px]">
                            {{form.password_error}}
                        </span>
                    </div>
                    <!-- Password confirmation -->
                    <div class="mt-4">
                        <InputLabel for="password_confirmation" :value="translations.password_confirmation" />
                        <TextInputRegister id="password_confirmation" type="password" class="mt-1 block w-3/4 mx-auto"
                            v-model="form.password_confirmation" required autocomplete="new-password" />
                        <InputError class="mt-2" :message="form.errors.password_confirmation" />
                    </div>
                </div>

            </div>
            <div class="mt-4 flex items-center justify-center mb-4">
                <Link :href="route('login')"
                    class="rounded-md text-sm text-gray-600 underline hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:text-black dark:hover:text-primary dark:focus:ring-offset-gray-800">
                {{ translations.already_registered }}
                </Link>

                <PrimaryButton class="ms-4" :class="{ 'opacity-25': form.processing }" :disabled="form.processing">
                    {{ translations.submit }}
                </PrimaryButton>
            </div>
        </form>
    </Templates>
</template>