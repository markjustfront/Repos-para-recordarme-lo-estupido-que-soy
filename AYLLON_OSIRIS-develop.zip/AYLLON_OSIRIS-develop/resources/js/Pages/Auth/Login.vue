<script setup>
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import TextInput from '@/Components/TextInputLogin.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import Templates from '@/Layouts/Templates.vue';

defineProps({
    canResetPassword: {
        type: Boolean,
    },
    status: {
        type: String,
    },
    translations: {
        type: Object,
        required: true,
    }
});

const form = useForm({
    email: '',
    password: '',
    remember: false,
});

const loginsubmit = () => {
    form.post(route('login'), {
        onFinish: () => form.reset('password'),
    });
};
</script>

<template>
    <Templates :translations="translations">
        <Head title="Log in" />
        <!-- Login Form -->
        <form @submit.prevent="loginsubmit" class="w-3/4 mx-auto bg-terciary shadow-md rounded-xl flex flex-col mt-5 mb-32 p-10">
            <!-- Login -->
            <div>
               <h1 class="font-headers my-10" >{{ translations.login }}</h1>

                <InputLabel for="email" >{{ translations.loginemail }}</InputLabel> 

                <TextInput
                    id="email" type="email" name="email" class="mt-1 block w-full"
                    v-model="form.email" required autofocus autocomplete="username" placeholder="Introduïu el teu correu electrònic"
                />
                <InputError class="mt-2" :message="form.errors.email" />
            </div>
            <!-- Password -->
            <div class="mt-4 ">
                <InputLabel for="password">{{ translations.loginpassword }}</InputLabel> 
                <TextInput
                    id="password" type="password" name="password" class="mt-1 block w-full"
                    v-model="form.password" required autocomplete="current-password" placeholder="Introduïu la vostra contrasenya"
                />
                <InputError class="mt-2" :message="form.errors.password" />
            </div>

            <div class="mt-4 flex items-center justify-end ">
                <!-- Forget password -->
                <Link
                    v-if="canResetPassword"
                    :href="route('password.request')"
                    class="rounded-md text-sm text-gray-600 underline hover:text-gray-900
                    focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
                    dark:text-gray-400 dark:hover:text-gray-100 dark:focus:ring-offset-gray-800 me-5"
                > 
                    {{ translations.loginforgot }}
                </Link>
                <!-- Button -->
                <button type="submit" class="inline-flex justify-items-center rounded-md border border-transparent bg-primary
                        px-3 py-2 text-xs font-semibold uppercase tracking-widest text-white transition duration-150
                        ease-in-out hover:bg-gray-700 focus:bg-gray-700 focus:outline-none
                        focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 active:bg-primary dark:bg-primary
                        dark:text-white dark:hover:bg-primary dark:focus:bg-white dark:focus:ring-offset-primary
                        dark:active:bg-primary -mr-2 sm:text-base" >{{ translations.loginsubmit }}</button>
            </div>
        </form>
    </Templates>
</template>