<script setup>
import { Head, useForm } from '@inertiajs/vue3';
import Sidebar from '@/Layouts/Sidebar.vue';
import Modal from '@/Components/Modal.vue';
import { reactive, ref } from 'vue';
//calendar
import { Calendar } from 'v-calendar';
import 'v-calendar/style.css';
import axios from 'axios';
import { Inertia } from '@inertiajs/inertia';

// Variables for the modal
const isModalOpen = ref(false);
const openModal = (person) => {
    if (window.innerWidth >= 767) {
        state.name = person.name;
        state.lastname = person.lastname;
        state.birthday = person.birthday;
        state.relationship = person.relationship;
        state.description = person.description;
        state.image = person.image;
        isModalOpen.value = true;
        selectedEntry.value = person;
    }
};
const closeModal = () => {
    isModalOpen.value = false;
};

const selectedEntry = ref(null);
const deleteEntry = async () => {
    if (!selectedEntry.value) return;
    {
        const response = await axios.delete(
            '/people/delete/' + selectedEntry.value.id,
        );
        console.log('Respuesta:', response); // consola

        window.location.reload();
        closeModal();
    }
};

//form
const state = reactive({
    name: '',
    lastname: '',
    birthday: '',
    relationship: '',
    description: '',
    image: '',
});

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
    people: {
        type: Object,
    },
    tasks: {
        type: Object,
        default: () => ({}),
    },
    diary: {
        type: Object,
        required: true,
    },
    user: {
        type: Object,
        required: true,
    },
});

const openDiaryPost = (entryId) => {
    Inertia.get(route('diary.show', { id: entryId }));
};
</script>

<style scoped>
/* Desktop Styles */
.task-square-desktop {
    @apply ml-2 mr-2 mt-4 h-40 max-w-sm flex-col rounded-lg bg-white shadow-md;
    aspect-ratio: 1 / 1;
    /* Ensures the box is square */
}

.task-square-desktop-entries {
    @apply ml-2 mr-2 mt-4 h-64 max-w-sm flex-col rounded-lg bg-white shadow-md;
    aspect-ratio: 1 / 1;
    /* Ensures the box is square */
}

.task-title-container-desktop {
    @apply rounded-t-lg bg-primary;
    /* Rounded corners only at the top */
    width: 100%;
    padding: 0.5rem;
}

.task-title-desktop {
    @apply text-lg font-bold text-notwhite;
    margin: px;
}

.task-content-desktop {
    @apply flex flex-grow flex-col justify-between p-4;
}

.task-description-desktop {
    @apply text-sm text-gray-800;
    margin-bottom: 0.5rem;
}

.task-time-desktop {
    @apply text-xs text-gray-700;
}
</style>

<template>
    <Head title="Dashboard" />
    <Sidebar :translations="translations" :isAdmin="isAdmin">
        <div class="mx-auto w-4/5 bg-notwhite mt-5">
            <!-- Title -->
            <div
                class="col-span-1 mt-2 text-center md:col-span-2 md:text-left lg:col-span-3"
            >
                <h1 class="dtitle font-headers text-2xl md:text-5xl">
                    {{ translations.welcome }} {{ user.firstname }}
                </h1>
            </div>

            <div class="mt-5 flex flex-col md:flex-row justify-between">
                <!-- Tasks -->
                <div
                    class="ms:p-5 me-5 w-full rounded-md bg-white p-2 shadow-md"
                >
                    <h1 class="font-headers">{{ translations.tasktitle }}</h1>
                    <div class="overflow-hidden">
                        <div
                            class="flex space-x-4 overflow-x-auto pb-7"
                            style="max-width: 800px; white-space: nowrap"
                        >
                            <div
                                v-for="task in tasks"
                                :key="task.id"
                                class="h-40 w-64 flex-none"
                            >
                                <div class="task-square-desktop">
                                    <div
                                        class="task-title-container-desktop mb-2"
                                    >
                                        <p class="task-title-desktop font-bold">
                                            {{ task.title }}
                                        </p>
                                    </div>
                                    <div class="task-content-desktop">
                                        <p
                                            class="task-description-desktop text-sm"
                                        >
                                            {{ task.description }}
                                        </p>
                                        <p
                                            class="task-time-desktop text-xs text-gray-600"
                                        >
                                            {{ translations.taskfrom }}
                                            {{ task.start_time }}
                                        </p>
                                        <p
                                            class="task-time-desktop text-xs text-gray-600"
                                        >
                                            {{ translations.taskof }}
                                            {{ task.end_time }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Last diary entries -->
                <div class="w-full md:w-1/3 mt-3 md:mt-0">
                    <div class="w-full bg-white rounded-md shadow-md h-full">
                        <div class="task-title-container-desktop">
                            <p class="task-title-desktop">
                                {{ translations.diarytitle }}
                            </p>
                        </div>
                        <div
                            v-for="entry in diary"
                            @click="openDiaryPost(entry.id)"
                            class="cursor-pointer border-b p-2 text-gray-700 hover:text-secondary"
                        >
                            <p>{{ entry.title }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-5 flex flex-col md:flex-row justify-between">
                <!-- Calendar -->
                <div
                    class="rounded-md bg-white p-2 shadow-md w-full me-5 hidden md:block"
                >
                    <Calendar :columns="2" expanded transparent borderless />
                </div>
                <div
                    class="rounded-md bg-white p-2 shadow-md w-full me-5 md:hidden"
                >
                    <Calendar :columns="1" expanded transparent borderless />
                </div>
                <!-- List of people -->
                <div class="w-full md:w-1/3 mt-3 md:mt-0">
                    <div class="rounded-md bg-white shadow-md p-2 min-h-72">
                        <div class="flex flex-col">
                            <h2 class="font-headers text-primary text-2xl">{{translations.persontitle}}</h2>
                            <div class="flex max-h-64 w-full flex-col overflow-y-scroll overflow-x-hidden">
                                <div v-for="person in people" class="flex flex-row bg-primary text-white rounded-md my-1 font-main p-3 cursor-pointer hover:bg-secondary transition-colors duration-300 ease-in-out items-center" @click="openModal(person)">
                                    <!-- image -->
                                    <img
                                        :src="person.image"
                                        alt="image"
                                        class="mr-2 h-10 w-10 rounded-full border-2 border-white object-cover"
                                    />
                                    <!-- name -->
                                    <div class="ml-7 font-bold text-white">
                                        {{ person.name }} {{ person.lastname }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal for person -->
            <Modal
                :show="isModalOpen"
                @close="closeModal"
                class="notwhite mx-auto overflow-auto my-auto"
            >
                <div
                    class="mx-auto w-1/2 md:w-auto md:max-w-2xl rounded-lg bg-terciary p-6 dark:bg-primary"
                >
                    <div class="space-y-4">
                        <!-- Instateation -->
                        <img
                            :src="state.image"
                            alt="User image"
                            class="max-h-20 max-w-20 md:max-h-80 md:max-w-80 rounded-full mx-auto"
                        />
                        <div class="space-y-3 text-white bg-primary rounded w-4/5 mx-auto p-2">
                            <p>
                                Nombre y apellido : {{ state.name }}
                                {{ state.lastname }}
                            </p>
                            <p>Descripcion: {{ state.description }}</p>
                            <p>Cumple: {{ state.birthday }}</p>
                            <p v-if="state.relationship">
                                Relación: {{ state.relationship }}
                            </p>
                        </div>
                        <!-- Delete button -->
                        <div class="mt-6 flex justify-end border-t border-primary pt-4">
                            <button
                                @click="deleteEntry"
                                class="z-[200] flex cursor-pointer items-center rounded-md bg-red-500 px-4 py-2 text-center text-white transition-colors hover:bg-red-600"
                            >
                                <i class="fa fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </Modal>
        </div>
    </Sidebar>
</template>
