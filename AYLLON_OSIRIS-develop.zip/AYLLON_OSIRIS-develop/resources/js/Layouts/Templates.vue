<script setup>
import NavLink from '@/Components/NavLink.vue';
import { Link, useForm } from '@inertiajs/vue3';
import { ref, onMounted, computed } from 'vue';
import CookieModal from '@/Components/CookieModal.vue';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});

const showCookiePopup = ref(false);

onMounted(() => {
    const cookiesAccepted = localStorage.getItem('cookiesAccepted');
    if (cookiesAccepted !== 'true') {
        showCookiePopup.value = true;
    }
});

const acceptCookies = () => {
    localStorage.setItem('cookiesAccepted', 'true');
    showCookiePopup.value = false;
};

const redirectToCookiesPage = () => {
    showCookiePopup.value = false;
    window.location.href = route('cookie');
};

const form = useForm({
    name: null,
    email: null,
    message: null,
    footer: false,
});

const submit = () => {
    form.post(route('addContact'), {});
    form.reset();
};

const locale = useForm({
    locale: null,
    currentUrl: window.location.pathname,
});

const changeLang = () => {
    locale.post(route('lang_change'), {});
};

const isCookiesPage = computed(() => route().current('cookie'));
</script>

<template>
    <div class="max-h-screen min-h-screen font-main text-black">
        <header
            class="flex min-h-32 flex-row items-center justify-between bg-secondary md:min-h-40"
        >
            <Link
                :href="route('home')"
                aria-label="Home page"
                class="flex w-1/5 flex-row items-center justify-start"
            >
                <img
                    src="/detailed-logo.png"
                    alt="osiris logo, a small yellow and blue sun"
                    aria-label="osiris logo, a small yellow and blue sun"
                    class="max-h-20 min-h-20 min-w-20 max-w-20 lg:max-h-24 lg:min-h-24 lg:min-w-24 lg:max-w-24"
                />
                <h1
                    class="hidden font-headers text-5xl text-black md:block lg:block"
                >
                    Osiris
                </h1>
            </Link>
            <nav
                class="flex w-2/5 items-center justify-end md:w-3/5 md:flex-row"
            >
                <div class="me-3 hidden md:block">
                    <label for="changeLanguages" class="me-2 hidden md:inline">
                        {{ translations.chooseLanguage }}
                    </label>
                    <select
                        name="changeLanguages"
                        v-model="locale.locale"
                        @change="changeLang"
                        class="w-1/5 rounded-xl bg-primary font-main text-white md:w-1/3"
                        aria-label="change language"
                    >
                        <option
                            value="en"
                            class="transition-colors duration-300 ease-in-out hover:bg-terciary hover:text-black"
                        >
                            English
                        </option>
                        <option
                            value="es"
                            class="transition-colors duration-300 ease-in-out hover:bg-terciary hover:text-black"
                        >
                            Español
                        </option>
                        <option
                            value="ca"
                            class="transition-colors duration-300 ease-in-out hover:bg-terciary hover:text-black"
                        >
                            Català
                        </option>
                    </select>
                </div>
                <nav-link
                    :href="route('about')"
                    :active="route().current('about')"
                    >{{ translations.about }}</nav-link
                >
                <nav-link
                    :href="route('contact')"
                    :active="route().current('contact')"
                    >{{ translations.contact }}</nav-link
                >
            </nav>
        </header>
        <main>
            <slot />
        </main>
        <footer
            class="absolute flex min-h-36 w-full flex-row justify-between divide-x-2 bg-terciary p-3 md:min-h-60"
        >
            <div
                class="flex min-h-full w-1/2 flex-col justify-center p-2 text-left md:w-1/3"
            >
                <div class="md:hidden">
                    <label for="changeLanguages" class="me-2 inline">
                        {{ translations.chooseLanguage }}
                    </label>
                    <select
                        name="changeLanguages"
                        v-model="locale.locale"
                        @change="changeLang"
                        class="w-1/5 rounded-xl bg-primary font-main text-white md:w-1/3"
                        aria-label="change language"
                    >
                        <option
                            value="en"
                            class="transition-colors duration-300 ease-in-out hover:bg-terciary hover:text-black"
                        >
                            English
                        </option>
                        <option
                            value="es"
                            class="transition-colors duration-300 ease-in-out hover:bg-terciary hover:text-black"
                        >
                            Español
                        </option>
                        <option
                            value="ca"
                            class="transition-colors duration-300 ease-in-out hover:bg-terciary hover:text-black"
                        >
                            Català
                        </option>
                    </select>
                </div>
                <Link
                    :href="route('terms')"
                    class="break-all rounded p-1 transition duration-150 ease-in-out hover:bg-mark hover:shadow-md hover:shadow-primary"
                >
                    {{ translations.terms }}
                </Link>
                <Link
                    :href="route('cookie')"
                    class="break-all rounded p-1 transition duration-150 ease-in-out hover:bg-mark hover:shadow-md hover:shadow-primary"
                >
                    {{ translations.cookies }}
                </Link>
                <Link
                    :href="route('about')"
                    class="break-all rounded p-1 transition duration-150 ease-in-out hover:bg-mark hover:shadow-md hover:shadow-primary"
                >
                    {{ translations.aboutus }}
                </Link>
                <a
                    href="https://www.svgbackgrounds.com/set/free-svg-backgrounds-and-patterns/"
                    class="break-all rounded p-1 transition duration-150 ease-in-out hover:bg-mark hover:shadow-md hover:shadow-primary"
                >
                    SVGBackgrounds.com
                </a>
            </div>
            <div
                class="flex min-h-full w-1/2 items-center justify-center md:w-1/3"
            >
                <form
                    class="flex w-full flex-col items-center justify-center"
                    @submit.prevent="submit"
                >
                    <h3 class="font-headers text-lg">
                        {{ translations.contact }}
                    </h3>
                    <label for="name">{{ translations.name }}</label>
                    <input
                        type="text"
                        v-model="form.name"
                        placeholder="John"
                        id="name"
                        name="name"
                        class="relative w-3/4 rounded border-0 bg-notwhite px-3 py-3 text-sm text-gray-600 placeholder-gray-400 shadow outline-none focus:outline-none focus:ring"
                        required
                    />
                    <label for="emailfooter">{{ translations.email }}</label>
                    <input
                        type="email"
                        v-model="form.email"
                        placeholder="john@doe.co"
                        id="emailfooter"
                        name="emailfooter"
                        class="relative w-3/4 rounded border-0 bg-notwhite px-3 py-3 text-sm text-gray-600 placeholder-gray-400 shadow outline-none focus:outline-none focus:ring"
                        required
                    />
                    <label for="message">{{ translations.message }}</label>
                    <input
                        type="text"
                        v-model="form.message"
                        placeholder="Bli bli bla bla blu"
                        id="message"
                        name="message"
                        class="relative min-h-6 w-3/4 rounded border-0 bg-notwhite px-3 py-3 text-sm text-gray-600 placeholder-gray-400 shadow outline-none focus:outline-none focus:ring"
                        required
                    />
                    <button
                        class="mb-1 mr-1 mt-2 inline-flex w-3/4 justify-center rounded bg-[#286067] px-6 py-3 text-sm font-bold uppercase text-white shadow outline-none transition-all duration-150 ease-linear hover:bg-secondary hover:shadow-lg focus:outline-none"
                        type="submit"
                        :disabled="form.processing"
                    >
                        {{ translations.submit }}
                    </button>
                </form>
            </div>
            <div
                class="hidden min-h-full w-1/3 items-center justify-center md:flex md:flex-col"
            >
                <Link :href="route('home')" aria-label="Home page">
                    <img
                        class="transition-all duration-300 ease-in-out md:max-h-36 md:max-w-36 hover:md:max-h-40 hover:md:max-w-40"
                        src="/detailed-logo.png"
                        alt="Osiris logo, go back to home"
                    />
                </Link>
                <div class="ms-2 mt-4 flex w-full flex-row justify-center">
                    <a
                        target="_blank"
                        href="https://www.instagram.com/osiris_planner/"
                        aria-label="Home page"
                        ><i
                            class="fa-brands fa-instagram mx-2 text-4xl transition-all duration-300 ease-in-out hover:text-6xl hover:text-mark"
                        ></i
                    ></a>
                    <a
                        target="_blank"
                        href="https://x.com/Osiris_planner"
                        aria-label="Home page"
                        ><i
                            class="fa-brands fa-x-twitter mx-2 text-4xl transition-all duration-300 ease-in-out hover:text-6xl hover:text-mark"
                        ></i
                    ></a>
                </div>
            </div>
        </footer>
        <CookieModal
            v-if="showCookiePopup && !isCookiesPage"
            :translations="translations"
            @accept="acceptCookies"
            @redirect="redirectToCookiesPage"
        />
    </div>
</template>

<script>
export default {
    name: 'Templates',
};
</script>

<style lang="scss">
@import '@fortawesome/fontawesome-free/css/all.css';
</style>
