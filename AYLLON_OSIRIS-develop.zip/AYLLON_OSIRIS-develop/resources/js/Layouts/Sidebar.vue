<script setup>
import { ref } from 'vue';
import { Link } from '@inertiajs/vue3';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
    isAdmin: {
        type: Boolean,
        required: true,
    },
});

const isSidebarOpen = ref(false);

const toggleSidebar = () => {
    isSidebarOpen.value = !isSidebarOpen.value;
};

const closeSidebar = () => {
    isSidebarOpen.value = false;
};
</script>

<template>
    <div class="relative flex h-screen">
        <!-- Overlay to close the sidebar if it is clicked outside -->
        <div
            v-if="isSidebarOpen"
            @click="closeSidebar"
            class="fixed inset-0 z-40 bg-black bg-opacity-50 md:hidden"
        ></div>

        <!-- Sidebar -->
        <aside
            :class="[
                'fixed z-50 flex h-screen w-64 flex-col bg-terciary transition-all duration-300 md:fixed',
                isSidebarOpen
                    ? 'translate-x-0'
                    : '-translate-x-full md:translate-x-0',
            ]"
        >
            <Link
                :href="route('home')"
                class="flex h-20 items-center bg-secondary px-4 transition-all duration-300 hover:underline hover:decoration-mark"
            >
                <img
                    src="/detailed-logo.png"
                    alt="Logo"
                    class="mr-2 h-12 w-12"
                />
                <span class="font-headers text-4xl font-bold text-black"
                    >Osiris</span
                >
            </Link>

            <!-- Sidebar -->
            <nav class="mt-4 flex flex-col font-main text-lg">
                <Link
                    :href="route('dashboard')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white"
                >
                    <i class="fa fa-home mr-3"></i>
                    {{ translations.Dashboard }}</Link
                >
                <Link
                    :href="route('diary')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white"
                >
                    <i class="fas fa-book mr-4"></i> {{ translations.Diary }}
                </Link>

                <Link
                    :href="route('people')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white"
                >
                    <i class="fas fa-user-friends mr-4"></i>
                    {{ translations.people }}
                </Link>

                <Link
                    :href="route('workspace')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white"
                >
                    <i class="fas fa-file-alt mr-4"></i>
                    {{ translations.Workspace }}
                </Link>

                <div class="hover:bg-mark focus:bg-mark focus:text-white">
                    <Link
                        :href="route('upload')"
                        class="ml-5 flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:text-white"
                    >
                        <i class="fas fa-upload mr-4"></i>
                        {{ translations.Upload }}
                    </Link>
                </div>

                <Link
                    :href="route('study')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white"
                >
                    <i class="fas fa-pencil-alt mr-4"></i>
                    {{ translations.Study }}
                </Link>
                <Link
                    :href="route('tasks.index')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white"
                >
                    <i class="fas fa-tasks mr-4"></i> {{ translations.Tasks }}
                </Link>

                <div class="hover:bg-mark focus:bg-mark focus:text-white">
                    <Link
                        :href="route('tasks.create')"
                        class="ml-5 flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:text-white"
                    >
                        <i class="fas fa-plus mr-4"></i>
                        {{ translations.Create }}
                    </Link>
                </div>
                <div v-if="isAdmin" class="hover:bg-mark focus:bg-mark focus:text-white">
                    <Link
                        :href="route('admin')"
                        class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:text-white"
                    >
                        <i class="fas fa-user-cog mr-4"></i>
                        Admin
                    </Link>
                </div>
                <div class="fixed bottom-5 flex w-full flex-col justify-end">
                    <div class="flex w-full flex-row justify-end">
                        <Link
                            :href="route('profile.edit')"
                            class="me-5 text-xl text-black hover:text-mark"
                            aria-label="user"
                            ><i class="fas fa-user"></i
                        ></Link>
                        <a
                            href="/logout"
                            class="me-3 text-2xl text-black hover:text-mark"
                            aria-label="logout"
                            ><i class="fas fa-sign-out-alt"></i
                        ></a>
                    </div>
                </div>
            </nav>
        </aside>
        <main class="min-h-screen h-fit w-full mr-0 md:ml-64 bg-notwhite relative">
            <slot></slot>
        </main>
        <!-- Button for small screens -->
        <button
            v-if="!isSidebarOpen"
            @click="toggleSidebar"
            aria-label="Open sidebar on mobile"
            class="absolute right-9 top-5 z-50 rounded-md bg-secondary opacity-75 p-3 text-black shadow-lg transition-all duration-200 hover:bg-opacity-80 md:hidden"
        >
            <i class="fas fa-bars text-2xl"></i>
        </button>
    </div>
</template>

<style lang="scss">
@import '../../../node_modules/@fortawesome/fontawesome-free/css/all.css';
</style>
