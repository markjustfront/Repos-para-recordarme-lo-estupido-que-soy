<script setup>
import { ref } from 'vue';
import { Link, router } from '@inertiajs/vue3';

defineProps({
    translations: {
        type: Object,
        required: true,
    },
});

const isSidebarOpen = ref(false);

const toggleSidebar = () => {
    isSidebarOpen.value = !isSidebarOpen.value;
};

const closeSidebar = () => {
    isSidebarOpen.value = false;
};
</script>

<template>
    <div class="relative flex h-screen">
        <!-- Overlay to close the sidebar if it is clicked outside -->
        <div v-if="isSidebarOpen" @click="closeSidebar" class="fixed inset-0 z-40 bg-black bg-opacity-50 md:hidden">
        </div>

        <!-- Sidebar -->
        <aside :class="[
            'fixed z-50 flex h-screen w-64 flex-col bg-terciary transition-all duration-300 md:relative',
            isSidebarOpen
                ? 'translate-x-0'
                : '-translate-x-full md:translate-x-0',
        ]">
            <Link :href="route('home')" class="flex h-20 items-center bg-secondary px-4 hover:underline hover:decoration-mark transition-all duration-300">
                <img src="/detailed-logo.png" alt="Logo" class="mr-2 h-12 w-12" />
                <span class="font-headers text-4xl font-bold text-black">Osiris</span>
            </Link>

            <!-- Sidebar -->
            <nav class="mt-4 flex flex-col font-main text-lg">
                <Link :href="route('admin')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white">
                <i class="fa fa-home mr-3"></i> {{ translations.Dashboard }}</Link>
                <Link :href="route('admin.translations')"
                    class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white">
                <i class="fas fa-globe-europe mr-4"></i> {{ translations.translations }}
                </Link>
                <Link :href="route('dashboard')"
                      class="flex w-full items-center px-4 py-3 font-main text-black transition duration-200 hover:bg-mark hover:text-white focus:bg-mark focus:text-white">
                    <i class="fa fa-user mr-3"></i> {{ translations.user_dashboard }}</Link>
            </nav>
        </aside>
        <main class="w-full h-full bg-notwhite">
            <slot></slot>
        </main>
        <!-- Button for small screens -->
        <button
            v-if="!isSidebarOpen"
            @click="toggleSidebar"
            aria-label="Open sidebar on mobile"
            class="absolute right-9 top-5 z-50 rounded-md bg-secondary opacity-75 p-3 text-black shadow-lg transition-all duration-200 hover:bg-opacity-80 md:hidden"
        >
            <i class="fas fa-bars text-2xl"></i>
        </button>
    </div>
</template>

<style lang="scss">
@import '../../../node_modules/@fortawesome/fontawesome-free/css/all.css';
</style>
