import axios from 'axios';
import { describe, expect, it } from 'vitest';

describe('Yes or No API', () => {
    it('Should return "yes"', async () => {
        // API  call forcing yes as the answer
        const response = await axios.get('https://yesno.wtf/api?force=yes', {});

        expect(response.data.answer).toBe('yes');
    });
});
