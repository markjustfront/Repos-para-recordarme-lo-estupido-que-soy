import Test from '@/Components/Test.vue';
import { mount } from '@vue/test-utils';

describe('Test.vue', () => {
    it('Should render the correct title', () => {
        const wrapper = mount(Test);

        wrapper.vm.$nextTick();
        // Verify "Osiris" is in the component
        expect(wrapper.text()).toBe('Osiris');
    });
});
