import About from '@/Pages/About.vue';
import { mount } from '@vue/test-utils';
import { vi } from 'vitest';

// mock: Child component
vi.mock('@/Layouts/Templates.vue', () => ({
    // vi.mock: instead of using the real component we make a mock version
    default: {
        name: 'Templates',
        template: '<div><slot /></div>',
    },
}));

vi.mock('@inertiajs/vue3', () => ({
    // Mock the Head component from Inertia
    Head: {
        name: 'Head',
        render: () => null, // Just return null because it doesn't need to render anything in the test
    },
    createInertiaApp: vi.fn().mockReturnValue({
        app: {
            component: 'MockComponent',
        },
    }),
}));

describe('About.vue', () => {
    const translationsByLanguage = {
        es: {
            title: 'Título',
        },
        ca: {
            title: 'Títol',
        },
        en: {
            title: 'Title',
        },
    };

    // Each language test
    Object.entries(translationsByLanguage).forEach(([lang, translations]) => {
        it(`Should render the correct tile for ${lang}`, () => {
            const wrapper = mount(About, {
                props: {
                    translations,
                },
                global: {
                    plugins: [], // Add Inertia provider here
                },
            });
            wrapper.vm.$nextTick();

            // Verify the title sjpws up
            expect(wrapper.html()).toContain(translations.title);
        });
    });
});
