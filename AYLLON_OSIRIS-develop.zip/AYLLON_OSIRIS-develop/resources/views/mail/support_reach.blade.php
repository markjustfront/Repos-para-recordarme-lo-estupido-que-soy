<h1 style="font-size: large">Please contact: {{ $contactData["name"] }}</h1>
<p>Message: {{ $contactData["message"] }}</p>
<br>
<p>Send message to: {{ $contactData["email"] }}</p>
