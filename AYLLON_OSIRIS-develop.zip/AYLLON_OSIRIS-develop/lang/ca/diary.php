<?php

return [
    'diary' => 'Diari',
    'confirmti' => 'Estàs segur de desar aquesta informació?',
    'confirmte' => 'Aquesta informació es desarà a la base de dades',
    'placeholder' => 'Escriu aquí...',
    'error' => 'Error',
    'Save' => 'Desar',
    'Last' => 'Últimes Entrades',
    'See' => 'Més',
    'cancel' => 'Cancel·lar',
    'accept' => 'Acceptar',
    'close' => 'Tancar',
    'delete' => 'Esborrar',
    'previous' => 'Anterior',
    'next' => 'Següent',
    'allEntriesTitle' => 'Totes les Entrades',
    'open' => 'Obrir',
    'posts' => 'Entrada',
    'edit' => 'Editar',
    
];
