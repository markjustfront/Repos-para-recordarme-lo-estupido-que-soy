<?php
return [
    'title' => 'Perfil',
    'profile_information' => 'Informació del perfil',
    'text_update_info' => 'Actualitza el teu nom o correu',
    'name' => 'Nom',
    'last_name' => 'Cognom',
    'email' => 'Email',
    'save' => 'Desa',
    'saved' => 'Desat',
    'update_password' => 'Actualitza la contrasenya',
    'text_update_password' => 'Assegura\'t de fer servir una contrasenya segura',
    'current_password' => 'Contrasenya actual',
    'new_password' => 'Nova Contrasenya',
    'confirm_password' => 'Confirmar Contrasenya',
    'delete_account' => 'Eliminar compte',
    'text_delete_account' => 'Un cop eliminat el teu compte tot el teu contingut serà esborrat permanentment. Abans d\'esborrar el teu compte descarrega\'t els fitxers que vulguis mantenir.',
    'edit' => 'Editar perfil',
    'sure' => 'Esteu segur que voleu suprimir el vostre compte?',
    'text_sure' => 'Un cop eliminat el vostre compte, tots els seus recursos i dades s\'eliminaran permanentment. Introduïu la contrasenya per confirmar que voleu suprimir permanentment el vostre compte.',
    'password' => 'Contrasenya'
];
