<?php

return [
    'name' => 'Nom:',
    'email' => 'Correu electrònic:',
    'message' => 'Missatge:',
    'submit' => 'Enviar',
    'confirmation' => 'Enviat!',
    'confirmation_thanks' => 'Moltes gràcies',
    'confirmation_message' => 'Ens posarem en contacte amb u al mes aviat possible.',
];

