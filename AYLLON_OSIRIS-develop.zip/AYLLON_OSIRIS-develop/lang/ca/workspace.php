<?php

return [
    "workspace"=> "Espai de Treball",
    "search" => "Buscar arxiu...",
    "read" => "Llegir",

];
