<?php
return[
    'peopletitle' => 'Afegir persones',
    'inputname' => "Nom",
    'placeholdername' => "Escriu el nom...",
    'inputlastname' => "Cognom",
    'placeholderlastname' => "Escriu el cognom...",
    'inputdescription' => "Descripció",
    'placeholderdescription' => "Descripció de la persona...",
    'inputbirthday' => "Aniversari",
    'inputrelation' => "Relació",
    'option1' => "Amic",
    'option2' => "Familiar",
    'option3' => "Company",
    'option4' => "Conegut",
    'inputimage' => "Imatge",
    'submitpeople' => "Envia",
];
