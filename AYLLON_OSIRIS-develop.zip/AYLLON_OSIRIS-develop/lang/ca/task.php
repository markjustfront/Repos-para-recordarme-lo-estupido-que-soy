<?php

return [
    'tasks' => 'Tasques',
    'title' => 'Tasques',
    'subtitle' => 'Afegeix aquí les teves tasques',
    'tasktitle' => 'Títol',
    'description' => 'Descripció',
    'start_time' => 'Data d\'inici',
    'end_time' => 'Data de fi',
    'addTask' => 'Afegir tasca',
    'from' => 'De',
    'to' => 'fins',
    'finish' => 'Acaba la tasca',
];
