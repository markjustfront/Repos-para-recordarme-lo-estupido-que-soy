<?php
return [
    'title' => 'Traduccions',
    'save' => 'Guardar',
    'key' => 'Identificador',
    'open_in_pc' => 'Siusplau obre aquesta pàgina desde un ordinador.',
];
