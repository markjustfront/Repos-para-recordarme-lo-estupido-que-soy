<?php
return [
    'title' => 'Sobre Nosaltres',
    'team' => 'Equip',
    'team_members' => [
        '1' => [
            "name" => "Marc",
            "description" => "Amb un enfocament analític, en Marc garanteix la qualitat i l'eficiència en cada detall del projecte.",
            "image" => "/images/marc.png",
        ],
        '2' => [
            "name" => "Mounia",
            "description" => "Experta en disseny i experiència d'usuari, la Mounia transforma idees en interfícies intuïtives i atractives.",
            "image" => "/images/mounia.png",
        ],
        '3' => [
            "name" => "Mateo",
            "description" => "Apassionat per la innovació, en Mateo lidera el desenvolupament tècnic amb una visió estratègica i creativa.",
            "image" => "/images/mateo.png",
        ],
        '4' => [
            "name" => "Carolina",
            "description" => "Organitzada i empàtica, la Carolina gestiona l'equip amb entusiasme i una comunicació impecable.",
            "image" => "/images/carolina.png",
        ],
        '5' => [
            "name" => "Denis",
            "description" => "Enginyós i resolutiu, en Denis aporta solucions tècniques amb un enfocament sempre pràctic.",
            "image" => "/images/denis.png",
        ],
    ],
    'about_text' => 'Som un equip orgullós de joves programadors web que busquen la solució a l`organització de la vida d`un mateix. Estem ansiosos per mostrar al món el que es pot aconseguir quan pots planificar amb antelació les teves tasques i esdeveniments del dia a dia. La nostra visió reflecteix la llarga experiència de no saber què fer quan comença el dia. Amb l`aplicació que oferim als nostres clients, pretenem fer-los la vida més fàcil assegurant-nos que tot el que necessitin fer en el seu dia a dia es pugui organitzar perquè puguin tenir menys estrès durant les seves vides. Osiris va ser concebut una tarda els primers dies després de la nit de Cap d`Any, estàvem decidits a solucionar un problema del nostre món modern, i després de llargues hores de pensament i pluja d`idees vam tenir la idea després que un de nosaltres deixés de pensar en resoldre aquests problemes i es posés nerviós perquè estava pensant en el que havia de fer aquell dia a la nit i el que va seguir al matí següent.',
];
