<?php
return [
    'login' => 'Iniciar sessió',
    'loginemail' => "Correu electrònic",
    'loginpassword' => "Contrasenya",
    'loginforgot' => "Has olvidat la teva contrasenya?",
    'loginsubmit' => "Envia",
    ];
