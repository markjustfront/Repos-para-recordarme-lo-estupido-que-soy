<?php

return [
    'start' => 'Comença',
    'pause' => 'Pausa',
    'resume' => 'Segueix',
    'stop' => 'Para',
    'series' => 'Sèries:',
    'pomodoro' => 'Aquest comptador de temps fa servir el mètode pomodoro. Aquest mètode consisteix a fer un número de sèries dividides per iteracions, aquestes iteracions són 4 períodes de 25 minuts d\'estudi acompanyats per 5 minuts de descans. A l\'acabar els 4 periodes hi ha un descans de 15 minuts. En el selector de sèries pots seleccionar fer fins a 3 sèries de 4 iteracions cadascuna fent possible fins a 6 hores i mitja d\'estudi.',
    'ai_whatis' => 'Processar Text amb IA',
    'ai_writehere' => 'Escriu el teu text aquí...',
    'ai_short' => 'Resumir',
    'ai_studyplan' => 'Pla d\'estudi',
    'ai_generating' => 'Generant resposta...',
    'ai_response' => 'Resposta:',
    'ai_close' => 'Tanca'
];
