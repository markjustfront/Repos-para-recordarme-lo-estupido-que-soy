<?php

return [
    "upload"=> "Pujar arxiu"
    
];