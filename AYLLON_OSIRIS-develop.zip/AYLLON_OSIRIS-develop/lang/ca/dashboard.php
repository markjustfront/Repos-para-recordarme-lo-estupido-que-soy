<?php
return[
    'welcome' => 'Benvingut/da',
    'tasktitle' => 'Properes tasques',
    'taskfrom' => 'de',
    'taskof' =>  'a',
    'diarytitle' => 'Darreres entradas',
    'persontitle' => 'Persones',
    'modalname' => 'Nom i cognoms:',
    'modaldescription' => 'Descripció:',
    'modalbirthday' => 'Aniversari:',
    'modalrelation' => 'Relació:',
];
