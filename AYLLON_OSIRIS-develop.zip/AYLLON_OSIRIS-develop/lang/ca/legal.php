<?php

return [
    "title1" => "Avís Legal",
    "legalnotice" => '<h1 class="block font-headers text-gray-700 text-gray-900 grid justify-items-center my-8 text-4xl">Avís Legal</h1>
    <ol class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Informació del Responsable del Lloc Web</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">De conformitat amb el que disposa la Llei 34/2002, d\'11 de juliol, de Serveis de la Societat de la Informació i de Comerç Electrònic (LSSICE), s\'informa del següent:</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Responsable: Osiris</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Adreça: c/Arquitecte Pelai Martínez, 1, 17600, Figueres, Espanya</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Correu electrònic de contacte: osiris@email.com</span></p>
    <p>&nbsp;</p>

    <ol start="2" class="list-decimal"><li class="font-extrabold text-mark"><strong>Descripció dels Serveis</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Osiris és una plataforma en línia dissenyada per ajudar els usuaris a organitzar i gestionar els seus estudis o activitats de lectura de manera eficient. Els serveis inclouen:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Registre d\'usuaris mitjançant nom, cognom i correu electrònic.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Creació i gestió de tasques diàries.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Accés a un calendari d\'activitats.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Pujada i emmagatzematge d\'arxius PDF.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Cronòmetre per controlar el temps d\'estudi o lectura.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Registre d\'informació addicional, incloent noms, cognoms i imatges d\'altres persones.</span></li>
    <p>&nbsp;</p>
    
    <ol start="3" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Condicions d\'Ús</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">L\'accés i ús del lloc web Osiris estan subjectes a les següents condicions:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Els usuaris es comprometen a proporcionar informació veritable i actualitzada durant el procés de registre.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Els usuaris són responsables d\'obtenir el consentiment explícit de les persones les dades i imatges de les quals pugin a la plataforma, conforme a les normatives de protecció de dades.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Està prohibit l\'ús de la plataforma per a fins il·legals o no autoritzats.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">L\'empresa es reserva el dret de modificar o interrompre el servei sense previ avís.</span></p>
    <p>&nbsp;</p>

    <ol start="4" class="list-decimal"><li class="font-extrabold text-mark"><strong>Protecció de Dades Personals</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">De conformitat amb el Reglament (UE) 2016/679 del Parlament Europeu i del Consell, de 27 d\'abril de 2016, relatiu a la protecció de les persones físiques (RGPD) i la Llei Orgànica 3/2018, de 5 de desembre, de Protecció de Dades Personals i garantia dels drets digitals (LOPDGDD), s\'informa del següent:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Les dades personals recopilades a través d\'aquest lloc web s\'utilitzaran únicament per proporcionar els serveis oferts.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Els usuaris podran pujar dades personals de tercers (com noms, cognoms i imatges) només si compten amb el consentiment exprés d\'aquests tercers.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Els usuaris podran exercir els seus drets d\'accés, rectificació, supressió, oposició, limitació del tractament i portabilitat de les seves dades enviant una sol·licitud a osiris@email.com.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Per obtenir més informació sobre el tractament de dades, consulti la nostra [Política de Privacitat].</span></p>
    <p>&nbsp;</p>

    <ol start="5" class="list-decimal"><li class="font-extrabold text-mark"><strong>Ús de Cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Aquest lloc web pot utilitzar cookies per millorar l\'experiència de l\'usuari. Navegant pel lloc, accepta l\'ús de cookies segons es descriu a la nostra [Política de Cookies]. Els usuaris poden configurar els seus navegadors per rebutjar les cookies.</span></p>
    <p>&nbsp;</p>

    <ol start="6" class="list-decimal"><li class="font-extrabold text-mark"><strong>Propietat Intel·lectual</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Tot el contingut, disseny, logotips, textos i gràfics del lloc web són propietat d\'Osiris i estan protegits per les lleis de propietat intel·lectual. Queda prohibida la reproducció, distribució o modificació sense autorització expressa.</span></p>
    <p>&nbsp;</p>

    <ol start="7" class="list-decimal"><li class="font-extrabold text-mark"><strong>Limitació de Responsabilitat</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Osiris no es fa responsable dels danys i perjudicis derivats del mal ús de la plataforma, interrupcions del servei o errors en els continguts proporcionats. Els usuaris són responsables del contingut que pugin, especialment si inclou dades personals de tercers sense el degut consentiment.</span></p>
    <p>&nbsp;</p>

    <ol start="8" class="list-decimal"><li class="font-extrabold text-mark"><strong>Legislació Aplicable i Jurisdicció</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Aquestes condicions es regeixen per la legislació espanyola. Per a la resolució de qualsevol disputa que pogués sorgir de l\'accés o ús d\'aquest lloc web, les parts se sotmeten als jutjats i tribunals de Figueres, Espanya, llevat que la llei disposi una altra cosa.</span></p>'

    
];