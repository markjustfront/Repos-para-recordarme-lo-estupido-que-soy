<?php

return [
    'forgot' => 'Recuperar contrasenya',
    'forgot_long' => 'Has oblidat la teva contrasenya? No hi ha problema. Només fes-nos saber la teva adreça de correu electrònic i t\'enviarem un enllaç per restablir la contrasenya que et permetrà triar-ne una de nova.',
    'recovery_email' => 'Envia el correu de recuperació'
];

