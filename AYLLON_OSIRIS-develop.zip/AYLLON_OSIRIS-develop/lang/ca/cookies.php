<?php

return [
    "cookies_policy" => '<h1 class="font-headers text-gray-900 grid justify-items-center my-8 text-4xl">Política de Cookies</h1>
    <p>&nbsp;</p>

    <ol class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Què són les cookies?</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Les cookies són petits fitxers de text que es descarreguen i emmagatzemen al teu dispositiu (ordinador, tauleta, smartphone, etc.) quan accedeixes a determinats llocs web. Permeten que el lloc web recordi informació sobre la teva visita, com ara les teves preferències i configuracions, per millorar la teva experiència d\'usuari.</span></p>
    <p>&nbsp;</p>

    <ol start="2" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Tipus de cookies que utilitzem</strong></li></ol>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;"><strong>Cookies pròpies:</strong> Són aquelles que s’envien al teu dispositiu des dels nostres propis servidors o dominis i des de les quals prestem el servei sol·licitat.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies de tercers:</strong> Són aquelles que s’envien al teu dispositiu des d’un domini o servidor que no és gestionat per nosaltres, sinó per una altra entitat que tracta les dades obtingudes a través de les cookies.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies de sessió:</strong> Són temporals i desapareixen en tancar el navegador.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies persistents:</strong> Romanen al teu dispositiu durant un període determinat o fins que les eliminis manualment.</span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="3" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Per a què utilitzem les cookies?</strong></li></ol>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;"><strong>Cookies tècniques:</strong> Necessàries per al funcionament correcte del lloc web.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies de personalització:</strong> Permeten recordar les teves preferències com l\'idioma o la configuració de la pàgina.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies d\'anàlisi:</strong> Ens ajuden a entendre com interactuen els usuaris amb el lloc web, millorant els nostres serveis.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies publicitàries:</strong> Serveixen per mostrar anuncis rellevants en funció dels teus interessos.</span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="4" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Gestió de les cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Pots permetre, bloquejar o eliminar les cookies mitjançant la configuració del teu navegador. A continuació, t\'oferim informació sobre com fer-ho en els navegadors més populars:</span></p>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;">Google Chrome: <a href="https://support.google.com/chrome/answer/95647" target="_blank">support.google.com</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Mozilla Firefox: <a href="https://support.mozilla.org/ca/kb/Galetes" target="_blank">support.mozilla.org</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Microsoft Edge: <a href="https://support.microsoft.com/" target="_blank">support.microsoft.com</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Safari: <a href="https://support.apple.com/ca-es/guide/safari/sfri11471/mac" target="_blank">support.apple.com</a></span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="5" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Canvis en la política de cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Ens reservem el dret d\'actualitzar aquesta política de cookies en qualsevol moment. Es recomana revisar-la periòdicament per estar informat de possibles canvis.</span></p>
    <p>&nbsp;</p>

    <ol start="6" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Contacte</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Si tens qualsevol dubte o consulta sobre la nostra política de cookies, pots contactar-nos a través del correu electrònic: <a href="mailto:osiris@email.com">osiris@email.com</a>.</span></p>
    <p>&nbsp;</p>
    '
];
