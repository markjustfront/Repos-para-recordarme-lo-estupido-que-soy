<?php

return [
    "adminpanel" => "Panell d'administrador",
    "users" => "Usuaris",
    "generate" => "Genera",
    "admin" => "Administrador",
    "manager" => "Manager",
    "user" => "Usuari",
    "messages" => "Missatges",
];
