<?php

return [
    'home' => 'Inici',
    'about' => 'Nosaltres',
    'contact' => 'Contacte',
    'terms' => 'Condicions d\'ús',
    'cookies' => 'Galetes',
    'aboutus' => 'Sobre nosaltres',
    'cookies_title' => 'Galetes',
    'cookies_text' => "Aquest lloc web utilitza galetes per garantir el seu correcte funcionament i millorar la teva experiència d'usuari. En fer clic a 'Acceptar', consenteixes l'ús de galetes. Per a més informació",
    'more_info' => 'clic aquí',
    'accept' => 'Acceptar',
    'reject' => 'Rebutjar',
    'chooseLanguage' => 'Canvia l\'idioma:',
    
];

