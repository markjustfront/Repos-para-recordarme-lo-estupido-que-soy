<?php

return [
    'join' => 'Uneix-te a',
    'register' => 'Uneix-te',
    'login' => 'Entra',
    'whatis' => 'Què és Osiris?',
    'description' => 'Osiris és el teu company de productivitat definitiu, dissenyat per ajudar-te a organitzar el teu dia amb facilitat i eficiència. Crea tasques, organitza el teu temps i mantén-te al dia amb mètodes d\'estudi personalitzables. Amb Osiris, pots pujar i accedir a arxius PDF directament, assegurant que els teus recursos estiguin sempre a mà. L\'app també inclou un diari integrat que et permet documentar els teus assoliments diaris i reflexions. Pots associar les entrades del diari amb persones de la teva vida, afegint un toc personal i ajudant-te a enfortir les teves connexions. Simplifica el teu flux de treball, augmenta la teva productivitat i guarda els teus records amb Osiris.',
];
