<?php

return [
    "register" => "Registrar",
    "firstname" => "Nom",
    "lastname" => "Cognom",
    "email" => "Email",
    "password" => "Contrasenya",
    "password_confirmation" => "Confirmi la contrasenya",
    "already_registered" => "Ja està registrat?",
    "submit" => "Enviar"
];
