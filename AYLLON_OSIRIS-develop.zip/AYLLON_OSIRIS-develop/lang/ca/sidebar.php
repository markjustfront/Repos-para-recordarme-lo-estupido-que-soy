<?php
return [
    'Dashboard' => 'Tauler',
    'Diary' => 'Diari',
    'Workspace' => 'Espai de Treball',
    'Upload' => 'Carrega',
    'Study' => 'Estudi',
    'Tasks' => 'Tasques',
    'Create' => 'Crear',
    'user_dashboard' => 'Tauler d\'usuari',
    'translations' => 'Traduccions',
    'people' => 'Contactes',
];
