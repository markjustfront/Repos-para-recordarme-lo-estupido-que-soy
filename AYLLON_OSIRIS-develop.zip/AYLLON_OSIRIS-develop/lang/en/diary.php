<?php

return [
    'diary' => 'Diary',
    'confirmti' => 'Are you sure to save this information?',
    'confirmte' => 'This information will be saved in the database',
    'placeholder' => 'Write here...',
    'Save' => 'Save',
    'Last' => 'Last Entries',
    'See' => 'See More',
    'cancel' => 'Cancel',
    'accept' => 'Accept',
    'close' => 'Close',
    'delete' => 'Delete',
    'previous' => 'Previous',
    'next' => 'Next',
    'allEntriesTitle' => 'All Entries',
    'open' => 'Open',
    'posts' => 'Post',
    'edit' => 'Edit',
    
];
