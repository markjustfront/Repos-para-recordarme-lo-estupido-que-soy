<?php

return [
    'name' => 'Name:',
    'email' => 'Email:',
    'message' => 'Message:',
    'submit' => 'Submit',
    'confirmation' => 'Sent!',
    'confirmation_thanks' => 'Thank you!',
    'confirmation_message' => 'We`ll get in touch as soon as possible.',
];

