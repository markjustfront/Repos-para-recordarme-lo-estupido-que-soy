<?php
return[
    'peopletitle' => 'Add people',
    'inputname' => "Name",
    'placeholdername' => "Write the name...", 
    'inputlastname' => "Last name",
    'placeholderlastname' => "Write your last name...",
    'inputdescription' => "Description",
    'placeholderdescription' => "Description of the person...",
    'inputbirthday' => "Birthday",
    'inputrelation' => "Relationship",
    'option1' => "Friend",
    'option2' => "Family",
    'option3' => "Colleague",
    'option4' => "Acquaintance",
    'inputimage' => "Image",
    'submitpeople' => "Submit", 
];