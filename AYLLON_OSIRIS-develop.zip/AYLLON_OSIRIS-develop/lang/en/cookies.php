<?php

return [
    "cookies_policy" => '<h1 class="font-headers text-gray-900 grid justify-items-center my-8 text-4xl">Cookie Policy</h1>
    <p>&nbsp;</p>

    <ol class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>What are cookies?</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Cookies are small text files that are downloaded and stored on your device (computer, tablet, smartphone, etc.) when you access certain websites. They allow the website to remember information about your visit, such as your preferences and settings, to improve your user experience.</span></p>
    <p>&nbsp;</p>

    <ol start="2" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Types of cookies we use</strong></li></ol>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;"><strong>First-party cookies:</strong> These are cookies sent to your device from our own servers or domains and used to provide the requested service.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Third-party cookies:</strong> These are cookies sent to your device from a domain or server not managed by us, but by another entity that processes data obtained through cookies.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Session cookies:</strong> These are temporary and are deleted when you close the browser.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Persistent cookies:</strong> These remain on your device for a specified period or until you manually delete them.</span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="3" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Why do we use cookies?</strong></li></ol>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;"><strong>Technical cookies:</strong> Necessary for the proper functioning of the website.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Customization cookies:</strong> Allow remembering your preferences such as language or page settings.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Analytical cookies:</strong> Help us understand how users interact with the website, improving our services.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Advertising cookies:</strong> Serve to display relevant ads based on your interests.</span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="4" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Managing cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">You can allow, block, or delete cookies through your browser settings. Below, we provide information on how to do this in the most popular browsers:</span></p>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;">Google Chrome: <a href="https://support.google.com/chrome/answer/95647" target="_blank">support.google.com</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Mozilla Firefox: <a href="https://support.mozilla.org/en-US/kb/cookies-information-websites-store-on-your-computer" target="_blank">support.mozilla.org</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Microsoft Edge: <a href="https://support.microsoft.com/" target="_blank">support.microsoft.com</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Safari: <a href="https://support.apple.com/en-us/guide/safari/sfri11471/mac" target="_blank">support.apple.com</a></span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="5" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Changes to the cookie policy</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">We reserve the right to update this cookie policy at any time. It is recommended to review it periodically to stay informed of any changes.</span></p>
    <p>&nbsp;</p>

    <ol start="6" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Contact</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">If you have any questions or inquiries about our cookie policy, you can contact us via email at: <a href="mailto:osiris@email.com">osiris@email.com</a>.</span></p>
    <p>&nbsp;</p>
    '
];
