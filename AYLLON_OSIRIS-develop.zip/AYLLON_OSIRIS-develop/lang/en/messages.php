<?php

return [
    'home' => 'Home',
    'about' => 'About',
    'contact' => 'Contact',
    'terms' => 'Terms & Conditions',
    'cookies' => 'Cookies',
    'cookies_title' => 'Cookies',
    'cookies_text' => 'This website uses cookies to ensure its proper functioning and improve your user experience. By clicking "Accept", you consent to the use of cookies. For more information',
    'more_info' => 'click here',
    'accept' => 'Accept',
    'reject' => 'Reject',
    'aboutus' => 'About Us',
    'chooseLanguage' => 'Change the language:',
];
