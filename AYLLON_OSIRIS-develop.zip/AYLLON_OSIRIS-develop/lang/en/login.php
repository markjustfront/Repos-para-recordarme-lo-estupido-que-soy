<?php
return [
    'login' => 'Log In',
    'loginemail' => "Email",
    'loginpassword' => "Password",
    'loginforgot' => "Have you forgotten your password?",
    'loginsubmit' => "Send",
    ];
