<?php

return [
    "title1" => "Legal Notice",
    "legalnotice" => '<h1 class="block font-headers text-gray-700 text-gray-900 grid justify-items-center my-8 text-4xl">Legal Notice</h1>
    <ol class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Information about the Website Owner</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">In accordance with the provisions of Law 34/2002, of July 11, on Information Society Services and Electronic Commerce (LSSICE), the following information is provided:</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Owner: Osiris</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Address: c/Arquitecte Pelai Mart&Atilde;&shy;nez, 1, 17600, Figueres, Spain</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Contact Email: osiris@email.com</span></p>
    <p>&nbsp;</p>

    <ol start="2" class="list-decimal"><li class="font-extrabold text-mark"><strong> Description of Services</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Osiris is an online platform designed to help users organize and manage their studies or reading activities efficiently. The services include:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">User registration using name, surname, and email address.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Creation and management of daily tasks.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Access to a calendar of activities.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Uploading and storage of PDF files.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">A timer to track study or reading time.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Recording additional information, including names, surnames, and images of other individuals.</span></li>
    <p>&nbsp;</p>
    
    <ol start="3" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong> Terms of Use</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Access and use of the Osiris website are subject to the following terms and conditions:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Users agree to provide truthful and up-to-date information during the registration process.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Users are responsible for obtaining explicit consent from individuals whose data and images they upload to the platform, in accordance with data protection regulations.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">The use of the platform for illegal or unauthorized purposes is prohibited.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">The company reserves the right to modify or discontinue the service without prior notice.</span></p>
    <p>&nbsp;</p>

    <ol start="4" class="list-decimal"><li class="font-extrabold text-mark"><strong> Personal Data Protection</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">In accordance with Regulation (EU) 2016/679 of the European Parliament and of the Council, of April 27, 2016, regarding the protection of natural persons (GDPR) and Organic Law 3/2018, of December 5, on Personal Data Protection and the guarantee of digital rights (LOPDGDD), the following information is provided:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Personal data collected through this website will be used solely to provide the offered services.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Users may upload third-party personal data (such as names, surnames, and images) only if they have obtained the express consent of those third parties.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Users may exercise their rights of access, rectification, deletion, opposition, restriction of processing, and data portability by sending a request to osiris@email.com.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">For more information about data processing, please consult our [Privacy Policy].</span></p>
    <p>&nbsp;</p>

    <ol start="5" class="list-decimal"><li class="font-extrabold text-mark"><strong> Use of Cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">This website may use cookies to enhance user experience. By browsing the site, you agree to the use of cookies as described in our [Cookie Policy]. Users can configure their browsers to reject cookies.</span></p>
    <p>&nbsp;</p>

    <ol start="6" class="list-decimal"><li class="font-extrabold text-mark"><strong> Intellectual Property</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">All content, design, logos, texts, and graphics on the website are the property of Osiris and are protected by intellectual property laws. Reproduction, distribution, or modification without express authorization is prohibited.</span></p>
    <p>&nbsp;</p>

    <ol start="7" class="list-decimal"><li class="font-extrabold text-mark"><strong> Limitation of Liability</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Osiris is not responsible for any damages resulting from the misuse of the platform, service interruptions, or errors in provided content. Users are responsible for the content they upload, especially if it includes third-party personal data without the required consent.</span></p>
    <p>&nbsp;</p>

    <ol start="8" class="list-decimal"><li class="font-extrabold text-mark"><strong> Applicable Law and Jurisdiction</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">These terms are governed by Spanish law. For the resolution of any disputes arising from access to or use of this website, the parties submit to the courts and tribunals of Figueres, Spain, unless otherwise provided by law.</span></p>'

];