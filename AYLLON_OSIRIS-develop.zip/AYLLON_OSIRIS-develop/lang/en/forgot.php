<?php

return [
    'forgot' => 'Forgot password?',
    'forgot_long' => 'Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.',
    'recovery_email' => 'Send recovery password email',
];

