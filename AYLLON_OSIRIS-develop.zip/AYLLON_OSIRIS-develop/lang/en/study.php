<?php

return [
    'start' => 'Start',
    'pause' => 'Pause',
    'resume' => 'Resume',
    'stop' => 'Stop',
    'series' => 'Series:',
    'pomodoro' => 'This timer uses the pomodoro method. This method consists of making a number of series divided by iterations, these iterations are 4 periods of 25 minutes of study accompanied by 5 minutes of rest. At the end of the 4 periods there is a 15-minute break. In the series selector you can select to do up to 3 series of 4 iterations each making possible up to 6 and a half hours of study.',
    'ai_whatis' => 'Use AI to process this text',
    'ai_writehere' => 'Write here',
    'ai_short' => 'Summarize',
    'ai_studyplan' => 'Study plan',
    'ai_generating' => 'Generating response...',
    'ai_response' => 'Response:',
    'ai_close' => 'Close'
];
