<?php

return [
    'join' => 'Join',
    'register' => 'Sign up',
    'login' => 'Sign in',
    'whatis' => 'What is Osiris?',
    'description' => 'Osiris is your ultimate productivity companion, designed to help you organize your day with ease and efficiency. Create tasks, schedule your time, and stay on track using customizable study methods. With Osiris, you can upload and access PDF files directly, ensuring your resources are always at hand. The app also features an integrated diary, allowing you to document your daily achievements and reflections. You can associate diary entries with people in your life, fostering a personal touch and helping you build stronger connections. Simplify your workflow, enhance your productivity, and keep your memories alive with Osiris.',
];
