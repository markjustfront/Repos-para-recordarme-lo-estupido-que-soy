<?php
return [
    'Dashboard' => 'Dashboard',
    'Diary' => 'Diary',
    'Workspace' => 'Workspace',
    'Upload' => 'Upload',
    'Study' => 'Study',
    'Tasks' => 'Tasks',
    'Create' => 'Create',
    'user_dashboard' => 'User Dashboard',
    'translations' => 'Translations',
    'people' => 'Contacts',
];
