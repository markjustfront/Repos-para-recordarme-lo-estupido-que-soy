<?php

return [
    'message' => 'We are sorry. But the page you requested was not found',
    'home' => 'Go Home',
    'contact' => 'Contact Us',
];