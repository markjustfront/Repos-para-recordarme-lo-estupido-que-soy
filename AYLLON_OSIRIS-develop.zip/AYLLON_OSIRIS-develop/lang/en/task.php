<?php

return [
    'tasks' => 'Tasks',
    'title' => 'Tasks',
    'subtitle' => 'Add your tasks here',
    'tasktitle' => 'Title',
    'description' => 'Description',
    'start_time' => 'Start time',
    'end_time' => 'End time',
    'addTask' => 'Add task',
    'from' => 'From',
    'to' => 'to',
    'finish' => 'Finish the task',
];
