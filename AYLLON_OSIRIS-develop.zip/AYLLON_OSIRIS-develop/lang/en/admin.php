<?php

return [
    "adminpanel" => "Admin Panel",
    "users" => "Users",
    "generate" => "Generate",
    "admin" => "Administrator",
    "manager" => "Manager",
    "user" => "User",
    "messages" => "Messages",
];
