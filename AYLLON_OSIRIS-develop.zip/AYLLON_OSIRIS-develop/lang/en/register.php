<?php

return [
    "register" => "Register",
    "firstname" => "First Name",
    "lastname" => "Last Name",
    "email" => "Email",
    "password" => "Password",
    "password_confirmation" => "Password confirmation",
    "already_registered" => "Already registered?",
    "submit" => "Submit"
];
