<?php
return[
    'welcome' => 'Welcome',
    'tasktitle' => 'Upcoming tasks',
    'taskfrom' => 'From',
    'taskof' =>  'to',
    'diarytitle' => 'Latest entries',
    'persontitle' => 'Contacts',
    'modalname' => 'First and last name:',
    'modaldescription' => 'Description:',
    'modalbirthday' => 'Birthday:',
    'modalrelation' => 'Relationship:',
];
