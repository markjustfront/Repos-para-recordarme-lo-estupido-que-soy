<?php

return [
    "workspace" => "Workspace",
    "search" => "Search file..",
    "read" => "Read",

];
