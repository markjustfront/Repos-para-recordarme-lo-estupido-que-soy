<?php
return [
    'title' => 'Translations',
    'save' => 'Save',
    'key' => 'Key',
    'open_in_pc' => 'Please open this page in PC.',
];
