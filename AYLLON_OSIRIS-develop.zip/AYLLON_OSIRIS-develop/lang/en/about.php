<?php
return [
    'title' => 'About Us',
    'team' => 'Team',
    'team_members' => [
        '1' => [
            "name" => "Marc",
            "description" => "With an analytical approach, Marc ensures quality and efficiency in every detail of the project.",
            "image" => "/images/marc.png",
        ],
        '2' => [
            "name" => "Mounia",
            "description" => "An expert in design and user experience, Mounia turns ideas into intuitive and attractive interfaces.",
            "image" => "/images/mounia.png",
        ],
        '3' => [
            "name" => "Mateo",
            "description" => "Passionate about innovation, Mateo leads technical development with strategic and creative vision.",
            "image" => "/images/mateo.png",
        ],
        '4' => [
            "name" => "Carolina",
            "description" => "Organized and empathetic, Carolina manages the team with enthusiasm and impeccable communication.",
            "image" => "/images/carolina.png",
        ],
        '5' => [
            "name" => "Denis",
            "description" => "Ingenious and resourceful, Denis provides technical solutions with a always practical approach.",
            "image" => "/images/denis.png",
        ],
    ],
    'about_text' => 'We are a proud team of young web programmers that seek the solution to one self`s life organization. We are eager to show the world what can be achieved when you can plan ahead your day-to-day tasks and events. Our vision reflects the long-suffering experience of not knowing what to do when your day starts. With the application that we provide to our customers, we intend to make their life easier by making sure whatever they need to do in their day can be organized so they can have less stress over their lives. Osiris was conceived one afternoon the first days after New Year`s Eve, we were determined to fix an issue of our modern world, and after long hours of thinking and brainstorming we got the idea after one of us stopped thinking about solving these issue and stared to get nervous because he was thinking about what he had to that days night and what followed the morning after.',
];
