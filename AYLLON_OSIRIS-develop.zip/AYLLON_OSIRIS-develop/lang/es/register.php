<?php

return [
    "register" => "Registrarme",
    "firstname" => "Nombre",
    "lastname" => "Apellido",
    "email" => "Email",
    "password" => "Contraseña",
    "password_confirmation" => "Confirme la contraseña",
    "already_registered" => "¿Ya estás registrado?",
    "submit" => "Enviar"
];
