<?php 

return [
    'allEntriesTitle' => 'Todas las Entradas',
    'close' => 'Cerrar',
    'See' => 'Ver Más',

];

?>

