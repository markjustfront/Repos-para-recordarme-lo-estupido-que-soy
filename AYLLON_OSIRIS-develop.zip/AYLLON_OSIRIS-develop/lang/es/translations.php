<?php
return [
    'title' => 'Traducciones',
    'save' => 'Guardar',
    'key' => 'Identificador',
    'open_in_pc' => 'Porfavor abra esta página desde un ordenador.',
];
