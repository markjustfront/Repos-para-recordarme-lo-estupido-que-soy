<?php

return [
    'join' => 'Unete a',
    'register' => 'Unirse',
    'login' => 'Entra',
    'whatis' => '¿Que és Osiris?',
    'description' => 'Osiris es tu compañero de productividad definitivo, diseñado para ayudarte a organizar tu día con facilidad y eficiencia. Crea tareas, organiza tu tiempo y mantente al día utilizando métodos de estudio personalizables. Con Osiris, puedes subir y acceder a archivos PDF directamente, asegurando que tus recursos estén siempre a mano. La app también cuenta con un diario integrado, que te permite documentar tus logros diarios y reflexiones. Puedes asociar las entradas del diario con personas en tu vida, aportando un toque personal y ayudándote a fortalecer tus conexiones. Simplifica tu flujo de trabajo, mejora tu productividad y guarda tus recuerdos con Osiris.',
];
