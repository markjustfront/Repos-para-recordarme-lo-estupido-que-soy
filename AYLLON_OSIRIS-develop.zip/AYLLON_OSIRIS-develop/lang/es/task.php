<?php

return [
    'tasks' => 'Tareas',
    'title' => 'Tareas',
    'subtitle' => 'Añade aquí tus tareas',
    'tasktitle' => 'Título',
    'description' => 'Descripción',
    'start_time' => 'Fecha de inicio',
    'end_time' => 'Fecha de fin',
    'addTask' => 'Añadir tarea',
    'from' => 'De',
    'to' => 'a',
    'finish' => 'Termina la tarea',
];
