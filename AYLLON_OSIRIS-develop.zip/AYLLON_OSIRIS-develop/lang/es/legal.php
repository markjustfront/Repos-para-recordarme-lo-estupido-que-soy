<?php

return [
    "title1" => "Aviso Legal",
    "legalnotice" => '<h1 class="block font-headers text-gray-700 text-gray-900 grid justify-items-center my-8 text-4xl">Aviso Legal</h1>
    <ol class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Información del Responsable del Sitio Web</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">De conformidad con lo dispuesto en la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y de Comercio Electrónico (LSSICE), se informa de lo siguiente:</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Responsable: Osiris</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Domicilio: c/Arquitecte Pelai Martínez, 1, 17600, Figueres, España</span></p>
    <p>&nbsp;</p>
    <li class="ml-12 list-disc"><span style="font-weight: 400;">Correo electrónico de contacto: osiris@email.com</span></p>
    <p>&nbsp;</p>

    <ol start="2" class="list-decimal"><li class="font-extrabold text-mark"><strong>Descripción de los Servicios</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Osiris es una plataforma en línea diseñada para ayudar a los usuarios a organizar y gestionar sus estudios o actividades de lectura de manera eficiente. Los servicios incluyen:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Registro de usuarios mediante nombre, apellido y correo electrónico.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Creación y gestión de tareas diarias.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Acceso a un calendario de actividades.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Subida y almacenamiento de archivos PDF.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Cronómetro para controlar el tiempo de estudio o lectura.</span></li>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Registro de información adicional, incluyendo nombres, apellidos e imágenes de otras personas.</span></li>
    <p>&nbsp;</p>
    
    <ol start="3" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Condiciones de Uso</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">El acceso y uso de la página web Osiris están sujetos a los siguientes términos y condiciones:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Los usuarios se comprometen a proporcionar información veraz y actualizada durante el proceso de registro.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Los usuarios son responsables de obtener el consentimiento explícito de las personas cuyos datos e imágenes suban a la plataforma, conforme a las normativas de protección de datos.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">El uso de la plataforma para fines ilegales o no autorizados está prohibido.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">La empresa se reserva el derecho de modificar o interrumpir el servicio sin previo aviso.</span></p>
    <p>&nbsp;</p>

    <ol start="4" class="list-decimal"><li class="font-extrabold text-mark"><strong>Protección de Datos Personales</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">De conformidad con el Reglamento (UE) 2016/679 del Parlamento Europeo y del Consejo, de 27 de abril de 2016, relativo a la protección de las personas físicas (RGPD) y la Ley Orgánica 3/2018, de 5 de diciembre, de Protección de Datos Personales y garantía de los derechos digitales (LOPDGDD), se informa de lo siguiente:</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Los datos personales recopilados a través de esta página web se utilizarán únicamente para proporcionar los servicios ofrecidos.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Los usuarios podrán subir datos personales de terceros (como nombres, apellidos e imágenes) solo si cuentan con el consentimiento expreso de dichos terceros.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Los usuarios podrán ejercer sus derechos de acceso, rectificación, supresión, oposición, limitación del tratamiento y portabilidad de sus datos enviando una solicitud a osiris@email.com.</span></p>
    <p>&nbsp;</p>
    <li class="list-disc ml-12"><span style="font-weight: 400;">Para obtener más información sobre el tratamiento de datos, consulte nuestra [Política de Privacidad].</span></p>
    <p>&nbsp;</p>

    <ol start="5" class="list-decimal"><li class="font-extrabold text-mark"><strong> Uso de Cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Este sitio web puede utilizar cookies para mejorar la experiencia del usuario. Al navegar por el sitio, usted acepta el uso de cookies según se describe en nuestra [Política de Cookies]. Los usuarios pueden configurar sus navegadores para rechazar cookies.</span></p>
    <p>&nbsp;</p>

    <ol start="6" class="list-decimal"><li class="font-extrabold text-mark"><strong>Propiedad Intelectual</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Todo el contenido, diseño, logotipos, textos y gráficos del sitio web son propiedad de Osiris y están protegidos por las leyes de propiedad intelectual. Queda prohibida la reproducción, distribución o modificación sin autorización expresa.</span></p>
    <p>&nbsp;</p>

    <ol start="7" class="list-decimal"><li class="font-extrabold text-mark"><strong>Limitación de Responsabilidad</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Osiris no se hace responsable de los daños y perjuicios derivados del mal uso de la plataforma, interrupciones del servicio o errores en los contenidos proporcionados. Los usuarios son responsables del contenido que suban, especialmente si incluye datos personales de terceros sin el debido consentimiento.</span></p>
    <p>&nbsp;</p>

    <ol start="8" class="list-decimal"><li class="font-extrabold text-mark"><strong>Legislación Aplicable y Jurisdicción</strong></li></ol>
    <p>&nbsp;</p>
    <p><span style="font-weight: 400;">Estas condiciones se rigen por la legislación española. Para la resolución de cualquier disputa que pudiera surgir del acceso o uso de este sitio web, las partes se someten a los juzgados y tribunales de Figueres, España, salvo que la ley disponga otra cosa.</span></p>'

    
];