<?php

return [
    "cookies_policy" => '<h1 class="font-headers text-gray-900 grid justify-items-center my-8 text-4xl">Política de Cookies</h1>
    <p>&nbsp;</p>

    <ol class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>¿Qué son las cookies?</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Las cookies son pequeños archivos de texto que se descargan y almacenan en tu dispositivo (ordenador, tableta, smartphone, etc.) cuando accedes a determinados sitios web. Permiten que el sitio web recuerde información sobre tu visita, como tus preferencias y configuraciones, para mejorar tu experiencia de usuario.</span></p>
    <p>&nbsp;</p>

    <ol start="2" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Tipos de cookies que utilizamos</strong></li></ol>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;"><strong>Cookies propias:</strong> Son aquellas que se envían a tu dispositivo desde nuestros propios servidores o dominios y desde las cuales prestamos el servicio solicitado.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies de terceros:</strong> Son aquellas que se envían a tu dispositivo desde un dominio o servidor que no es gestionado por nosotros, sino por otra entidad que trata los datos obtenidos a través de las cookies.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies de sesión:</strong> Son temporales y desaparecen al cerrar el navegador.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies persistentes:</strong> Permanecen en tu dispositivo durante un periodo determinado o hasta que las elimines manualmente.</span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="3" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>¿Para qué utilizamos las cookies?</strong></li></ol>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;"><strong>Cookies técnicas:</strong> Necesarias para el correcto funcionamiento del sitio web.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies de personalización:</strong> Permiten recordar tus preferencias como el idioma o la configuración de la página.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies de análisis:</strong> Nos ayudan a entender cómo interactúan los usuarios con el sitio web, mejorando nuestros servicios.</span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;"><strong>Cookies publicitarias:</strong> Sirven para mostrar anuncios relevantes en función de tus intereses.</span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="4" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Gestión de cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Puedes permitir, bloquear o eliminar las cookies mediante la configuración de tu navegador. A continuación, te ofrecemos información sobre cómo hacerlo en los navegadores más populares:</span></p>
    <p>&nbsp;</p>
    <ul class="list-disc ml-12">
        <li><span style="font-weight: 400;">Google Chrome: <a href="https://support.google.com/chrome/answer/95647" target="_blank">support.google.com</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Mozilla Firefox: <a href="https://support.mozilla.org/es/kb/cookies" target="_blank">support.mozilla.org</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Microsoft Edge: <a href="https://support.microsoft.com/" target="_blank">support.microsoft.com</a></span></li>
        <p>&nbsp;</p>
        <li><span style="font-weight: 400;">Safari: <a href="https://support.apple.com/es-es/guide/safari/sfri11471/mac" target="_blank">support.apple.com</a></span></li>
    </ul>
    <p>&nbsp;</p>

    <ol start="5" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Cambios en la política de cookies</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Nos reservamos el derecho de actualizar esta política de cookies en cualquier momento. Se recomienda revisarla periódicamente para estar informado de posibles cambios.</span></p>
    <p>&nbsp;</p>

    <ol start="6" class="list-decimal ml-12"><li class="font-extrabold text-mark"><strong>Contacto</strong></li></ol>
    <p>&nbsp;</p>
    <p class="ml-12"><span style="font-weight: 400;">Si tienes alguna duda o consulta sobre nuestra política de cookies, puedes contactarnos a través del correo electrónico: <a href="mailto:osiris@email.com">osiris@email.com</a>.</span></p>
    <p>&nbsp;</p>
    '
];
