<?php

return [
    "adminpanel" => "Panel de administrador",
    "users" => "Usuarios",
    "generate" => "Genera",
    "admin" => "Administrador",
    "manager" => "Manager",
    "user" => "Usuario",
    "messages" => "Mensajes",
];
