<?php
return [
    'login' => 'Iniciar sesión',
    'loginemail' => "Correo electrónico",
    'loginpassword' => "Contraseña",
    'loginforgot' => "¿Has olvidado tu contraseña?",
    'loginsubmit' => "Envía",
    ];
