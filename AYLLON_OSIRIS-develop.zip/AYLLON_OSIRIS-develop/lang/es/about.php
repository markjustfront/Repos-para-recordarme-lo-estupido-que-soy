<?php
return [
    'title' => 'Sobre Nosotros',
    'team' => 'Equipo',
    'team_members' => [
        '1' => [
            "name" => "Marc",
            "description" => "Con un enfoque analítico, Marc asegura la calidad y eficiencia en cada detalle del proyecto.",
            "image" => "/images/marc.png",
        ],
        '2' => [
            "name" => "Mounia",
            "description" => "Experta en diseño y experiencia de usuario, Mounia transforma ideas en interfaces intuitivas y atractivas.",
            "image" => "/images/mounia.png",
        ],
        '3' => [
            "name" => "Mateo",
            "description" => "Apasionado por la innovación, Mateo lidera el desarrollo técnico con una visión estratégica y creativa.",
            "image" => "/images/mateo.png",
        ],
        '4' => [
            "name" => "Carolina",
            "description" => "Organizada y empática, Carolina gestiona el equipo con entusiasmo y una comunicación impecable.",
            "image" => "/images/carolina.png",
        ],
        '5' => [
            "name" => "Denis",
            "description" => "Ingenioso y resolutivo, Denis aporta soluciones técnicas con un enfoque siempre práctico.",
            "image" => "/images/denis.png",
        ],
    ],
    'about_text' => 'Somos un orgulloso equipo de jóvenes programadores web que buscan la solución a la organización de la vida de uno mismo. Estamos ansiosos por mostrarle al mundo lo que se puede lograr cuando puede planificar con anticipación sus tareas y eventos diarios. Nuestra visión refleja la sufrida experiencia de no saber qué hacer cuando comienza el día. Con la aplicación que proporcionamos a nuestros clientes, pretendemos hacerles la vida más fácil asegurándonos de que lo que necesiten hacer en su día se pueda organizar para que puedan tener menos estrés en sus vidas. Osiris fue concebido una tarde los primeros días después de la víspera de Año Nuevo, estábamos decididos a arreglar un problema de nuestro mundo moderno, y después de largas horas de pensar y lluvia de ideas se nos ocurrió la idea después de que uno de nosotros dejó de pensar en resolver estos problemas y se puso nervioso porque estaba pensando en lo que tenía que hacer esa noche de día y lo que siguió a la mañana siguiente.',
];
