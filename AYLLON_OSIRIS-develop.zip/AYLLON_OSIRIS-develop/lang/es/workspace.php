<?php

return [
    "workspace" => "Espacio de Trabajo",
    "search" => "Buscar archivo...",
    "read" => "Leer",
];
