<?php
return [
    'title' => 'Perfil',
    'profile_information' => 'Información del perfil',
    'text_update_info' => 'Actualiza tu nombre o correo electrónico',
    'name' => 'Nombre',
    'last_name' => 'Apellido',
    'email' => 'Correo electrónico',
    'save' => 'Guardar',
    'saved' => 'Guardado',
    'update_password' => 'Actualizar contraseña',
    'text_update_password' => 'Asegúrate de usar una contraseña segura',
    'current_password' => 'Contraseña actual',
    'new_password' => 'Nueva contraseña',
    'confirm_password' => 'Confirmar contraseña',
    'delete_account' => 'Eliminar cuenta',
    'text_delete_account' => 'Una vez que tu cuenta sea eliminada, todo tu contenido será borrado permanentemente. Antes de eliminar tu cuenta, descarga los archivos que desees conservar.',
    'edit' => 'Editar perfil',
    'sure' => 'Estáis seguro que queréis suprimir vuestra cuenta?',
    'text_sure' => 'Una vez eliminada vuestra cuenta, todos sus recursos y datos se eliminarán permanentemente. Introducís la contraseña para confirmar que queréis suprimir permanentemente vuestra cuenta.',
    'password' => 'Contraseña'
    ];
