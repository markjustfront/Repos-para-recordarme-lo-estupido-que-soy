<?php

return [
    'forgot' => 'Olvidaste la contraseña',
    'forgot_long' => '¿Olvidaste tu contraseña? No hay problema. Simplemente déjanos saber tu dirección de correo electrónico y te enviaremos un enlace para restablecer la contraseña que te permitirá 1  elegir una nueva.',
    'recovery_email' => 'Envia correo de recuperación',
];

