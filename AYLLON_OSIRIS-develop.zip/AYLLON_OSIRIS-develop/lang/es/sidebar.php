<?php
return [
    'Dashboard' => 'Tablero',
    'Diary' => 'Diario',
    'Workspace' => 'Espacio de Trabajo',
    'Upload' => 'Carga',
    'Study' => 'Estudia',
    'Tasks' => 'Tareas',
    'Create' => 'Crear',
    'user_dashboard' => 'Tablero de usuario',
    'translations' => 'Traducciones',
    'people' => 'Contactos',
];
