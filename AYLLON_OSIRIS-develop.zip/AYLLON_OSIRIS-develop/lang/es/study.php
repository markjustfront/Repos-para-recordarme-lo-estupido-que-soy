<?php

return [
    'start' => 'Empieza',
    'pause' => 'Pausa',
    'resume' => 'Sigue',
    'stop' => 'Para',
    'series' => 'Series:',
    'pomodoro' => 'Este contador de tiempo usa el método pomodoro. Este método consiste a hacer un número de series divididas por iteraciones, estas iteraciones son 4 periodos de 25 minutos de estudio acompañados por 5 minutos de descanso. Al acabar los 4 periodes hay un descanso de 15 minutos. En el selector de series puedes seleccionar hacer hasta 3 series de 4 iteraciones cada una haciendo posible hasta 6 horas y media de estudio.',
    'ai_whatis' => 'Procesar Texto con IA',
    'ai_writehere' => 'Escribe tu texto aquí...',
    'ai_short' => 'Resumir',
    'ai_studyplan' => 'Plan de estudio',
    'ai_generating' => 'Generando respuesta...',
    'ai_response' => 'Respuesta:',
    'ai_close' => 'Cerrar'
];
