<?php

return [
    'process_text' => 'Process Text with AI',
    'write_text' => 'Write your text here...',
    'summarize' => 'Summarize',
    'study_plan' => 'Study Plan',
    'generating_response' => 'Generating response...',
    'response' => 'Response:',
    'write_first' => 'Write a text first',
    'error_generating' => 'Error generating text.',
    'no_response' => 'No response',
];