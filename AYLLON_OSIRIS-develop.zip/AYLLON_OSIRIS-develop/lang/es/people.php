<?php
return[
    'peopletitle' => 'Añadir personas',
    'inputname' => "Nombre",
    'placeholdername' => "Escribe tu nombre...", 
    'inputlastname' => "Apellido",
    'placeholderlastname' => "Escribe el apellido...",
    'inputdescription' => "Descripción",
    'placeholderdescription' => "Descripción de la persona...",
    'inputbirthday' => "Cumpleaños",
    'inputrelation' => "Relación",
    'option1' => "Amigo",
    'option2' => "Familiar",
    'option3' => "Compañero",
    'option4' => "Conocido",
    'inputimage' => "Imagen",
    'submitpeople' => "Enviar", 
];