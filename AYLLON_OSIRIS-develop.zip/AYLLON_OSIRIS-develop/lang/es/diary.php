<?php

return [
    'diary' => 'Diario',
    'confirmti' => '¿Estás seguro de guardar esta información?',
    'confirmte' => 'Esta información se guardará en la base de datos',
    'placeholder' => 'Escribe aquí...',
    'Save' => 'Guardar',
    'Last' => 'Últimas Entradas',
    'See' => 'Ver Más',
    'cancel' => 'Cancelar',
    'accept' => 'Aceptar',
    'close' => 'Cerrar',
    'delete' => 'Borrar',   
    'previous' => 'Anterior',
    'next' => 'Siguiente', 
    'allEntriesTitle' => 'Todas las Entradas',
    'open' => 'Abrir',
    'posts' => 'Entrada',
    'edit' => 'Editar',
    
];
