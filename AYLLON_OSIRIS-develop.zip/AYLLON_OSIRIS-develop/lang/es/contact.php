<?php

return [
    'name' => 'Nombre:',
    'email' => 'Correo electronico:',
    'message' => 'Mensaje:',
    'submit' => 'Enviar',
    'confirmation' => 'Enviado!',
    'confirmation_thanks' => 'Muchas gracias',
    'confirmation_message' => 'Nos pondremos en contacto contigo lo más pronto possible',
];
