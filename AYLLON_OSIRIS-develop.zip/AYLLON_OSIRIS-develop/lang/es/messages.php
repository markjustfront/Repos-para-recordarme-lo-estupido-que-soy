<?php

return [
    'home' => 'Inicio',
    'about' => 'Nosotros',
    'contact' => 'Contacto',
    'terms' => 'Condiciones de uso',
    'cookies' => 'Cookies',
    'aboutus' => 'Sobre nosotros',
    'cookies_title' => 'Cookies',
    'cookies_text' => 'Este sitio web utiliza cookies para garantizar su correcto funcionamiento y mejorar tu experiencia de usuario. Al hacer clic en "Aceptar", consientes el uso de cookies. Para más información',
    'more_info' => 'clic aquí',
    'accept' => 'Aceptar',
    'reject' => 'Rechazar',
    'chooseLanguage' => 'Cambia el idioma:',
];
