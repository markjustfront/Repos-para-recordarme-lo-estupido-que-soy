<?php
return[
    'welcome' => 'Bienvenido/a',
    'tasktitle' => 'Próximas tareas',
    'taskfrom' => 'de',
    'taskof' =>  'a',
    'diarytitle' => 'Últimas entradas',
    'persontitle' => 'Personas',
    'modalname' => 'Nombre y apellidos:',
    'modaldescription' => 'Descripción:',
    'modalbirthday' => 'Cumpleaños:',
    'modalrelation' => 'Relación:',
];
