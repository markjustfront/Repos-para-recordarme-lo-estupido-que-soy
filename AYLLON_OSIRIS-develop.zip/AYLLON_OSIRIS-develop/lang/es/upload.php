<?php

return [
    "upload"=> "Subir archivo"
    

];