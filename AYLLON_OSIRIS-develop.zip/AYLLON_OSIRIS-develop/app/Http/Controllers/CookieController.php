<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use App\Traits\LangHelper;

class CookieController extends Controller
{
    public function index(?string $locale = null)
    {
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["contact", "cookies", "messages"]);
        return Inertia::render('Cookie', [
            'translations' => $translations,
        ]);
    }
}
