<?php

namespace App\Http\Controllers;

use App\Models\Application;
use App\Traits\LangHelper;
use Inertia\Inertia;
use Inertia\Response;

class StudyController extends Controller
{
    public function index(?string $locale = null) : Response {
        LangHelper::localeHandler($locale);
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;
        return Inertia::render('Study', [
            'translations' => LangHelper::getMultipleTranslations(["sidebar", "study"]),
            'isAdmin' => $isAdmin,
        ]);
    }

    public function incrementStudied() {
        $app = Application::all()->first();
        if ($app == null) {
            $application = new Application();
            $application->times_studied = 1;
            $application->save();

        } else {
            $app->times_studied++;
            $app->save();
        }

    }
}
