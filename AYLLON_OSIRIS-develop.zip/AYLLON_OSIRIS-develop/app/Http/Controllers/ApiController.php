<?php

namespace App\Http\Controllers;

use App\Http\Middleware\Manager;
use App\Models\Application;
use App\Models\Contact;
use App\Models\File;
use App\Models\Person;
use App\Models\Task;
use App\Models\User;
use Illuminate\Http\Request;
use function MongoDB\BSON\toJSON;

class ApiController extends Controller
{
    public function stats()
    {
        if (!\request()->get("admin")) {
            return "manager";
        }

        $userCount = User::all()->count();
        $contactCount = Person::all()->count();
        $taskCount = Task::all()->count();
        $fileCount = File::all()->count();
        $studiesCount = Application::all()->first()->times_studied;
        $managerCount = \App\Models\Manager::all()->count();

        $response = array();
        $response["users"] = $userCount;
        $response["contacts"] = $contactCount;
        $response["tasks"] = $taskCount;
        $response["files"] = $fileCount;
        $response["studied"] = $studiesCount;
        $response["managers"] = $managerCount;

        return json_encode($response);
    }
}
