<?php

namespace App\Http\Controllers;

use App\Mail\ContactSuccess;
use App\Mail\SupportReach;
use App\Models\Contact;
use Inertia\Inertia;
use App\Traits\LangHelper;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function showContact(?string $locale = null)
    {
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["messages", "contact"]);
        return Inertia::render('Contact', [
            'translations' => $translations,
        ]);


    }
    public function index()
    {
        $validated = request()->validate([
            'name' => 'required',
            'email' => 'required|email',
            'message' => 'required'
        ]);

        $contact = new Contact();
        $contact->name = $validated['name'];
        $contact->email = $validated['email'];
        $contact->message = $validated['message'];
        $contact->save();

        Mail::to($validated['email'])->send(new ContactSuccess());
        Mail::to('suport@osiris.cat')->send(new SupportReach($validated));

        if (request('footer') != null) {
            return Inertia::location(route('home'));
        }

    }

    public function loadContacts() {
        $contacts = Contact::all();
        return $contacts->toJson();
    }

    public function delete() {
        $id = request('id');
        Contact::destroy($id);
    }
}
