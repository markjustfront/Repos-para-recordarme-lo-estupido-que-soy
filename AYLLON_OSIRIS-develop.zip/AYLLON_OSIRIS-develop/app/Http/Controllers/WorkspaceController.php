<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Traits\LangHelper;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\File;
use Illuminate\Support\Facades\Auth;


class WorkspaceController extends Controller
{
    public function index (?string $locale = null)
    {
        LangHelper::localeHandler($locale);
        //  dd(Auth::user());
        $user_id=Auth::user()->id;
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;

        $translations = LangHelper::getMultipleTranslations(["sidebar", "workspace"]);
        $pdfs = File::where('user_id',$user_id)->get();
        return Inertia::render('Workspace', [
            'translations' => $translations,
            'pdfs' => $pdfs,
            'isAdmin' => $isAdmin,
        ]);

    }

    // Show PDF
    public function showPdf (string $documentName)
    {
        $document = File::where('name',$documentName)->get();

        if ($document->user_id != \Illuminate\Support\Facades\Auth::user()->id ) {
            return redirect(route('home', absolute: false));
        }

        return redirect("/storage/files/" . $documentName);
    }

    // Search PDF
    public function searchPdf ()
    {
        $user_id = Auth::id();
        $search = \request()->get("params")["search"];

        $user = User::all()->find($user_id);
        if ($search == "") {
            $pdfs = $user->files()->get();
        } else {
            $pdfs = $user->files()->where('fake_name', "like", "%" . $search . "%")->get();
        }


        return response()->json($pdfs);

    }

    public function deletePDF (string $documentName) {
        $user_id = Auth::id();
        $file = File::all()->where('name',$documentName)->where('user_id', $user_id)->first();
        try {
            unlink($file->route);
            $file->delete();
        } catch (\Exception $e) {
            return "File is not here";
        }

        return true;
    }

    public function getPDFS() {
        return File::all()->where('user_id',Auth::id())->toJson();
    }

}


