<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use App\Traits\LangHelper;

//About controller
class AboutController extends Controller
{
    public function index(?string $locale=null)
    {
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["messages", "about", "contact"]);
        return Inertia::render('About', [
            'translations' => $translations,
        ]);
    }
}
