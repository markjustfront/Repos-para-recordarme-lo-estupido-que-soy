<?php

namespace App\Http\Controllers;

use App\Traits\LangHelper;
use Illuminate\Http\Request;
use Inertia\Inertia;

class HomeController extends Controller
{
    public function index(?string $locale = null) : \Inertia\Response {
        LangHelper::localeHandler($locale);
        return Inertia::render('Home', [
            'translations' => LangHelper::getMultipleTranslations(["messages", "home", "contact"]),
        ]);
    }
}
