<?php

namespace App\Http\Controllers;

use App\Models\DiaryEntry;
use App\Traits\LangHelper;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Person;
use App\Models\Task;
use App\Models\User;

class DashboardController extends Controller
{
    public function index (?string $locale = null){
        LangHelper::localeHandler($locale);
        $user = Auth::user();
        $people = Person::all()->where("user_id", auth()->id());
        $tasks = Task::all()->where('user_id', Auth::user()->id);
        $entry = DiaryEntry::all()->where('user_id', \auth()->id())->take(5);
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0;

        return Inertia::render('Dashboard', [
            'translations' => LangHelper::getMultipleTranslations(["sidebar", "dashboard"]),
            'user' => $user,
            'tasks' => $tasks,
            'people' => $people,
            'diary' => $entry,
            'isAdmin' => $isAdmin,
        ]);
    }
}
