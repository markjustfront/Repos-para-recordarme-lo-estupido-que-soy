<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Inertia\Inertia;

class IaController extends Controller
{
    private $geminiToken;

    public function __construct()
    {
        // Retrieve the Gemini API key from the environment file
        $this->geminiToken = env('GEMINI_API_KEY');

        // Log an error and throw an exception if the API key is missing
        if (!$this->geminiToken) {
            Log::error("GEMINI_API_KEY is missing in the .env file");
            throw new \Exception("Gemini API key is missing.");
        }
    }

    public function index()
    {
        // Render the IA view using Inertia and pass flash messages
        return Inertia::render('IA', [
            'flash' => session('flash') ?? []
        ]);
    }

    public function generarTexto(Request $request)
    {
        // Log the incoming request for debugging purposes
        Log::info("Request received in Laravel", $request->all());

        // Validate the request parameters
        $request->validate([
            'texto' => 'required|string|max:5000',
            'tipo'  => 'required|string|in:resumen,plan_estudio',
        ]);

        try {
            // Build the prompt based on the input type
            $prompt = $this->buildPrompt($request->texto, $request->tipo);
            // Send the prompt to Gemini API and retrieve the response
            $respuesta = $this->sendToGemini($prompt);
        } catch (\Exception $e) {
            // Log any errors and return a 500 error response
            Log::error("Error in AI: " . $e->getMessage());
            return response()->json(['error' => 'Error generating response with AI.'], 500);
        }
        return response()->json(['respuesta' => $respuesta]);
    }

    private function buildPrompt($texto, $tipo)
    {
        // Base instruction for the AI assistant
        $basePrompt = "Eres un asistente experto en educación y síntesis de información.\n\n";
        
        // Return different prompts based on the requested type
        return match ($tipo) {
            'resumen' => $basePrompt 
                . "Genera un resumen claro y conciso del siguiente contenido:\n\n" 
                . $texto . "\n\n"
                . "Responde solo con el resumen final, sin repetir la instrucción.",
            'plan_estudio' => $basePrompt 
                . "Crea un plan de estudio detallado basado en el siguiente contenido. Incluye objetivos de aprendizaje, temas clave y recursos recomendados:\n\n" 
                . $texto . "\n\n"
                . "Responde solo con el plan de estudio final, sin repetir la instrucción.",
        };
    }
    private function sendToGemini($prompt)
    {
        // Log the request to Gemini API
        Log::info("Sending request to Gemini API with prompt: " . $prompt);

        // Define the API endpoint with the authentication token
        $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $this->geminiToken;

        // Send the request to Gemini API
        $response = Http::withHeaders([
            'Content-Type' => 'application/json'
        ])->timeout(90)
          ->post($url, [
              'contents' => [
                  [
                      'parts' => [
                          ['text' => $prompt]
                      ]
                  ]
              ]
          ]);

        // Log the API response
        Log::info("✅ Response from Gemini API: ", $response->json());
        if ($response->failed()) {
            Log::error("Error in Gemini API response", $response->json());
            throw new \Exception('Error communicating with the Gemini API.');
        }
        $output = $response->json();
        // Check if the expected response structure exists
        if (!isset($output['candidates'][0]['content']['parts'][0]['text'])) {
            Log::error("Unexpected response from Gemini API: ", $output);
            throw new \Exception('Unexpected response from Gemini API.');
        }

        return trim($output['candidates'][0]['content']['parts'][0]['text']);
    }
}
