<?php

namespace App\Http\Controllers;

use App\Models\DiaryEntry;
use App\Traits\LangHelper;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Http\Request;

class DiaryEntryController extends Controller
{
    public function index(?string $locale = null): Response {
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["diary","sidebar"]);
        $entries = DiaryEntry::orderBy('created_at','desc')->get();
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;
        return Inertia::render('DiaryEntry', [
            'translations' => $translations,
            'entries'      => $entries,
            'isAdmin'      => $isAdmin,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title'   => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $entry = DiaryEntry::create([
            'user_id' => auth()->id(),
            'title'   => $validated['title'],
            'content' => $validated['content'],
        ]);

        return response()->json([
            'entry' => $entry,
            'message' => 'Entry created successfully'
        ]);
    }

    public function getEntries()
    {
        $entries = DiaryEntry::orderBy('created_at', 'desc')->get();
        return response()->json(['entries' => $entries]);
    }

    public function destroy($id)
    {
        DiaryEntry::findOrFail($id)->delete();

        return response()->json([
            'message' => 'Entry deleted successfully',
            'entries' => DiaryEntry::latest()->take(5)->get()
        ]);
    }

    // Método para actualizar la entrada
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'title'   => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $entry = DiaryEntry::findOrFail($id);
        $entry->update($validated);

        return response()->json([
            'entry' => $entry,
            'message' => 'Entry updated successfully'
        ]);
    }

    public function show($id, ?string $locale = null)
    {
        LangHelper::localeHandler($locale);

        $locale = app()->getLocale();
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;
        $translations = LangHelper::getMultipleTranslations(["diary", "sidebar"]);
        $entry = DiaryEntry::findOrFail($id);

        return Inertia::render('DiaryPost', [
            'entry'        => $entry,
            'translations' => $translations,
            'locale'       => $locale,
            'isAdmin'      => $isAdmin,
        ]);
    }
}
