<?php

namespace App\Http\Controllers;

use App\Traits\LangHelper;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\File;

class UploadController extends Controller
{
    public function index (?string $locale = null)
    {
        LangHelper::localeHandler($locale);
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;
        $translations = LangHelper::getMultipleTranslations(["sidebar", "upload"]);
        return Inertia::render('Upload', [
            'translations' => $translations,
            'isAdmin' => $isAdmin
        ]);
    }

    public function file(Request $request)
    {
        $validated = request()->validate([
            'file' => ['required','file', \Illuminate\Validation\Rules\File::types(['pdf'])],
        ]);

        $name = uniqid() . ".pdf";
        $fakeName = $request->file('file')->getClientOriginalName();
        $path = "storage/".$request->file('file')->storeAs("/files", $name);
        $userid = \Illuminate\Support\Facades\Auth::user()->id;


        $file = new File();
        $file->name = $name;
        $file->fake_name = $fakeName;
        $file->route = $path;
        $file->user_id = $userid;

        $file->save();

        return redirect(route("workspace"));
    }


}
