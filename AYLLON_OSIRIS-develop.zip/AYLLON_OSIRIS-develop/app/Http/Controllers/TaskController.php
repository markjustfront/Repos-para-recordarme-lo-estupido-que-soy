<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Inertia\Inertia;
use App\Traits\LangHelper;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function showTasks(?string $locale = null)
    {
        LangHelper::localeHandler($locale);
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;
        $translations = LangHelper::getMultipleTranslations(["sidebar", "task"]);
        return Inertia::render('Task', [
            'translations' => $translations,
            'isAdmin' => $isAdmin,
        ]);
    }

    public function showCreateForm(?string $locale = null)
    {
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["sidebar", "task"]);
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;
        return Inertia::render('TaskForm', [
            'tasks' => [], // No tasks initially for creation form
            'translations' => $translations,
            'isAdmin' => $isAdmin,
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required',
            'importance' => 'required|integer',
            'description' => 'required',
            'start_time' => 'date',
            'end_time' => 'date|after:start_time',
        ]);

        $task = Task::create([
            'user_id' => Auth::user()->id,
            'title' => $validated['title'],
            'importance' => $validated['importance'],
            'description' => $validated['description'],
            'start_time' => $validated['start_time'],
            'end_time' => $validated['end_time'],
        ]);

        return redirect()->route('tasks.index');
    }

    public function getTasks()
    {
        $tasks = Task::orderBy('created_at', 'desc')->where('user_id', Auth::user()->id)->get();
        return response()->json(['tasks' => $tasks]);
    }

    public function destroy($id)
    {
        $task = Task::findOrFail($id);

        if ($task->user_id === Auth::user()->id) {
            $task->delete();
        }
    }
}
