<?php

namespace App\Http\Controllers;

use App\Traits\LangHelper;
use Illuminate\Foundation\Application;
use Illuminate\Http\RedirectResponse;
use Illuminate\Routing\Redirector;
use Inertia\Inertia;
use Inertia\Response;

class AdminController extends Controller
{
    public function index(?string $locale = null): Response {
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["sidebar", "admin"]);
        return Inertia::render('Admin/Admin', [
            'translations' => $translations,
            'userid' => auth()->id(),
        ]);
    }

    public function translations(?string $locale = null): Response {
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["sidebar", "translations"]);
        $modifiableTranslations = LangHelper::getAllTranslationsFromFile("home");

        return Inertia::render('Admin/Translations', [
            'translations' => $translations,
            'modifiableTranslations' => $modifiableTranslations,
            'csrf_token' => csrf_token(),
        ]);
    }

    public function saveTranslations(): Application|Redirector|RedirectResponse
    {

        $esTranslations = [];
        $enTranslations = [];
        $caTranslations = [];

        foreach (request()->all() as $key => $value) {
            if ($key != "_token") {
                $language = substr($key, 0, 3);
                $realKey = substr($key, 3);
                switch ($language) {
                    case 'es_':
                        $esTranslations[$realKey] = $value;
                        break;
                    case 'en_':
                        $enTranslations[$realKey] = $value;
                        break;
                    case 'ca_':
                        $caTranslations[$realKey] = $value;
                        break;
                    default:
                        break;
                }
            }
        }

        $saveStart = "<?php\n\nreturn [\n";
        $save="";
        $saveEnd = "];\n";

        //ES
        foreach ($esTranslations as $key => $value) {
            if (str_contains($value, "'")) {
                $value =str_replace("'", "\'", $value);
            }
            $save .= "    '" . $key . "' => '" . $value . "',\n";
        }
        file_put_contents(base_path('lang/es/home.php'), $saveStart.$save.$saveEnd);

        //EN
        $save = '';
        foreach ($enTranslations as $key => $value) {
            if (str_contains($value, "'")) {
                $value =str_replace("'", "\'", $value);
            }
            $save .= "    '" . $key . "' => '" . $value . "',\n";
        }
        file_put_contents(base_path('lang/en/home.php'), $saveStart.$save.$saveEnd);

        //CA
        $save = '';
        foreach ($caTranslations as $key => $value) {
            if (str_contains($value, "'")) {
                $value =str_replace("'", "\'", $value);
            }
            $save .= "    '" . $key . "' => '" . $value . "',\n";
        }
        file_put_contents(base_path('lang/ca/home.php'), $saveStart.$save.$saveEnd);



        return redirect(route('admin'));
    }
}
