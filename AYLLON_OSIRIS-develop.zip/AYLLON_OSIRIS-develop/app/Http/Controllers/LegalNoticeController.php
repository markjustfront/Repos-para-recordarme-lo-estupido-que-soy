<?php

namespace App\Http\Controllers;

use App\Traits\LangHelper;
use Illuminate\Http\Request;
use Inertia\Inertia;

class LegalNoticeController extends Controller
{
    public function index (?string $locale = null) 
    { 
        LangHelper::localeHandler($locale);
        $translations = LangHelper::getMultipleTranslations(["messages", "legal", "contact"]);
        return Inertia::render('LegalNotice', [
            'translations' => $translations,
        ]);
    }
}
