<?php

namespace App\Http\Controllers;

use App\Traits\LangHelper;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;
use App\Models\Person;
use Illuminate\Support\Facades\DB;

class PeopleController extends Controller
{
    public function index(?string $locale = null) : \Inertia\Response {
        LangHelper::localeHandler($locale);
        $isAdmin = \Illuminate\Support\Facades\Auth::user()->role == 0 ? true : false;
        return Inertia::render('PeopleForm', [
            'translations' => LangHelper::getMultipleTranslations(["sidebar", "people"]),
            'isAdmin' => $isAdmin,
        ]);

    }

    //Controller to collect the data from the form
    public function peopleform(Request $request) {
        //dd(request()->all());
        $validated = request()->validate([
            'name' => 'required',
            'lastname' => 'required',
            'description' => 'required',
            'birthday' => 'nullable|date',
            'relationship' => 'required',
            //'image' => 'required|image',
            'image' => 'nullable',
        ]);
        $userid = Auth::user()->id;
        $name = uniqid() . ".png";
        $person = new Person();
        $person -> name = $validated['name'];
        $person -> lastname = $validated['lastname'];
        $person -> description = $validated['description'];
        $person -> birthday = $validated['birthday'];
        $person -> relationship = $validated['relationship'];
        $person -> image = "storage/".$request->file('image')->storeAs("/images", $name);
        $person -> user_id = $userid;

        $person->save();
        $id = $person -> id;
        $person -> user_id = $id;

        return Inertia::location(route('dashboard'));
    }

    public function destroypeople($id)
    {
        $person = Person::all()->find($id);
        $personImage = $person->image;
        unlink($personImage);
        $person->delete();
        return response()->json([
            'message' => 'Persona eliminada exitosamente',
            'people' => Person::all()
        ]);
    }


}
