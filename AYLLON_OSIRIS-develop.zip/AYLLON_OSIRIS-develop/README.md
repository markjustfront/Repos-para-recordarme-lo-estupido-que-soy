# Osiris(English)

Osiris is your ultimate productivity companion, designed to help you organize your day with ease and efficiency. You can create tasks, manage your time, access PDF files, and keep a personal journal. It also includes study tools based on the Pomodoro technique, an AI chatbot for assistance, and a comprehensive user management system for managers and administrators.

## 🚀 Features

- 🌐 **Multilingual interface** with language switch.
- 🏡 **Dashboard:** Manage your tasks, calendar, and important people.
- 📝 **Personal Journal:** Store your daily thoughts and achievements
- 📄 **PDF Document Manager:** Upload, search, and read your files with ease.
- ⏰ **Pomodoro Study Space:** Configurable timer to improve focus.
- 🧠 **AI Assistant:** Automatic summaries and personalized study plans.
- 🔑 **Advanced Security:** Session control, profile editing, and account management.
- 👥 **User Management for Managers:** Assign tasks to users and manage shared files.
- 🛠 **Admin Panel:** User, contact, and system statistics management.
- 🌍 **Translation System:** Upload files with automatic translation to Spanish, Catalan, and English.

## 🔧 Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/ABP-2n-DAW-24-25/2-OSIRIS
   cd osiris
   ```
2. Install dependencies:
   ```bash
   sail npm install
   ```
3. Start the application:
   ```bash
   sail npm start
   ```
4. Build with:
   ```bash
   sail npm run build
   ```

## 📚 Usage

1. **Registration and Login:** Access with your account.
2. **Dashboard:** Manage tasks, calendar, and contacts.
3. **Personal Journal:** Write and save your reflections.
4. **PDF Manager:** Upload, search, and read documents.
5. **Pomodoro Study:** Set sessions and use the timer.
6. **AI Assistant:** Use AI for summaries or study plans.
7. **Account Management:** Edit profile, change password, or delete account.
8. **User Management (Managers):** Assign tasks to users with details like task name, due date, and description.
9.  **Admin Panel:** Monitor users, managers, uploaded files, and recorded study times.
10. **Translation:** Upload files and get automatic translation to multiple languages.

## 🤝 Contributing

1. Fork the repository.
2. Create a branch (`git checkout -b new-feature`).
3. Make changes and commit (`git commit -m "New feature"`).
4. Push the changes (`git push origin new-feature`).
5. Open a Pull Request.
6. Wait for the repository owner’s response.



# Osiris(Català)

Osiris és el teu company de productivitat definitiu, dissenyat per ajudar-te a organitzar el teu dia amb facilitat i eficiència. Pots crear tasques, gestionar el teu temps, accedir a fitxers PDF i mantenir un diari personal. A més, inclou eines d'estudi basades en la tècnica Pomodoro, un chatbot d'IA per a assistència i un sistema complet de gestió d'usuaris per a managers i administradors.

## 🚀 Característiques

- 🌐 **Interfície multilingüe** amb canvi d'idioma.
- 🏡 **Tauler de control:** Gestiona les teves tasques, calendari i persones importants.
- 📝 **Diari personal:** Desa els teus pensaments i assoliments diaris.
- 📄 **Gestor de documents PDF:** Puja, cerca i llegeix els teus fitxers amb facilitat.
- ⏰ **Espai d'estudi Pomodoro:** Temporitzador configurable per millorar la concentració.
- 🧠 **Assistent d'IA:** Resums automàtics i plans d'estudi personalitzats.
- 🔑 **Seguretat avançada:** Control de sessió, edició de perfil i gestió del compte.
- 👥 **Gestió d'usuaris per a Managers:** Assigna tasques a usuaris i gestiona fitxers compartits.
- 🛠 **Panell d'Administrador:** Gestió d'usuaris, contactes i estadístiques del sistema.
- 🌍 **Sistema de Traducció:** Upload files with automatic translation to Spanish, Catalan, and English.Puja fitxers amb traducció automàtica a espanyol, català i anglès.

## 🔧 Instal·lació

1. Clona el repositori:
   ```bash
   git clone https://github.com/ABP-2n-DAW-24-25/2-OSIRIS
   cd osiris
   ```
2. Instal·la les dependències:
   ```bash
   sail npm install
   ```
3. Inicia l'aplicació:
   ```bash
   sail npm start
   ```
4. Compila amb::
   ```bash
   sail npm run build
   ```

## 📚 Ús

1. **Registre i inici de sessió:** Accedeix amb el teu compte.
2. **Tauler de control:** Gestiona tasques, calendari i contactes.
3. **Diari personal:** Escriu i desa les teves reflexions.
4. **Gestor de PDF:** Puja, cerca i llegeix documents.
5. **Estudi Pomodoro:** Configura sessions i utilitza el temporitzador.
6. **Assistent d'IA:** Utilitza la IA per a resums o plans d'estudi.
7. **Gestió del compte:** Edita el perfil, canvia la contrasenya o elimina el compte.
8. **Gestió d'usuaris (Managers):** Assigna tasques als usuaris amb detalls com el nom de la tasca, data de venciment i descripció.
9. **Panell d'Administrador:** Monitora usuaris, managers, fitxers pujats i temps d'estudi registrats.
10. **Traducció:** Puja fitxers i obté traducció automàtica a diversos idiomes.

## 🤝 Contribució

1. Fes un fork del repositori.
2. Crea una branca (`git checkout -b nova-funcionalitat`).
3. Fes els canvis i commit (`git commit -m "Nova funcionalitat"`).
4. Puja els canvis (`git push origin nova-funcionalitat`).
5. Obre un Pull Request.
6.  la resposta del propietari del repositori.




# Osiris(Español)

Osiris es tu compañero definitivo de productividad, diseñado para ayudarte a organizar tu día con facilidad y eficiencia. Puedes crear tareas, gestionar tu tiempo, acceder a archivos PDF y mantener un diario personal. Además, incluye herramientas de estudio basadas en la técnica Pomodoro, un chatbot de IA para asistencia y un completo sistema de gestión de usuarios para managers y administradores.

## 🚀 Características

- 🌐 **Interfaz multilingüe** con cambio de idioma.
- 🏡 **Panel de control (Dashboard):** Gestiona tus tareas, calendario y personas importantes.
- 📝 **Diario personal:** Guarda tus pensamientos y logros diarios.
- 📄 **Gestor de documentos PDF:** Sube, busca y lee tus archivos con facilidad.
- ⏰ **Espacio de estudio con Pomodoro:** Temporizador configurable para mejorar la concentración.
- 🧠 **Asistente de IA:** Resúmenes automáticos y planes de estudio personalizados.
- 🔑 **Seguridad avanzada:** Control de sesión, edición de perfil y gestión de cuenta.
- 👥 **Gestión de usuarios para Managers:** Asignación de tareas a usuarios y administración de archivos compartidos.
- 🛠 **Panel de Administrador:** Gestión de usuarios, contactos y estadísticas del sistema.
- 🌍 **Sistema de Traducción:** Subida de archivos con traducción automática a español, catalán e inglés.

## 🔧 Instalación

1. Clona el repositorio:
   ```bash
   git clone https://github.com/ABP-2n-DAW-24-25/2-OSIRIS
   cd osiris
   ```
2. Instala las dependencias:
   ```bash
   sail npm install
   ```
3. Inicia la aplicación:
   ```bash
   sail npm start
   ```
4. Compila con:
   ```bash
   sail npm run build
   ```

## 📚 Uso

1. **Registro e inicio de sesión:** Accede con tu cuenta.
2. **Panel de control:** Administra tareas, calendario y contactos.
3. **Diario personal:** Escribe y guarda tus reflexiones.
4. **Gestor de PDF:** Sube, busca y lee documentos.
5. **Estudio Pomodoro:** Configura sesiones y usa el temporizador.
6. **Asistente de IA:** Usa la IA para resúmenes o planes de estudio.
7. **Gestión de cuenta:** Edita perfil, cambia contraseña o elimina la cuenta.
8. **Gestión de usuarios (Managers):** Asigna tareas a usuarios, con detalles como nombre de la tarea, fecha de vencimiento y descripción.
9. **Panel de Administrador:** Monitorea usuarios, managers, archivos subidos y tiempos de estudio registrados.
10. **Traducción:** Subida de ficheros y traducción automática a varios idiomas.

## 🤝 Contribución

1. Haz un fork del repositorio.
2. Crea una rama (`git checkout -b nueva-funcionalidad`).
3. Realiza cambios y haz un commit (`git commit -m "Nueva funcionalidad"`).
4. Sube los cambios (`git push origin nueva-funcionalidad`).
5. Abre un Pull Request.
6. Espera a la respuesta del dueño del repositorio.



