<?php

use App\Http\Controllers\CRUD\ActivityCrudController;
use App\Http\Controllers\CRUD\MonitorCrudController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MonitorController;
use App\Http\Controllers\CRUD\TutorCrudController;
use App\Http\Controllers\TutorController;
use App\Http\Middleware\AdminMiddleware;
use App\Http\Middleware\MonitorMiddleware;
use App\Http\Controllers\DefaulterController;
use App\Http\Controllers\CRUD\DefaulterCrudController;
use App\Http\Controllers\CRUD\IncidencesCrudController;
use Inertia\Inertia;
use App\Models\User;
use App\Http\Controllers\CRUD\ParticipantCrudController;
use App\Http\Controllers\ParticipantController;
use App\Http\Controllers\DashboardController;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Auth;

Route::get('/', function () {
    return Inertia::render('Auth/Login');
});

// Dashboard
Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', AdminMiddleware::class])->name('dashboard');

// API
Route::get('/api/test', function () {
    return true;
});
Route::get('/api/tutor', [TutorCrudController::class, 'read'])->middleware(['auth'])->name('tutor.read');
Route::get('/api/tutor/name', [TutorCrudController::class, 'tutors'])->middleware(['auth'])->name('tutor.name');
Route::get('/api/participant', [ParticipantCrudController::class, 'index'])->middleware(['auth', MonitorMiddleware::class])->name('participant.api');
Route::get('/api/monitor', [MonitorCrudController::class, 'index'])->middleware(['auth', AdminMiddleware::class])->name('monitor.api');
Route::get('/api/defaulter', [DefaulterCrudController::class, 'read'])->name('defaulter.read');
Route::get('/api/participants/notDefaulters', [ParticipantCrudController::class, 'getParticipantsNotDefaulters'])->name('participants.not.defaulters');
Route::get('/api/incidence',[IncidencesCrudController::class, 'index'])->middleware(['auth', MonitorMiddleware::class])->name('incidence.api');
Route::get('/api/activities', [ActivityCrudController::class, 'index'])->middleware(['auth', MonitorMiddleware::class])->name('activities.api');

// Tutors
Route::get('/tutors', [TutorController::class, 'tutorsList'])->middleware(['auth', 'verified'])->name('tutor.index');
Route::get('/tutor/add', [TutorController::class, 'tutorForm'])->middleware('auth')->name('tutor.form');
Route::post('/tutor/add', [TutorCrudController::class, 'create'])->middleware('auth')->name('tutor.create');
Route::delete('/tutor/delete', [TutorCrudController::class, 'delete'])->middleware(['auth', 'verified'])->name('tutor.delete');
Route::delete('/tutor/delete/massive', [TutorCrudController::class, 'deleteAllCheckbox'])->middleware([AdminMiddleware::class])->name('tutor.delete-massive');
Route::patch('/tutor/update', [TutorCrudController::class, 'update'])->middleware(['auth', 'verified'])->name('tutor.update');

// Incidences WIP
//Route::get('/incidences', [\App\Http\Controllers\IncidencesController::class, 'index'])->middleware(['auth', MonitorMiddleware::class])->name('incidence.index');
Route::get('/incidence/add', [\App\Http\Controllers\IncidencesController::class, 'createForm'])->middleware(['auth', MonitorMiddleware::class])->name('incidence.form');
Route::post('/incidence/add', [\App\Http\Controllers\CRUD\IncidencesCrudController::class, 'create'])->middleware(['auth', MonitorMiddleware::class])->name('incidence.create');
Route::delete('/incidence/delete', [\App\Http\Controllers\CRUD\IncidencesCrudController::class, 'delete'])->middleware(['auth', MonitorMiddleware::class])->name('incidence.delete');

// Participants
Route::get('/participants', [ParticipantController::class, 'index'])->middleware([MonitorMiddleware::class])->name('participant.index');
Route::get('/participant/add', [ParticipantController::class, 'createForm'])->name('participant.form');
Route::post('/participant/add', [ParticipantCrudController::class, 'create'])->name('participant.create');
Route::patch('/participant/update', [ParticipantCrudController::class, 'update'])->name('participant.update');
Route::delete('/participant/delete', [ParticipantCrudController::class, 'delete'])->name('participant.delete');
Route::delete('/participant/delete/massive', [ParticipantCrudController::class, 'deleteAllCheckboxedParticipants'])->name('participant.delete-massive');
//Route::get('participant/{id}', [ParticipantController::class, 'show'])->middleware(['auth', AdminMiddleware::class])->name('participant.show');

// Monitor
Route::get('/monitors', [MonitorController::class, 'index'])->middleware(['auth', AdminMiddleware::class])->name('monitor.index');
Route::get('/monitor/add', [MonitorController::class, 'show'])->middleware(['auth', AdminMiddleware::class])->name('monitors.show');
Route::post('/monitor/add', [MonitorCrudController::class, 'create'])->middleware(['auth', AdminMiddleware::class])->name('monitors.create');
Route::patch('/monitor/update', [MonitorCrudController::class, 'update'])->middleware(['auth', AdminMiddleware::class])->name('monitor.update');
Route::delete('/monitor/delete', [MonitorCrudController::class, 'delete'])->middleware(['auth', AdminMiddleware::class])->name('monitor.delete');
Route::delete('/monitor/delete/massive', [MonitorCrudController::class, 'deleteAllCheckbox'])->middleware(['auth', AdminMiddleware::class])->name('monitor.delete-massive');

// Meetings WIP
//Route::get('/meetings', [MeetingController::class, 'index'])->middleware(['auth', AdminMiddleware::class])->name('meeting.index');
//Route::get('/meeting/add', [MeetingController::class, 'createForm'])->middleware(['auth', AdminMiddleware::class])->name('meeting.create');
//Route::post('/meeting/add', [MeetingCrudController::class, 'create'])->middleware(['auth', AdminMiddleware::class])->name('meeting.create');

// Activities
Route::get('/activities', [\App\Http\Controllers\ActivityController::class, 'index'])->middleware(['auth', MonitorMiddleware::class])->name('activity.index');
Route::get('/activity/add', [\App\Http\Controllers\ActivityController::class, 'create'])->middleware(['auth', MonitorMiddleware::class])->name('activity.form');
Route::post('/activity/add', [\App\Http\Controllers\CRUD\ActivityCrudController::class, 'create'])->middleware(['auth', MonitorMiddleware::class])->name('activity.create');
Route::patch('/activity/update', [\App\Http\Controllers\CRUD\ActivityCrudController::class, 'update'])->middleware(['auth', MonitorMiddleware::class])->name('activity.update');
Route::delete('/activity/delete', [\App\Http\Controllers\CRUD\ActivityCrudController::class, 'delete'])->middleware(['auth', AdminMiddleware::class])->name('activity.delete');
Route::delete('/activity/delete/massive', [\App\Http\Controllers\CRUD\ActivityCrudController::class, 'deleteAllCheckbox'])->middleware(['auth', AdminMiddleware::class])->name('activity.delete-massive');
Route::get('/activity/{id}', [\App\Http\Controllers\ActivityController::class, 'show'])->middleware(['auth', AdminMiddleware::class])->name('activity.show');

// Defaulters
Route::get('/defaulters', [DefaulterController::class, 'index'])->middleware(['auth', AdminMiddleware::class])->name('defaulter.index');
Route::post('/defaulter/add', [DefaulterCrudController::class, 'create'])->middleware(['auth', AdminMiddleware::class])->name('defaulter.create');
Route::delete('/defaulter/delete', [DefaulterCrudController::class, 'delete'])->middleware(['auth', AdminMiddleware::class])->name('defaulter.delete');

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

//Treasury
Route::get('/treasury', [\App\Http\Controllers\TreasuryController::class, 'index'])->middleware(['auth',AdminMiddleware::class])->name('treasury.index');

// GitHub Oauth
Route::get('/auth/github', function () {
    return \Laravel\Socialite\Facades\Socialite::driver('github')->redirect();
});

Route::get('/callback/github', function () {
    $githubUser = Socialite::driver('github')->user();

    $user = \App\Models\User::all()->where('email', $githubUser->getEmail())->first();

    if (!$user) {
        return redirect('/login');
    } else {
        \Illuminate\Support\Facades\Auth::login($user);
        return redirect()->intended('/dashboard');
    }
});

// Login with Google
Route::get('login-google', function () {
    return Socialite::driver('google')->redirect('');
})->name('login-google');

Route::get('google-callback', function () {
    $user = Socialite::driver('google')->user();

    $userExists = User::where('email', $user->email)->first();
    if ($userExists) {
        Auth::login($userExists);
        return redirect('/dashboard');
    }else {
        return redirect('/login');
    }
});

// X Oauth
Route::get('/auth/x', function () {
    return \Laravel\Socialite\Facades\Socialite::driver('twitter')->redirect();
});

Route::get('/callback/x', function () {
    $xUser = Socialite::driver('twitter')->user();

    $user = \App\Models\User::all()->where('email', $xUser->getEmail())->first();

    if (!$user) {
        return redirect('/login');
    } else {
        \Illuminate\Support\Facades\Auth::login($user);
        return redirect()->intended('/dashboard');
    }
});

// Reddit Oauth
Route::get('/auth/reddit', function () {
    return Socialite::driver('reddit')->redirect();
});

Route::get('/callback/reddit', function () {
    $redditUser = Socialite::driver('reddit')->user();

    $user = \App\Models\User::all()->where('email', $redditUser->getEmail())->first();

    if (!$user) {
        return redirect('/login');
    } else {
        \Illuminate\Support\Facades\Auth::login($user);
        return redirect()->intended('/dashboard');
    }
});

// Login with facebook
Route::get('login-facebook', function () {
    return Socialite::driver('facebook')->redirect('');
})->name('login-facebook');

Route::get('facebook-callback', function () {
    $user = Socialite::driver('facebook')->user();

    $userExists = User::where('email', $user->email)->first();
    if ($userExists) {
        Auth::login($userExists);
        return redirect('/dashboard');
    }else {
        return redirect('/login');
    }
});

require __DIR__ . '/auth.php';
