// import defaultTheme from 'tailwindcss/defaultTheme';
// import forms from '@tailwindcss/forms';

// /** @type {import('tailwindcss').Config} */
// export default {
//     content: [
//         './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
//         './storage/framework/views/*.php',
//         './resources/views/**/*.blade.php',
//         './resources/js/**/*.vue',
//     ],

//     theme: {
//         extend: {
//             fontFamily: {
//                 sans: ['Lexend', ...defaultTheme.fontFamily.sans],
//             },
//             colors: {
//                 primary: '#4da3a0',
//                 secondary: '#8dc4c2',
//                 light_secondary: '#BEDBDA',
//                 notwhite: '#5e5e5e',
//                 mclaren: '#ff8000',
//                 dashboard: '#DBEDEC'
//             },
//             screens:{
//                 ssm: '550px',
//             }
//         },
//     },

//     plugins: [forms],
// };

import forms from '@tailwindcss/forms';
import defaultTheme from 'tailwindcss/defaultTheme';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
        './resources/js/**/*.vue',
    ],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Lexend', ...defaultTheme.fontFamily.sans],
            },
            colors: {
                primary: '#487f7d', // Updated from #4ca29f
                secondary: '#679e9c', // Updated from #8dc4c2
                light_secondary: '#BEDBDA',
                notwhite: '#5e5e5e',
                mclaren: '#b95d00', // Updated from #ff8000 for 2.52:1 issue
                dashboard: '#DBEDEC',
            },
            screens: {
                ssm: '550px',
            },
        },
    },
    plugins: [forms],
};
