<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Meeting>
 */
class MeetingFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            "type" => $this->faker->randomElement(["board", "member", "monitor"]),
            "route" => $this->faker->url(),
            "assistants" => [
                "type" => $this->faker->randomElement(["dennis", "pau", "moncayo"]),
                "name" => $this->faker->name(),
                "id" => $this->faker->randomNumber(1),
            ],
            "observations" => json_encode([
                'observation' => $this->faker->sentence(),
            ]),
            "date" => $this->faker->dateTime(),
            "place" => $this->faker->address(),
        ];
    }
}
