<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Activity>
 */
class ActivityFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $participants = array();
        for ($i = 0; $i < 10; $i++) {
            $participants[] = $this->faker->randomNumber();
        }
        $monitorsInfo = array();
        for ($i = 0; $i < 10; $i++) {
            $monitorsInfo[] = [
                'id' => $this->faker->randomNumber(),
                'responsable' => $i == 0 ? true : false,
                'plus' => $i == 0 ? 150 : 0,
            ];
        }
        $collaborations = array();
        for ($i = 0; $i < 10; $i++) {
            $collaborations[] = [
                'name' => $this->faker->company(),
                'link' => $this->faker->url(),
            ];
        }

        $startTime = $this->faker->dateTime();
        $nonMemberPrice = $this->faker->numberBetween(100, 1000);
        return [
            'name' => $this->faker->name(),
            'start_time' => $startTime,
            'end_time' => (clone $startTime)->modify('+' . rand(1, 24) . ' hours'),
            'place' => $this->faker->address(),
            'member_price' => $nonMemberPrice - 100,
            'nonmember_price' => $nonMemberPrice,
            'monitor_salary' => $this->faker->numberBetween(9.26, 100),
            'participants_id' => json_encode($participants),
            'monitors_info' => json_encode($monitorsInfo),
            'collaborations' => json_encode($collaborations),
            'description' => $this->faker->paragraph(),
        ];
    }
}
