<?php

namespace Database\Factories;

use App\Models\Tutor;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Monitor>
 */
class MonitorFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => $this->faker->name(),
            'surnames' => $this->faker->lastName() . ' ' . $this->faker->lastName(),
            'birthday' => $this->faker->dateTimeBetween('-50 years', '-18 years'),
            'direction' => $this->faker->address(),
            'entry_year' => $this->faker->year(),
            'active' => true,
            'last_activity' => null,
            'study_level' => $this->faker->numberBetween(0,4),
            'monitor_permit' => $this->faker->boolean(),
            'email' => $this->faker->unique()->safeEmail(),
            'phonenumber' => $this->faker->numerify('9########'),
            'role' => $this->faker->randomElement(['coordinator', 'responsable', 'monitor', 'volunteer']),
            'contract_start' => $this->faker->dateTimeBetween('-5 years', 'now'),
            'contract_end' => $this->faker->dateTimeBetween('now', '+5 years'),
            'tutor_id' => fn() => Tutor::inRandomOrder()->first()->id ?? Tutor::factory()->create()->id,

            'dni' => function () {
                $number = str_pad($this->faker->numberBetween(1, 99999999), 8, '0', STR_PAD_LEFT);
                $letters = "TRWAGMYFPDXBNJZSQVHLCKE";
                $letter = $letters[intval($number) % 23];
                return $number . $letter;
            },
        ];
    }
}
