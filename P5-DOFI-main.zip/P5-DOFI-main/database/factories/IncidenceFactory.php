<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Incidence;
use App\Models\Monitor;
use App\Models\Participant;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Incidence>
 */
class IncidenceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'type' => $this->faker->randomElement(['Crisis epilèptiques', 'Alteració conductual', 'Altres']),
            'description' => $this->faker->text(),
            'actuation' => $this->faker->text(),
            'date' => $this->faker->date(),
            'time' => $this->faker->time(),
            'monitor_id' => Monitor::factory()->create()->id,
            'participant_id' => Participant::factory()->create()->id,
        ];
    }
}
