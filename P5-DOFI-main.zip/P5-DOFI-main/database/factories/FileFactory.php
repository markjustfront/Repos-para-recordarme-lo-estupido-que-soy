<?php

namespace Database\Factories;
use App\Models\Participant;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\File>
 */
class FileFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'for'=>$this->faker->randomElement(["monitor", "participant","board"]),
            'type'=>$this->faker->word(),
            'route'=>$this->faker->word(),
            'participant_id' => Participant::factory()->create()->id,
            'monitor_id' => null,
        ];
    }
}
