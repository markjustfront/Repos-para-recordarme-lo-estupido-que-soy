<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Monitor;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\BankData>
 */
class BankDataFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'for'=>'monitor',
            'iban'=>$this->faker->word(),
            'name'=>$this->faker->word(),
            'nass'=>$this->faker->word(),
            'monitor_id' => Monitor::factory()->create()->id,
            'participant_id' => null,
        ];
    }
}
