<?php

namespace Database\Factories;

use App\Models\Tutor;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Participant>
 */
class ParticipantFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'dni' => $this->faker->unique()->randomNumber(9),
            'name' => $this->faker->name(),
            'surnames' => $this->faker->lastName(),
            'birthday' => $this->faker->date(),
            'direction' => $this->faker->address(),
            'entry_year' => $this->faker->numberBetween(1990, 2025),
            'member' => $this->faker->randomElement([true, false]),
            'cash' => $this->faker->randomElement([true, false]),
            'active' => true,
            'relationship' => $this->faker->randomElement(['parent', 'uncle', 'brother', 'sister']),
            'educational_sheet' => $this->faker->text(250),
            'tutor_id' => Tutor::factory()->create()->id,
        ];
    }
}
