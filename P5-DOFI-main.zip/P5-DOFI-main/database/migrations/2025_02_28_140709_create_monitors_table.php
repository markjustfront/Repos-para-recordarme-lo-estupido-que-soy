<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use phpDocumentor\Reflection\Types\Nullable;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('monitors', function (Blueprint $table) {
            $table->id();
            $table->string('dni')->unique();
            $table->string('name');
            $table->string('surnames');
            $table->date('birthday');
            $table->string('direction');
            $table->year('entry_year');
            $table->boolean('active');
            $table->date('last_activity')->nullable();
            $table->string('study_level')->nullable();
            $table->boolean('monitor_permit');
            $table->string('email')->unique();
            $table->string('phonenumber');
            $table->ENUM('role', ['coordinator', 'responsable', 'monitor','volunteer'])->default('monitor');
            $table->date('contract_start');
            $table->date('contract_end');
            $table->foreignId('tutor_id')->nullable()->constrained('tutors');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('monitors');
    }
};
