<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            DefaulterSeeder::class,
            DocumentationSeeder::class,
            MedicalDataSeeder::class,
            MeetingSeeder::class,
            MonitorSeeder::class,
            ParticipantSeeder::class,
            TutorSeeder::class,
            UserSeeder::class,
            AdminSeeder::class,
            ActivitySeeder::class,
            FileSeeder::class,
            BankDataSeeder::class,
            ActivityMemorySeeder::class,
            IncidencesSeeder::class,
        ]);
    }
}
