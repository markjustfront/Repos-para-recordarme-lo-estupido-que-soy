<?php

namespace Database\Seeders;

use App\Models\MedicalData;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class MedicalDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Use the Medical Data Factory to seed the database
        MedicalData::factory(5)->create();
    }
}
