<?php

namespace Database\Seeders;

use App\Models\ActivityMemory;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ActivityMemorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        ActivityMemory::factory(5)->create();
    }
}
