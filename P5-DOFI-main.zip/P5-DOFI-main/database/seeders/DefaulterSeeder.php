<?php

namespace Database\Seeders;

use App\Models\Defaulter;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DefaulterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Use the Defaulter Factory to seed the database
        Defaulter::factory(5)->create();
    }
}
