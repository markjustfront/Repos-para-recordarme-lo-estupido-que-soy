<?php

declare(strict_types=1);

return [
    'next'     => 'Siguiente &raquo;',
    'previous' => '&laquo; Anterior',
];
