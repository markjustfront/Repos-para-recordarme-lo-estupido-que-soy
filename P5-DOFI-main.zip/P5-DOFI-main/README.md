## El dofí (Català)

El dofí és un projecte especial per a l’organització **Associació El Dofí**. Es tracta d’una intranet real pensada per a facilitar el dia a dia dels treballadors de l’entitat. Respon a necessitats concretes com l’emmagatzematge segur d’informació sensible (com comptes bancaris i informes mèdics), una organització clara dels documents, i la gestió intuïtiva de llistats.

🚀 **Característiques**  
🔐 Emmagatzematge segur: Informació mèdica i financera protegida.  
📁 Organització de documents: Gestor d’arxius senzill i eficient.  
📋 Gestió de llistats: Crea, edita i consulta llistats de manera intuïtiva.  
👥 Gestió d’usuaris: Diferents rols i permisos segons el perfil.  
🌐 Interfície clara i adaptada: Disseny pensat per a l’ús diari i àgil.  

🔧 **Instal·lació**  
Clona el repositori:  
```bash  
git clone https://github.com/El-Dofi/Intranet-Dofi  
cd Intranet-Dofi  
```  

Add composer:
```bash  
composer install  
```  

Instal·la les dependències:  
```bash  
npm install  
```  

Inicia l’aplicació:  
```bash  
npm run dev  
```  

Compila per producció:  
```bash  
npm run build  
```  

---


## El Dofí (English)

El Dofí is a special project created for the **Associació El Dofí**. It is a real intranet designed to make the daily work of the organization’s staff easier. It addresses specific needs such as secure storage of sensitive information (like bank accounts and medical reports), a clear structure for document management, and an intuitive list management system.

🚀 **Features**  
🔐 Secure storage: Protected medical and financial information.  
📁 Document organization: Simple and efficient file manager.  
📋 List management: Create, edit, and view lists easily.  
👥 User management: Roles and permissions based on user profiles.  
🌐 Clear and accessible interface: Designed for quick daily use.  

🔧 **Installation**  
Clone the repository:  
```bash  
git clone https://github.com/El-Dofi/Intranet-Dofi  
cd Intranet-Dofi  
```  

Add composer:
```bash  
composer install  
```  

Install dependencies:  
```bash  
npm install  
```  

Start the application:  
```bash  
npm run dev  
```  

Build for production:  
```bash  
npm run build  
```  
