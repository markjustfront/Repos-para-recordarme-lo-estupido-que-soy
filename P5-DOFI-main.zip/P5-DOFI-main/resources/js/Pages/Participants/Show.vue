<script setup>
import { Head } from '@inertiajs/vue3';
import axios from 'axios';
import { ref } from 'vue';
import LoadingAnimation from '@/Components/LoadingAnimation.vue';
import BackButton from '@/Components/BackButton.vue';
import FormButton from '@/Components/FormButton.vue';

const member = ref();
const active = ref();
const cash = ref();

const props = defineProps({
    participant: Object,
});

if (props.participant.member === 0) member.value = 'No';
else if (props.participant.member === 1) member.value = 'Sí';

if (props.participant.active === 0) active.value = 'No';
else if (props.participant.active === 1) active.value = 'Sí';

if (props.participant.cash === 0) cash.value = 'No';
else if (props.participant.cash === 1) cash.value = 'Sí';
</script>

<template>
    <Head title="Participant" />
    <BackButton
        url="/tutor/dashboard"
        aria-label="Tornar al tauler del tutor"
        class="focus:outline-none focus:ring-2 focus:ring-mclaren"
    />
    <div
        class="mt-56 flex h-screen grid-rows-2 flex-col items-center justify-center sm:mt-0"
    >
        <div
            class="h-auto w-4/6 items-center justify-center rounded-md bg-secondary sm:h-4/5"
        >
            <div class="grid h-full w-full grid-rows-11 sm:grid-rows-6">
                <div class="flex items-center justify-center">
                    <h1 class="text-3xl font-semibold uppercase text-white">
                        Detalls de {{ props.participant.name }}
                    </h1>
                </div>
                <dl
                    class="row-span-10 grid grid-cols-1 gap-4 p-4 sm:row-span-5 sm:grid-cols-2"
                >
                    <div
                        class="col-span-1 flex flex-col items-center justify-center"
                    >
                        <dt class="font-semibold text-white">Cognom</dt>
                        <dd
                            class="mx-5 mb-4 mt-4 w-full rounded-md bg-white py-2 text-center font-semibold"
                        >
                            {{ props.participant.surnames }}
                        </dd>
                        <dt class="font-semibold text-white">DNI</dt>
                        <dd
                            class="mx-5 mb-12 mt-4 w-full rounded-md bg-white py-2 text-center font-semibold"
                        >
                            {{ props.participant.dni }}
                        </dd>
                        <dt class="font-semibold text-white">Aniversari</dt>
                        <dd
                            class="mx-5 mb-4 mt-4 w-full rounded-md bg-white py-2 text-center font-semibold"
                        >
                            {{ props.participant.birthday }}
                        </dd>
                        <dt class="font-semibold text-white">Relació</dt>
                        <dd
                            class="mx-5 mb-4 mt-4 w-full rounded-md bg-white py-2 text-center font-semibold sm:mb-[70px]"
                        >
                            {{ props.participant.relationship }}
                        </dd>
                    </div>
                    <div
                        class="col-span-1 flex flex-col items-center justify-center"
                    >
                        <dt class="font-semibold text-white">Direcció</dt>
                        <dd
                            class="mx-5 my-4 w-full rounded-md bg-white py-2 text-center font-semibold"
                        >
                            {{ props.participant.direction }}
                        </dd>
                        <div
                            class="grid w-full grid-cols-2 items-center justify-center"
                        >
                            <dt
                                class="flex w-full justify-center text-center font-semibold text-white"
                            >
                                Any
                            </dt>
                            <dt
                                class="flex w-full justify-center text-center font-semibold text-white"
                            >
                                Membre?
                            </dt>
                        </div>
                        <div class="grid w-full grid-cols-2">
                            <dd class="flex w-full justify-center">
                                <div
                                    class="my-4 mr-2 w-full rounded-md bg-white py-2 text-center font-semibold"
                                >
                                    {{ props.participant.entry_year }}
                                </div>
                            </dd>
                            <dd class="flex w-full justify-center">
                                <div
                                    class="my-4 ml-2 w-full rounded-md bg-white py-2 text-center font-semibold"
                                >
                                    {{ member }}
                                </div>
                            </dd>
                        </div>
                        <div class="mt-8 grid w-full grid-cols-2">
                            <dt
                                class="flex w-full justify-center text-center font-semibold text-white"
                            >
                                Actiu?
                            </dt>
                            <dt
                                class="flex w-full justify-center text-center font-semibold text-white"
                            >
                                Efectiu?
                            </dt>
                        </div>
                        <div class="grid w-full grid-cols-2">
                            <dd class="flex w-full justify-center">
                                <div
                                    class="my-4 mr-2 w-full rounded-md bg-white py-2 text-center font-semibold"
                                >
                                    {{ active }}
                                </div>
                            </dd>
                            <dd class="flex w-full justify-center">
                                <div
                                    class="my-4 ml-2 w-full rounded-md bg-white py-2 text-center font-semibold"
                                >
                                    {{ cash }}
                                </div>
                            </dd>
                        </div>
                        <dt class="font-semibold text-white">
                            Fitxa Educativa
                        </dt>
                        <dd
                            class="mx-5 my-4 w-full rounded-md bg-white text-center font-semibold"
                        >
                            {{ props.participant.educational_sheet }}
                        </dd>
                    </div>
                </dl>
            </div>
        </div>
        <div class="mt-5 grid w-4/6 grid-cols-2">
            <div class="flex justify-center">
                <FormButton
                    class="focus:outline-none focus:ring-2 focus:ring-mclaren"
                >
                    Visualitzar Activitats
                </FormButton>
            </div>
            <div class="flex justify-center">
                <FormButton
                    class="focus:outline-none focus:ring-2 focus:ring-mclaren"
                >
                    Visualitzar Documents
                </FormButton>
            </div>
        </div>
    </div>
</template>
