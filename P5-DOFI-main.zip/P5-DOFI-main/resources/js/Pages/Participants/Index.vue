<script setup>
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { ref, onMounted, computed, nextTick } from 'vue';
import axios from 'axios';
import { Head, Link } from '@inertiajs/vue3';
import LoadingAnimation from '@/Components/LoadingAnimation.vue';
import SearchBar from '@/Components/SearchBar.vue';

const participants = ref([]);
const checkedParticipants = ref([]);
const showInfoModal = ref(false);
const showEditModal = ref(false);
const selectedParticipant = ref(null);
const editableParticipant = ref(null);
const participantsLoaded = ref(false);
const infoModal = ref(null);
const editModal = ref(null);
const input = ref('');

// Toggle all checkboxes
const toggleCheckboxAll = () => {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    const newState =
        checkedParticipants.value.length !== participants.value.length;
    checkedParticipants.value = newState
        ? [...Array(participants.value.length).keys()]
        : [];
    checkboxes.forEach((checkbox) => (checkbox.checked = newState));
};

// Toggle participant selection
const toggleParticipantSelection = (index) => {
    const position = checkedParticipants.value.indexOf(index);
    if (position === -1) checkedParticipants.value.push(index);
    else checkedParticipants.value.splice(position, 1);
};

// Delete all selected
const deleteToggleCheckboxAll = () => {
    const selectedParticipantIds = checkedParticipants.value.map(
        (index) => participants.value[index].id,
    );
    if (selectedParticipantIds.length === 0) {
        console.log('No participants selected');
        return;
    }
    axios
        .delete('/participant/delete/massive', {
            data: { ids: selectedParticipantIds },
        })
        .then(() => {
            checkedParticipants.value = [];
            listParticipants();
        })
        .catch((error) => console.error('Error deleting participants:', error));
};

// Get all participants
const listParticipants = () => {
    participantsLoaded.value = false;
    axios
        .get('/api/participant')
        .then((response) => {
            participants.value = response.data;
            participantsLoaded.value = true;
        })
        .catch((error) => console.error('Error fetching participants:', error));
};

// Open info modal
const openInfoModal = (participant) => {
    selectedParticipant.value = participant;
    showInfoModal.value = true;
    nextTick(() => infoModal.value?.focus());
};
// Close edit modal
const openEditModal = (participant) => {
    selectedParticipant.value = participant;
    editableParticipant.value = JSON.parse(JSON.stringify(participant));
    showEditModal.value = true;
    nextTick(() => editModal.value?.focus());
};
// Close info modal
const closeInfoModal = () => {
    showInfoModal.value = false;
    selectedParticipant.value = null;
};
// Close edit modal
const closeEditModal = () => {
    showEditModal.value = false;
    selectedParticipant.value = null;
};
// Format date
const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
};
// Delete participant
const deleteParticipant = (participant) => {
    axios
        .delete('/participant/delete', { data: { id: participant.id } })
        .then(() => listParticipants())
        .catch((error) => console.error('Error:', error));
};
// Check participant to select
const singleSelectedParticipant = computed(() => {
    return checkedParticipants.value.length === 1
        ? participants.value[checkedParticipants.value[0]]
        : null;
});
// Check participant to delete
const deleteSelectedParticipant = () => {
    if (singleSelectedParticipant.value)
        deleteParticipant(singleSelectedParticipant.value);
};
// Check participant to edit
const editSelectedParticipant = () => {
    if (singleSelectedParticipant.value)
        openEditModal(singleSelectedParticipant.value);
};

const selectedParticipantsCount = computed(
    () => checkedParticipants.value.length,
);

// Submit edit form
const saveParticipantChanges = () => {
    axios
        .patch('/participant/update', {
            participant_id: editableParticipant.value.id,
            ...editableParticipant.value,
        })
        .then(() => {
            listParticipants();
            closeEditModal();
        })
        .catch((error) => console.error('Error', error));
};

// Search participant in object
const searchBarParticipant = () => {
    return participants.value.filter((participant) =>
        participant.name.toLowerCase().includes(input.value.toLowerCase()),
    );
};

onMounted(listParticipants);
</script>

<template>
    <Head title="Llista de Participants"></Head>
    <SidebarLayout>
        <div
            class="mx-auto mt-14 flex h-[720px] w-5/6 flex-col rounded-md bg-secondary p-6 md:h-[630px]"
        >
            <h1
                class="sticky top-0 z-10 flex w-full items-center justify-center bg-secondary pb-3 pt-5 text-center text-3xl font-light text-white"
            >
                LLISTA DE PARTICIPANTS
            </h1>
            <div
                class="sticky top-0 z-10 mb-4 items-center justify-center bg-secondary pb-3 pt-5 text-white md:flex"
            >
                <div class="flex flex-col items-center min-[1500px]:flex-row">
                    <button
                        @click="toggleCheckboxAll"
                        class="my-3 h-10 w-24 rounded-md bg-mclaren text-white transition-colors duration-75 ease-in-out hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        aria-label="Marcar o desmarcar tots els participants"
                    >
                        {{
                            checkedParticipants.length === participants.length
                                ? 'Desmarcar'
                                : 'Tots'
                        }}
                    </button>
                    <SearchBar
                        class="w-auto rounded-md text-black md:mb-0 md:mt-0"
                        type="text"
                        placeholder="Buscar participants..."
                        v-model="input"
                        aria-label="Cercar participants"
                    />
                    <div
                        class="my-3 flex flex-row items-center justify-center space-x-2 min-[1500px]:ml-2"
                        aria-live="polite"
                    >
                        <button
                            v-if="selectedParticipantsCount === 1"
                            @click="editSelectedParticipant"
                            class="h-10 w-24 rounded-md bg-mclaren text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        >
                            Editar
                        </button>
                        <button
                            v-if="selectedParticipantsCount === 1"
                            @click="deleteSelectedParticipant"
                            class="h-10 w-24 rounded-md bg-red-600 text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-red-600"
                        >
                            Eliminar
                        </button>
                        <button
                            v-if="selectedParticipantsCount > 1"
                            @click="deleteToggleCheckboxAll"
                            class="flex h-10 w-auto items-center rounded-md bg-red-600 px-4 text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-red-600"
                            aria-label="Eliminar participants seleccionats"
                        >
                            <span
                                >Eliminar ({{
                                    selectedParticipantsCount
                                }})</span
                            >
                        </button>
                        <button
                            v-if="selectedParticipantsCount === 0"
                            disabled
                            class="h-10 w-24 rounded-md bg-gray-400 text-white"
                            aria-disabled="true"
                        >
                            Editar
                        </button>
                        <button
                            v-if="selectedParticipantsCount === 0"
                            disabled
                            class="h-10 w-24 rounded-md bg-gray-400 text-white"
                            aria-disabled="true"
                        >
                            Eliminar
                        </button>
                    </div>
                </div>
            </div>

            <LoadingAnimation
                class="px-8"
                v-if="!participantsLoaded"
                aria-label="Carregant llista de participants"
            />
            <div
                class="w-full overflow-y-auto overflow-x-hidden"
                v-if="participantsLoaded"
                role="list"
                aria-label="Llista de participants"
            >
                <div
                    v-for="(participant, index) in searchBarParticipant()"
                    :key="participant.id"
                    role="listitem"
                    class="mt-4 flex justify-center"
                >
                    <div
                        class="mb-2 grid w-full grid-cols-3 items-center gap-4 rounded-md bg-white p-2 sm:grid-cols-5 xl:grid-cols-6"
                    >
                        <div
                            class="col-span-1 flex items-center justify-center"
                        >
                            <input
                                type="checkbox"
                                :id="'participant-' + index"
                                :checked="checkedParticipants.includes(index)"
                                @change="toggleParticipantSelection(index)"
                                class="h-5 w-5 rounded text-mclaren checked:bg-mclaren checked:ring-mclaren focus:ring-2 focus:ring-mclaren focus:ring-offset-0"
                                :aria-label="`Seleccionar ${participant.name}`"
                            />
                        </div>
                        <div class="col-span-1">
                            <p class="font-semibold">{{ participant.name }}</p>
                        </div>
                        <div class="col-span-2 hidden sm:flex">
                            <p class="font-semibold">
                                {{ participant.surnames }}
                            </p>
                        </div>
                        <div class="col-span-1 hidden xl:flex">
                            <p class="text-right font-semibold capitalize">
                                {{ participant.relationship }}
                            </p>
                        </div>
                        <div class="col-span-1 flex justify-end space-x-2">
                            <svg
                                @click="openInfoModal(participant)"
                                role="button"
                                :aria-label="`Veure informació de ${participant.name}`"
                                tabindex="0"
                                @keydown.enter="openInfoModal(participant)"
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-2 mt-1 size-8 cursor-pointer stroke-mclaren hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-mclaren"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M12 4.5v15m7.5-7.5h-15"
                                />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Info Modal -->
        <div
            v-if="showInfoModal"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
            role="dialog"
            aria-modal="true"
            aria-labelledby="info-modal-title"
        >
            <div
                class="max-h-[80vh] w-full max-w-md overflow-auto rounded-lg bg-white p-8"
                tabindex="-1"
                ref="infoModal"
            >
                <div class="mb-6 flex items-center justify-between">
                    <h3
                        id="info-modal-title"
                        class="text-xl font-bold text-gray-800"
                    >
                        Informació adicional
                    </h3>
                    <button
                        @click="closeInfoModal"
                        @keydown.enter="closeInfoModal"
                        tabindex="0"
                        class="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                        aria-label="Tancar modal d'informació"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-6 w-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>
                <div v-if="selectedParticipant" class="space-y-4">
                    <div class="flex space-x-20">
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Nom</p>
                            <p class="font-semibold">
                                {{ selectedParticipant.name }}
                            </p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Cognoms</p>
                            <p class="font-semibold">
                                {{ selectedParticipant.surnames }}
                            </p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Relació</p>
                            <p class="font-semibold">
                                {{ selectedParticipant.relationship }}
                            </p>
                        </div>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Direcció</p>
                        <p class="font-semibold">
                            {{ selectedParticipant.direction }}
                        </p>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Any d'Entrada</p>
                        <p class="font-semibold">
                            {{ selectedParticipant.entry_year }}
                        </p>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Aniversari</p>
                        <p class="font-semibold">
                            {{ formatDate(selectedParticipant.birthday) }}
                        </p>
                    </div>
                    <div class="flex space-x-20">
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Membre</p>
                            <p
                                class="font-semibold"
                                v-if="selectedParticipant.member === 0"
                            >
                                No
                            </p>
                            <p
                                class="font-semibold"
                                v-if="selectedParticipant.member === 1"
                            >
                                Sí
                            </p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Actiu</p>
                            <p
                                class="font-semibold"
                                v-if="selectedParticipant.active === 0"
                            >
                                No
                            </p>
                            <p
                                class="font-semibold"
                                v-if="selectedParticipant.active === 1"
                            >
                                Sí
                            </p>
                        </div>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Presupost</p>
                        <p class="font-semibold">
                            {{ selectedParticipant.cash }}
                        </p>
                    </div>
                </div>
                <div class="mt-8 flex justify-end">
                    <button
                        @click="closeInfoModal"
                        class="rounded-md bg-mclaren px-4 py-2 text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        aria-label="Tancar modal d'informació"
                    >
                        Tancar
                    </button>
                </div>
            </div>
        </div>

        <!-- Edit Modal -->
        <div
            v-if="showEditModal"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
            role="dialog"
            aria-modal="true"
            aria-labelledby="edit-modal-title"
        >
            <div
                class="max-h-[80vh] w-full max-w-4xl overflow-auto rounded-lg bg-white p-8"
                tabindex="-1"
                ref="editModal"
            >
                <div class="mb-6 flex items-center justify-between">
                    <h3
                        id="edit-modal-title"
                        class="text-xl font-bold text-gray-800"
                    >
                        Editar Participant
                    </h3>
                    <button
                        @click="closeEditModal"
                        @keydown.enter="closeEditModal"
                        tabindex="0"
                        class="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                        aria-label="Tancar modal d'edició"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-6 w-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>
                <div v-if="editableParticipant" class="space-y-4">
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="name"
                                >Nom</label
                            >
                            <input
                                type="text"
                                v-model="editableParticipant.name"
                                class="w-full rounded-md border p-2"
                                id="name"
                                :aria-describedby="
                                    editableParticipant.name.length < 3
                                        ? 'name-error'
                                        : null
                                "
                            />
                            <span
                                v-if="editableParticipant.name.length < 3"
                                id="name-error"
                                class="text-red-500"
                            >
                                El nom ha de tenir almenys 3 caràcters
                            </span>
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="surname"
                                >Cognoms</label
                            >
                            <input
                                type="text"
                                v-model="editableParticipant.surnames"
                                class="w-full rounded-md border p-2"
                                id="surname"
                                :aria-describedby="
                                    editableParticipant.surnames.length < 3
                                        ? 'surname-error'
                                        : null
                                "
                            />
                            <span
                                v-if="editableParticipant.surnames.length < 3"
                                id="surname-error"
                                class="text-red-500"
                            >
                                Els cognoms han de tenir almenys 3 caràcters
                            </span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="direction"
                                >Direcció</label
                            >
                            <input
                                type="text"
                                v-model="editableParticipant.direction"
                                class="w-full rounded-md border p-2"
                                id="direction"
                            />
                        </div>
                        <div class="border-b pb-2">
                            <label
                                class="text-sm text-gray-500"
                                for="relationship"
                                >Relació</label
                            >
                            <input
                                type="text"
                                v-model="editableParticipant.relationship"
                                class="w-full rounded-md border p-2"
                                id="relationship"
                            />
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="ed_sheet"
                                >Full Educatiu</label
                            >
                            <input
                                type="text"
                                v-model="editableParticipant.educational_sheet"
                                class="w-full rounded-md border p-2"
                                id="ed_sheet"
                            />
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="dni"
                                >DNI</label
                            >
                            <input
                                type="text"
                                v-model="editableParticipant.dni"
                                class="w-full rounded-md border p-2"
                                id="dni"
                            />
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="birthday"
                                >Aniversari</label
                            >
                            <input
                                type="date"
                                v-model="editableParticipant.birthday"
                                class="w-full rounded-md border p-2"
                                id="birthday"
                            />
                        </div>
                        <div class="border-b pb-2">
                            <label
                                class="text-sm text-gray-500"
                                for="entry_year"
                                >Any d'entrada</label
                            >
                            <input
                                type="text"
                                v-model="editableParticipant.entry_year"
                                class="w-full rounded-md border p-2"
                                id="entry_year"
                            />
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="member"
                                >Membre</label
                            >
                            <select
                                v-model="editableParticipant.member"
                                class="w-full rounded-md border p-2"
                                id="member"
                                aria-label="L'usuari és membre o no"
                            >
                                <option value="0">No</option>
                                <option value="1">Sí</option>
                            </select>
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="active"
                                >Actiu</label
                            >
                            <select
                                v-model="editableParticipant.active"
                                class="w-full rounded-md border p-2"
                                id="active"
                                aria-label="Estat actiu del participant"
                            >
                                <option value="0">No</option>
                                <option value="1">Sí</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mt-8 flex justify-end space-x-4">
                    <button
                        @click="closeEditModal"
                        class="rounded-md bg-gray-300 px-4 py-2 text-gray-800 hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300"
                    >
                        Cancel·lar
                    </button>
                    <button
                        @click="saveParticipantChanges"
                        class="rounded-md bg-mclaren px-4 py-2 text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-mclaren"
                    >
                        Editar
                    </button>
                </div>
            </div>
        </div>
    </SidebarLayout>
</template>
