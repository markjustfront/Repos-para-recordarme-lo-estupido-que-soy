<script setup>
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { ref, onMounted } from 'vue';
import FormButton from '@/Components/FormButton.vue';
import axios from 'axios';
import { Head } from '@inertiajs/vue3';
import BackButton from '@/Components/BackButton.vue';

const form = ref({
    dni: '',
    name: '',
    surnames: '',
    direction: '',
    birthday: '',
    relationship: '',
    educationalSheet: '',
    entry_year: '',
    tutor_id: '',
    member: null,
    cash: null,
    active: true,
});

const currentStep = ref(1);
const tutors = ref([]);
const tutorsLoaded = ref(false);
const formStatus = ref('');

const next = () => currentStep.value++;
const previous = () => currentStep.value--;

// Get all tutors
const listTutors = () => {
    axios.get('/api/tutor').then((response) => {
        tutors.value = response.data;
        tutorsLoaded.value = true;
    });
};

//Submit form
const submit = () => {
    const formData = new FormData();
    formData.append('name', form.value.name);
    formData.append('surnames', form.value.surnames);
    formData.append('dni', form.value.dni);
    formData.append('birthday', form.value.birthday);
    formData.append('direction', form.value.direction);
    formData.append('entry_year', form.value.entry_year);
    formData.append('member', form.value.member ? 1 : 0);
    formData.append('cash', form.value.cash ? 1 : 0);
    formData.append('relationship', form.value.relationship);
    formData.append('tutor_id', form.value.tutor_id);
    formData.append('educational_sheet', form.value.educationalSheet);

    axios
        .post('/participant/add', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
        })
        .then(() => {
            formStatus.value = 'Participant afegit amb èxit';
            window.location.reload(true);
        });
};

onMounted(listTutors);
</script>

<template>
    <Head title="Afegir participant"></Head>
    <SidebarLayout>
        <BackButton url="/participants"></BackButton>
        <div>
            <div class="flex h-screen flex-col items-center justify-around">
                <div class="ml-2 mt-7 flex items-center justify-center">
                    <button
                        class="h-5 w-5 cursor-pointer rounded-full border border-secondary bg-secondary transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-mclaren"
                        @click="currentStep = 1"
                        aria-label="Anar al pas 1"
                        :aria-current="currentStep === 1 ? 'step' : null"
                    ></button>
                    <button
                        class="ml-1 h-5 w-5 cursor-pointer rounded-full border-2 border-secondary transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-mclaren"
                        :class="currentStep > 1 ? 'bg-secondary' : 'bg-white'"
                        @click="currentStep = 2"
                        aria-label="Anar al pas 2"
                        :aria-current="currentStep === 2 ? 'step' : null"
                    ></button>
                    <button
                        class="ml-1 h-5 w-5 cursor-pointer rounded-full border-2 border-secondary transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-mclaren"
                        :class="currentStep > 2 ? 'bg-secondary' : 'bg-white'"
                        @click="currentStep = 3"
                        aria-label="Anar al pas 3"
                        :aria-current="currentStep === 3 ? 'step' : null"
                    ></button>
                </div>
                <div
                    class="h-3/4 max-h-[690px] w-full rounded-md bg-secondary md:w-[450px]"
                >
                    <div v-if="currentStep === 1">
                        <h1
                            class="mt-5 flex items-center justify-center text-3xl text-white"
                        >
                            PARTICIPANT
                        </h1>
                        <div class="flex flex-col">
                            <label
                                for="name"
                                class="mt-3 flex items-center justify-center text-xl text-white"
                                >Nom</label
                            >
                            <input
                                type="text"
                                id="name"
                                name="name"
                                class="m-auto mt-3 h-10 w-96 rounded border-primary bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.name"
                                placeholder="Introdueix un nom"
                            />
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="surnames"
                                class="mt-5 flex items-center justify-center text-xl text-white"
                                >Cognoms</label
                            >
                            <input
                                type="text"
                                id="surnames"
                                name="surnames"
                                class="m-auto mt-3 h-10 w-96 rounded border-primary bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.surnames"
                                placeholder="Introdueix cognoms"
                            />
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="direction"
                                class="mt-5 flex items-center justify-center text-xl text-white"
                                >Direcció</label
                            >
                            <input
                                type="text"
                                id="direction"
                                name="direction"
                                class="m-auto mt-3 h-10 w-96 rounded border-primary bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.direction"
                                placeholder="Introdueix una direcció"
                            />
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="birthday"
                                class="mt-5 flex items-center justify-center text-xl text-white"
                                >Aniversari</label
                            >
                            <input
                                type="date"
                                id="birthday"
                                name="birthday"
                                class="m-auto mt-3 h-10 w-96 rounded border-primary bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.birthday"
                                placeholder="Introdueix una data"
                            />
                        </div>
                    </div>
                    <div v-if="currentStep === 2">
                        <h1
                            class="mt-1 flex items-center justify-center text-3xl text-white"
                        >
                            PARTICIPANT
                        </h1>
                        <div class="flex flex-col">
                            <label
                                for="dni"
                                class="mt-2 flex items-center justify-center text-xl text-white"
                                >DNI</label
                            >
                            <input
                                type="text"
                                id="dni"
                                name="dni"
                                class="m-auto mt-3 h-10 w-96 rounded border-primary bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.dni"
                                placeholder="Introdueix el dni"
                            />
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="relationship"
                                class="mt-5 flex items-center justify-center text-xl text-white"
                                >Relació</label
                            >
                            <input
                                type="text"
                                id="relationship"
                                name="relationship"
                                class="m-auto mt-3 h-10 w-96 rounded border-primary bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.relationship"
                                placeholder="Introdueix la relació"
                            />
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="entry_year"
                                class="mt-5 flex items-center justify-center text-xl text-white"
                                >Any d'entrada</label
                            >
                            <input
                                type="number"
                                id="entry_year"
                                name="entry_year"
                                class="m-auto mt-3 h-10 w-96 rounded border-primary bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.entry_year"
                                placeholder="Introdueix l'any d'entrada"
                            />
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="educational"
                                class="mt-5 flex items-center justify-center text-xl text-white"
                                >Fulla educativa</label
                            >
                            <textarea
                                id="educational"
                                name="educational"
                                class="m-auto mt-3 h-24 w-96 resize-none rounded bg-white p-2 py-3 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.educationalSheet"
                                placeholder="Introdueix informació educativa"
                            ></textarea>
                        </div>
                    </div>
                    <div v-if="currentStep === 3">
                        <h1
                            class="mt-1 flex items-center justify-center text-3xl text-white"
                        >
                            PARTICIPANT
                        </h1>
                        <div class="mt-3 flex flex-col">
                            <label
                                for="tutor"
                                class="flex items-center justify-center text-xl text-white"
                                >Tutors</label
                            >
                            <select
                                v-if="tutorsLoaded"
                                id="tutor"
                                name="tutor"
                                class="m-auto h-10 w-96 rounded bg-white p-2 focus:border-mclaren focus:ring-mclaren"
                                v-model="form.tutor_id"
                            >
                                <option
                                    class="py-3 focus:border-mclaren focus:ring-mclaren"
                                    v-for="tutor in tutors"
                                    :key="tutor.id"
                                    :value="tutor.id"
                                >
                                    {{ tutor.name }}
                                </option>
                            </select>
                            <span
                                v-else
                                aria-live="polite"
                                class="text-center text-white"
                                >Carregant tutors...</span
                            >
                        </div>
                        <fieldset class="mt-3">
                            <label
                                class="flex items-center justify-center text-xl text-white"
                                >Mètode de pagament</label
                            >
                            <div class="mt-3 flex justify-center space-x-8">
                                <div class="rounded p-2 text-center">
                                    <label
                                        class="relative flex cursor-pointer flex-col items-center"
                                        for="cash_yes"
                                    >
                                        <input
                                            type="radio"
                                            v-model="form.cash"
                                            :value="true"
                                            class="peer h-5 w-5 cursor-pointer appearance-none rounded border shadow transition-all checked:border-mclaren checked:bg-mclaren hover:shadow-md"
                                            id="cash_yes"
                                            name="cash"
                                        />
                                        <span class="mt-2 text-white"
                                            >Efectiu</span
                                        >
                                    </label>
                                </div>
                                <div class="rounded p-2 text-center">
                                    <label
                                        class="relative flex cursor-pointer flex-col items-center"
                                        for="cash_no"
                                    >
                                        <input
                                            type="radio"
                                            v-model="form.cash"
                                            :value="false"
                                            class="peer h-5 w-5 cursor-pointer appearance-none rounded border shadow transition-all checked:border-mclaren checked:bg-mclaren hover:shadow-md"
                                            id="cash_no"
                                            name="cash"
                                        />
                                        <span class="mt-2 text-white"
                                            >Domiciliat</span
                                        >
                                    </label>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset class="mt-3">
                            <label
                                class="flex items-center justify-center text-xl text-white"
                                >Soci</label
                            >
                            <div class="mt-3 flex justify-center space-x-8">
                                <div class="rounded p-2 text-center">
                                    <label
                                        class="relative flex cursor-pointer flex-col items-center"
                                        for="member_yes"
                                    >
                                        <input
                                            type="radio"
                                            v-model="form.member"
                                            :value="true"
                                            class="peer h-5 w-5 cursor-pointer appearance-none rounded border shadow transition-all checked:border-mclaren checked:bg-mclaren hover:shadow-md"
                                            id="member_yes"
                                            name="member"
                                        />
                                        <span class="mt-2 text-white">Sí</span>
                                    </label>
                                </div>
                                <div class="rounded p-2 text-center">
                                    <label
                                        class="relative flex cursor-pointer flex-col items-center"
                                        for="member_no"
                                    >
                                        <input
                                            type="radio"
                                            v-model="form.member"
                                            :value="false"
                                            class="peer h-5 w-5 cursor-pointer appearance-none rounded border shadow transition-all checked:border-mclaren checked:bg-mclaren hover:shadow-md"
                                            id="member_no"
                                            name="member"
                                        />
                                        <span class="mt-2 text-white">No</span>
                                    </label>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="flex w-full transform items-center justify-center">
                    <FormButton
                        class="ml-3 h-10 w-32 rounded bg-mclaren text-white focus:outline-none focus:ring-2 focus:ring-mclaren"
                        v-if="currentStep !== 1"
                        @click="previous"
                    >
                        Anterior
                    </FormButton>
                    <FormButton
                        class="ml-3 h-10 w-32 rounded bg-mclaren text-white focus:outline-none focus:ring-2 focus:ring-mclaren"
                        v-if="currentStep !== 3"
                        @click="next"
                    >
                        Següent
                    </FormButton>
                    <FormButton
                        class="ml-3 h-10 w-32 rounded bg-mclaren text-white focus:outline-none focus:ring-2 focus:ring-mclaren"
                        v-if="currentStep === 3"
                        @click="submit"
                    >
                        Finalitzar
                    </FormButton>
                </div>
            </div>
            <div aria-live="polite" class="sr-only">{{ formStatus }}</div>
        </div>
    </SidebarLayout>
</template>
