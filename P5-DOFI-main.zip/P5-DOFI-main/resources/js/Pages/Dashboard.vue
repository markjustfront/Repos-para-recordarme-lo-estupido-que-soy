<script setup>
import { Head, Link } from '@inertiajs/vue3';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { onMounted, ref } from 'vue';

const props = defineProps({
    isAuthenticated: Boolean,
    auth: Object,
});

//const showMessage = ref(props.auth.user.role === 'admin');
const showMessage = ref(false);

onMounted(() => {
    if (showMessage.value) {
        setTimeout(() => {
            showMessage.value = false;
        }, 2500);
    }
});
</script>

<template>
    <Head title="Dashboard" />
    <SidebarLayout>
        <main aria-labelledby="dashboard-title">
            <div class="py-5">
                <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    <h1 id="dashboard-title" class="p-2 text-5xl text-mclaren md:text-6xl">
                        <span v-if="!showMessage">Hola</span><span v-if="showMessage">Felicitats</span> <span class="capitalize">{{ auth.user.name }}</span>!
                    </h1>
                </div>
            </div>
            <nav class="mx-auto mt-10 max-w-7xl p-1 sm:px-6 md:mt-0 lg:px-8" aria-label="Opcions del tauler">
                <div class="grid w-full grid-cols-1 gap-4 rounded-md bg-dashboard p-4 shadow-md md:grid-cols-2 lg:grid-cols-4">
                    <div class="flex items-center justify-center">
                        <Link
                            href="/tutor/add"
                            class="group flex h-12 w-full items-center justify-center rounded-md bg-primary text-lg text-white shadow-md transition duration-300 hover:bg-white hover:text-primary focus:outline-none focus:ring-2 focus:ring-mclaren md:max-w-[250px]"
                            aria-label="Afegir un nou tutor"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-1 size-4 stroke-white group-hover:stroke-primary"
                                aria-hidden="true"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M12 4.5v15m7.5-7.5h-15"
                                />
                            </svg>
                            TUTOR
                        </Link>
                    </div>
                    <div class="flex items-center justify-center">
                        <Link
                            href="/participant/add"
                            class="group flex h-12 w-full items-center justify-center rounded-md bg-primary text-lg text-white shadow-md transition duration-300 hover:bg-white hover:text-primary focus:outline-none focus:ring-2 focus:ring-mclaren md:max-w-[250px]"
                            aria-label="Afegir un nou participant"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-1 size-4 stroke-white group-hover:stroke-primary"
                                aria-hidden="true"
                            >
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                            PARTICIPANT
                        </Link>
                    </div>
                    <div class="flex items-center justify-center">
                        <Link
                            href="/monitor/add"
                            class="group flex h-12 w-full items-center justify-center rounded-md bg-primary text-lg text-white shadow-md transition duration-300 hover:bg-white hover:text-primary md:max-w-[250px] focus:outline-none focus:ring-2 focus:ring-mclaren"
                            aria-label="Afegir un nou monitor"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-1 size-4 stroke-white group-hover:stroke-primary"
                                aria-hidden="true"
                            >
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                            MONITOR
                        </Link>
                    </div>
                    <!--<div class="flex items-center justify-center">
                        <Link
                            href="/activity/add"
                            class="group flex h-12 w-full items-center justify-center rounded-md bg-primary text-lg text-white shadow-md transition duration-300 hover:bg-white hover:text-primary md:max-w-[250px] focus:outline-none focus:ring-2 focus:ring-mclaren"
                            aria-label="Afegir una nova activitat"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-1 size-4 stroke-white group-hover:stroke-primary"
                                aria-hidden="true"
                            >
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                            ACTIVITAT
                        </Link>
                    </div>-->
                    <div class="flex items-center justify-center">
                        <Link
                            href="/incidence/add"
                            class="group flex h-12 w-full items-center justify-center rounded-md bg-primary text-lg text-white shadow-md transition duration-300 hover:bg-white hover:text-primary md:max-w-[250px] focus:outline-none focus:ring-2 focus:ring-mclaren"
                            aria-label="Afegir una nova incidència"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-1 size-4 stroke-white group-hover:stroke-primary"
                                aria-hidden="true"
                            >
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                            INCIDÈNCIA
                        </Link>
                    </div>
                    <!--<div class="flex items-center justify-center">
                        <Link
                            href="/meeting/add"
                            class="group flex h-12 w-full items-center justify-center rounded-md bg-primary text-lg text-white shadow-md transition duration-300 hover:bg-white hover:text-primary md:max-w-[250px] focus:outline-none focus:ring-2 focus:ring-mclaren"
                            aria-label="Afegir una nova reunió"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-1 size-4 stroke-white group-hover:stroke-primary"
                                aria-hidden="true"
                            >
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                            </svg>
                            REUNIÓ
                        </Link>
                    </div>-->
                </div>
            </nav>
            <div class="mx-auto mt-4 hidden max-w-7xl p-1 sm:px-6 md:block lg:px-8">
                <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div class="h-48 rounded-md bg-dashboard shadow-md lg:h-96"></div>
                    <div class="h-48 rounded-md bg-dashboard shadow-md lg:h-96"></div>
                </div>
            </div>
        </main>
    </SidebarLayout>
</template>