<script setup>
/*
  +----------------------------------+
  | THIS VIEW IS NOT YET IMPLEMENTED |
  |    - BE PATIENT YOUNG PADAWAN    |
  +----------------------------------+

import { Head } from '@inertiajs/vue3';
import axios from 'axios';
import { ref, onMounted, nextTick } from 'vue';
import LoadingAnimation from '@/Components/LoadingAnimation.vue';
import LoadingAnimationBlue from '@/Components/LoadingAnimationBlue.vue';

const incidences = ref([]);
const participants = ref([]);
const showInfoModal = ref(false);
const selectedIncidence = ref(null);
const incidencesLoaded = ref(false);
const participantsLoaded = ref(false);
const infoModal = ref(null);

const listIncidences = () => {
    incidencesLoaded.value = false;
    axios.get('/api/incidence')
        .then((response) => {
            incidences.value = response.data;
            incidencesLoaded.value = true;
        })
        .catch((error) => console.log(error));
};

const listParticipants = () => {
    participantsLoaded.value = false;
    axios.get('/api/participant')
        .then((response) => {
            participants.value = response.data;
            participantsLoaded.value = true;
        })
        .catch((error) => console.log(error));
};

const openInfoModal = (incidence) => {
    selectedIncidence.value = incidence;
    showInfoModal.value = true;
    nextTick(() => infoModal.value?.focus());
};

const closeInfoModal = () => {
    showInfoModal.value = false;
    selectedIncidence.value = null;
};

const redirectParticipantInfo = (participantId) => {
    window.location.href = `/participant/${participantId}`;
};

onMounted(listIncidences);
onMounted(listParticipants);*/
</script>

<template>
    <!--<Head title="Tutor dashboard" />
    <div class="mx-auto mb-14 mt-8 ssm:max-h-[650px] ssm:min-h-[650px] min-h-[1550px] w-5/6 grid grid-col-1 lg:grid-cols-2 rounded-md bg-secondary p-6">
        <h1 id="dashboard-title" class="sr-only">Tutor Dashboard</h1>
        <div class="bg-white max-h-[600px] mx-4 rounded-md">
            <h2 class="w-full text-center text-3xl font-semibold text-secondary my-7">LLISTA DE PARTICIPANTS</h2>
            <LoadingAnimationBlue v-if="!participantsLoaded" aria-label="Carregant llista de participants" />
            <div class="w-full max-h-[600px] ssm:max-h-[510px] overflow-y-auto overflow-x-hidden" v-if="participantsLoaded" role="list" aria-label="Llista de participants">
                <button
                    v-for="(participant, index) in participants"
                    :keyid="participant.id"
                    @click="redirectParticipantInfo(participant.id)"
                    class="mb-2 mx-4 grid grid-cols-2 ssm:grid-cols-3 items-center gap-4 text-white rounded-md bg-secondary p-2 focus:outline-none focus:ring-2 focus:ring-mclaren"
                    :aria-label="`Veure informació de ${participant.name} ${participant.surnames}`"
                >
                    <p class="text-left font-semibold capitalize">{{ participant.name }}</p>
                    <p class="col-span-1 text-left font-semibold">{{ participant.surnames }}</p>
                    <p class="col-span-1 text-left font-semibold hidden ssm:flex">{{ participant.relationship }}</p>
                </button>
            </div>
        </div>
        <div>
            <div class="max-h-[600px]">
                <h2 class="w-full text-center text-3xl font-semibold text-white my-7">LLISTA DE INCIDENCIES</h2>
                <LoadingAnimation v-if="!incidencesLoaded" aria-label="Carregant llista d'incidències" />
                <div class="w-full max-h-[510px] overflow-y-auto overflow-x-hidden" v-if="incidencesLoaded" role="list" aria-label="Llista d'incidències">
                    <div v-for="(incidence, index) in incidences" :key="incidence.id" role="listitem" class="mb-2 grid w-full grid-cols-2 ssm:grid-cols-3 items-center gap-4 rounded-md bg-white p-2">
                        <p class="text-left font-semibold capitalize">{{ incidence.participant_id }}</p>
                        <p class="col-span-1 text-left font-semibold hidden ssm:flex">{{ incidence.type }}</p>
                        <div class="col-span-1 flex justify-end space-x-2">
                            <button
                                @click="openInfoModal(incidence)"
                                @keydown.enter="openInfoModal(incidence)"
                                class="mr-2 mt-1 size-8 cursor-pointer hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-mclaren"
                                :aria-label="`Veure informació de l'incidència ${incidence.id}`"
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="3" class="stroke-mclaren">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div v-if="showInfoModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" role="dialog" aria-modal="true" aria-labelledby="info-modal-title" @click.self="closeInfoModal">
                <div class="max-h-[80vh] w-full max-w-md overflow-auto rounded-lg bg-white p-8" tabindex="-1" ref="infoModal">
                    <div class="mb-6 flex items-center justify-between">
                        <h3 id="info-modal-title" class="text-xl font-bold text-gray-800">Informació adicional</h3>
                        <button
                            @click="closeInfoModal"
                            @keydown.enter="closeInfoModal"
                            class="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                            aria-label="Tancar modal d'informació"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                    <div v-if="selectedIncidence" class="space-y-4">
                        <div class="flex space-x-20">
                            <div class="border-b pb-2">
                                <p class="text-sm text-gray-500">NOM MONITOR</p>
                                <p class="font-semibold">{{ selectedIncidence.monitor_id }}</p>
                            </div>
                            <div class="border-b pb-2">
                                <p class="text-sm text-gray-500">DESCRIPCIÓ</p>
                                <p class="font-semibold">{{ selectedIncidence.description }}</p>
                            </div>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">ACTUACIÓ</p>
                            <p class="font-semibold">{{ selectedIncidence.actuation }}</p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">DATA</p>
                            <p class="font-semibold">{{ selectedIncidence.date }}</p>
                        </div>
                        <div class="border-b pb-2 ssm:hidden">
                            <p class="text-sm text-gray-500">TIPUS</p>
                            <p class="font-semibold">{{ selectedIncidence.type }}</p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">HORA</p>
                            <p class="font-semibold">{{ selectedIncidence.time }}</p>
                        </div>
                    </div>
                    <div class="mt-8 flex justify-end">
                        <button
                            @click="closeInfoModal"
                            class="rounded-md bg-mclaren px-4 py-2 text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-mclaren"
                            aria-label="Tancar modal d'informació"
                        >
                            Tancar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>-->
</template>
