<script setup>
import { ref } from 'vue';
import { Head } from '@inertiajs/vue3';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import axios from 'axios';
import LoadingAnimation from '@/Components/LoadingAnimation.vue';

const defaulters = ref([]);
const participants = ref([]);
const defaulterLoaded = ref(false);
const participantLoaded = ref(false);

//Get all defaulters
axios.get('/api/defaulter').then(function (response) {
    defaulters.value = response.data;
    defaulterLoaded.value = true;
});

// Get all non defaulters
axios.get('/api/participants/notDefaulters').then(function (response) {
    participants.value = response.data;
    participantLoaded.value = true;
});

// Move non defaulter to defaulter
const moveInToDefaulter = async (participant, index) => {
    await axios.post('/defaulter/add', {
        participant_id: participant.id,
    });
    participants.value.splice(index, 1);
    defaulters.value.push(participant);
};

// Move defaulter to non defaulter participant
const moveOutDefaulter = async (defaulter, index) => {
    await axios.delete('/defaulter/delete', {
        id: defaulter.id,
    });
    defaulters.value.splice(index, 1);
    participants.value.push(defaulter);
};
</script>
<template>
    <Head title="Deutors" />
    <SidebarLayout>
        <div
            class="mx-auto flex min-h-screen w-5/6 flex-col-reverse justify-around p-4 md:w-full md:flex-row md:p-8"
        >
            <div
                class="mt-5 flex max-h-[800px] min-h-96 max-w-[400px] flex-col rounded-md bg-primary p-2 shadow-md md:min-w-[400px]"
            >
                <h2 class="w-full text-center text-3xl font-light text-white">
                    NO DEUTORS
                </h2>
                <LoadingAnimation
                    v-if="!participantLoaded"
                    aria-label="Carregant llista de no deutors"
                />
                <div
                    v-if="participantLoaded"
                    class="flex min-h-80 flex-col overflow-y-auto overflow-x-hidden"
                    role="list"
                    aria-label="Llista de no deutors"
                    aria-live="polite"
                >
                    <button
                        v-for="(participant, index) in participants"
                        :key="index"
                        class="mx-auto mb-2 w-full cursor-pointer rounded-md bg-secondary p-2 shadow-md"
                        @click="moveInToDefaulter(participant, index)"
                        type="button"
                        role="listitem"
                        :aria-label="`Moure ${participant.name} ${participant.surnames} a deutors`"
                    >
                        <p>{{ participant.dni }}</p>
                        <p>{{ participant.name }} {{ participant.surnames }}</p>
                    </button>
                </div>
            </div>
            <div
                class="flex max-h-[800px] min-h-96 max-w-[400px] flex-col rounded-md bg-primary p-2 shadow-md md:mt-0 md:min-w-[400px]"
            >
                <h2 class="w-full text-center text-3xl font-light text-white">
                    DEUTORS
                </h2>
                <LoadingAnimation
                    v-if="!defaulterLoaded"
                    aria-label="Carregant llista de deutors"
                />
                <div
                    v-if="defaulterLoaded"
                    class="flex min-h-80 flex-col overflow-y-auto overflow-x-hidden"
                    role="list"
                    aria-label="Llista de deutors"
                    aria-live="polite"
                >
                    <button
                        v-for="(defaulter, index) in defaulters"
                        :key="index"
                        class="mx-auto mb-2 w-full cursor-pointer rounded-md bg-secondary p-2 shadow-md"
                        @click="moveOutDefaulter(defaulter, index)"
                        type="button"
                        :aria-label="`Treure ${defaulter.name} ${defaulter.surnames} dels deutors`"
                    >
                        <p>{{ defaulter.dni }}</p>
                        <p>{{ defaulter.name }} {{ defaulter.surnames }}</p>
                    </button>
                </div>
            </div>
        </div>
    </SidebarLayout>
</template>
