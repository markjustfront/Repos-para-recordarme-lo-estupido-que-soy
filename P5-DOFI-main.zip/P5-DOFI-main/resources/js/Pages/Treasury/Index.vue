<script setup>
import { Head, Link } from '@inertiajs/vue3';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
</script>

<template>
    <Head title="Tresoreria"></Head>
    <SidebarLayout>
        <div
            class="mx-auto mt-10 flex w-5/6 flex-row justify-around rounded-md bg-secondary p-4 shadow-md"
        >
            <Link
                class="rounded-md bg-mclaren p-2 font-light text-black transition-colors duration-200 ease-in-out hover:bg-orange-600 focus:bg-primary focus:text-white focus:ring-mclaren"
                href="/defaulters"
            >
                Deutors
            </Link>
        </div>
    </SidebarLayout>
</template>