<script setup>
import { Head, useForm } from '@inertiajs/vue3';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import FormButton from '@/Components/FormButton.vue';
import { ref } from 'vue';
import BackButton from '@/Components/BackButton.vue';

const form = useForm({
    type: '',
    description: '',
    actuation: '',
    monitor_id: '',
    participant_id: '',
    date: '',
    time: '',
});

// Submit form
const submit = () => {
    form.submit('post', '/incidence/add');
};

const participantsLoaded = ref(false);
const monitorsLoaded = ref(false);

const participants = ref();
const monitors = ref();

// Get all participants
axios.get('/api/participant').then(function (response) {
    participants.value = response.data;
    participantsLoaded.value = true;
});

// Get all monitors
axios.get('/api/monitor').then(function (response) {
    monitors.value = response.data;
    monitorsLoaded.value = true;
});
</script>

<template>
    <Head title="Afegir incidència"></Head>
    <SidebarLayout>
        <BackButton url="/dashboard" tabindex="0"></BackButton>
        <form @submit.prevent="submit()">
            <div
                class="mx-auto mt-16 h-1/2 w-10/12 rounded-md bg-secondary px-12 py-16 shadow-md md:mt-[121px]"
            >
                <h1
                    class="mx-auto w-full text-center text-4xl font-bold text-white md:w-5/6"
                >
                    AFEGIR INCIDÈNCIA
                </h1>
                <div
                    class="mx-auto flex w-5/6 flex-col justify-between p-4 md:flex-row"
                >
                    <div class="flex w-full flex-col md:w-2/5">
                        <div class="mb-5 flex flex-col">
                            <label
                                for="date"
                                class="text-center text-2xl font-light text-white"
                                >DATA</label
                            >
                            <input
                                type="date"
                                id="date"
                                name="date"
                                v-model="form.date"
                                class="transition-color rounded-md border-gray-300 shadow-sm duration-75 ease-in-out focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>
                        <div class="mb-5 flex flex-col">
                            <label
                                for="description"
                                class="text-center text-2xl font-light text-white"
                                >DESCRIPCIÓ</label
                            >
                            <textarea
                                id="description"
                                name="description"
                                v-model="form.description"
                                class="transition-color min-h-48 rounded-md border-gray-300 shadow-sm duration-75 ease-in-out focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>
                        <div class="mb-5 flex flex-col">
                            <label
                                for="type"
                                class="text-center text-2xl font-light text-white"
                                >TIPUS</label
                            >
                            <select
                                id="type"
                                name="type"
                                v-model="form.type"
                                class="transition-color rounded-md border-gray-300 shadow-sm duration-75 ease-in-out focus:border-mclaren focus:ring-mclaren"
                            >
                                <option value="Crisis epilèptiques">
                                    Crisis epilèptiques
                                </option>
                                <option value="Alteració conductual">
                                    Alteració conductual
                                </option>
                                <option value="Altres">Altres</option>
                            </select>
                        </div>
                    </div>
                    <div class="flex w-full flex-col md:w-2/5">
                        <div class="mb-5 flex flex-col">
                            <label
                                for="time"
                                class="text-center text-2xl font-light text-white"
                                >HORA</label
                            >
                            <input
                                type="time"
                                id="time"
                                name="time"
                                v-model="form.time"
                                class="transition-color rounded-md border-gray-300 shadow-sm duration-75 ease-in-out focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>
                        <div class="mb-5 flex flex-col">
                            <label
                                for="participant"
                                class="text-center text-2xl font-light text-white"
                                >PARTICIPANT</label
                            >
                            <select
                                v-if="participantsLoaded"
                                id="participant"
                                name="participant"
                                v-model="form.participant_id"
                                class="transition-color rounded-md border-gray-300 shadow-sm duration-75 ease-in-out focus:border-mclaren focus:ring-mclaren"
                            >
                                <option
                                    v-for="participant in participants"
                                    :value="participant.id"
                                    :key="participant.id"
                                >
                                    {{ participant.name }} {{ participant.surnames }}
                                </option>
                            </select>
                            <div v-else aria-live="polite" class="text-white">
                                Carregant participants...
                            </div>
                        </div>
                        <div class="mb-5 flex flex-col">
                            <label
                                for="monitor"
                                class="text-center text-2xl font-light text-white"
                                >MONITOR</label
                            >
                            <select
                                v-if="monitorsLoaded"
                                id="monitor"
                                name="monitor"
                                v-model="form.monitor_id"
                                class="transition-color rounded-md border-gray-300 shadow-sm duration-75 ease-in-out focus:border-mclaren focus:ring-mclaren"
                            >
                                <option
                                    v-for="monitor in monitors"
                                    :value="monitor.id"
                                    :key="monitor.id"
                                >
                                    {{ monitor.name }} {{ monitor.surnames }}
                                </option>
                            </select>
                            <div v-else aria-live="polite" class="text-white">
                                Carregant monitors...
                            </div>
                        </div>
                        <div class="mb-5 flex flex-col">
                            <label
                                for="actuation"
                                class="text-center text-2xl font-light text-white"
                                >ACTUACIÓ</label
                            >
                            <input
                                type="text"
                                id="actuation"
                                name="actuation"
                                v-model="form.actuation"
                                class="transition-color rounded-md border-gray-300 shadow-sm duration-75 ease-in-out focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>
                    </div>
                </div>
            </div>
            <div class="mt-5 flex w-full min-w-full flex-row justify-center">
                <FormButton type="submit" tabindex="0"
                    >AFEGIR INCIDÈNCIA</FormButton
                >
            </div>
        </form>
    </SidebarLayout>
</template>
