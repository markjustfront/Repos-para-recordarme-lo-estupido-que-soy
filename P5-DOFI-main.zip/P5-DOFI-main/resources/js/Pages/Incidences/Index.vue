<script setup>
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <SidebarLayout>
        <div class="mx-auto mt-20 flex w-5/6 flex-row" role="navigation" aria-label="Opcions de gestió d'incidències">
            <Link href="/incidence/add" class="" aria-label="Crear una nova incidència">
            Crear
            </Link>
            <Link href="#" class="" aria-label="Esborrar incidències (desactivat)" aria-disabled="true" @click.prevent>
            Esborrar
            </Link>
            <Link href="#" class="" aria-label="Llistar incidències (desactivat)" aria-disabled="true" @click.prevent>
            Llistar
            </Link>
        </div>
    </SidebarLayout>
</template>