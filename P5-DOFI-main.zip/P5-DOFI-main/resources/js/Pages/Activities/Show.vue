<script setup>
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { Head } from '@inertiajs/vue3';
import Fancybox from '@/Components/Fancybox.vue';
import BackButton from '@/Components/BackButton.vue';

const props = defineProps({
    activity: {
        required: true,
        type: Object,
    },
});
</script>

<template>
    <Head :title="props.activity.name"></Head>
    <SidebarLayout>
        <BackButton url="/activities"></BackButton>
        <div
            class="mx-auto mt-16 flex w-5/6 flex-col-reverse justify-around rounded-md bg-primary p-4 md:flex-row"
        >
            <div class="w-full text-white md:w-1/2">
                <h1 class="text-3xl md:text-4xl">{{ props.activity.name }}</h1>
                <div class="flex w-full flex-row justify-start md:w-1/2">
                    <p>{{ props.activity.start_time }}</p>
                    <p class="ms-4">{{ props.activity.end_time }}</p>
                </div>
                <p>{{ props.activity.place }}</p>
                <div class="flex w-full flex-row justify-start md:w-1/2">
                    <p>Preu soci: {{ props.activity.member_price }}€</p>
                    <p class="ms-2 md:ms-4">
                        Preu no soci: {{ props.activity.nonmember_price }}€
                    </p>
                </div>
                <p>{{ props.activity.description }}</p>

                <!-- WIP <p>{{ props.activity.monitor_salary }}</p>
                <p>{{ props.activity.participants_id }}</p>
                <p>{{ props.activity.monitors_info }}</p>
                <p>{{ props.activity.collaborations }}</p>-->
            </div>

            <div class="max-h-48 min-h-48 w-full md:max-h-72 md:w-1/3">
                <Fancybox :options="{}">
                    <a
                        data-fancybox
                        :href="props.activity.imageRoute"
                        aria-label="Fancybox link"
                    >
                        <img
                            :src="props.activity.imageRoute"
                            :alt="'foto de' + props.activity.name"
                            class="h-full w-full object-cover"
                        />
                    </a>
                </Fancybox>
            </div>
        </div>
    </SidebarLayout>
</template>
