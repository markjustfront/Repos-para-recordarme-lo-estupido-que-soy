<script setup>
import { Head, Link } from '@inertiajs/vue3';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import axios from 'axios';
import { onMounted, ref } from 'vue';
import LoadingAnimation from '@/Components/LoadingAnimation.vue';
import SearchBar from '@/Components/SearchBar.vue';

const activities = ref([]);
const filteredActivities = ref([]);

const activitiesLoaded = ref(false);
const input = ref('');
// Function to list all activities
const listActivities = () => {
    activitiesLoaded.value = false;
    axios
        .get('/api/activities')
        .then((response) => {
            activities.value = response.data.map((activity) => ({
                ...activity,
                description: activity.description.substring(0, 80) + '...',
            }));
            filteredActivities.value = activities.value;
            activitiesLoaded.value = true;
        })
        .catch((error) => {
            console.log(error);
        });
};

// Function to filter activities
const search = () => {
    return (filteredActivities.value = activities.value.filter((activity) =>
        activity.name.toLowerCase().includes(input.value.toLowerCase()),
    ));
};

onMounted(listActivities);
</script>
<template>
    <Head title="Llista d'activitats"></Head>
    <SidebarLayout>
        <div class="flex min-h-screen w-full flex-col items-center p-8">
            <SearchBar
                placeholder="Buscar activitat..."
                class="mb-4"
                v-model="input"
                aria-label="Cerca activitats"
            ></SearchBar>
            <LoadingAnimation
                class="mt-5"
                color="#000000"
                v-if="!activitiesLoaded"
                aria-label="Carregant activitats"
            ></LoadingAnimation>
            <div
                class="mt-5 w-11/12 overflow-y-auto overflow-x-hidden md:max-h-[750px] md:w-4/6"
                v-if="activitiesLoaded"
                aria-live="polite"
            >
                <Link
                    class="mb-3 flex min-h-32 min-w-full max-w-full cursor-pointer flex-row rounded-md bg-secondary p-4 shadow-md transition-all duration-200 ease-in-out hover:max-h-80 hover:min-h-80 hover:bg-blue-700 md:max-h-72 md:min-h-72"
                    v-for="(activity, index) in search()"
                    :key="index"
                    :href="'/activity/' + activity.id"
                    tabindex="0"
                >
                    <div
                        class="max-h-full min-h-28 min-w-32 max-w-32 rounded-md bg-white md:max-h-64 md:min-h-64 md:min-w-64 md:max-w-64"
                    >
                        <img
                            :src="activity.imageRoute"
                            class="max-h-full min-h-full min-w-full max-w-full object-cover"
                            :alt="`Imatge de l'activitat ${activity.name}`"
                        />
                    </div>
                    <div class="ms-2 flex flex-col md:ms-4">
                        <h2
                            class="break-words text-3xl uppercase text-white md:text-6xl"
                        >
                            {{ activity.name }}
                        </h2>
                        <p class="break-words capitalize text-white md:text-3xl">
                            {{ activity.description }}
                        </p>
                    </div>
                </Link>
            </div>
        </div>
    </SidebarLayout>
</template>