<script setup>
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { ref, onMounted, computed, nextTick } from 'vue';
import axios from 'axios';
import { Head, Link } from '@inertiajs/vue3';
import LoadingAnimation from '@/Components/LoadingAnimation.vue';
import SearchBar from '@/Components/SearchBar.vue';

const monitors = ref([]);
const checkedMonitors = ref([]);
const showInfoModal = ref(false);
const showEditModal = ref(false);
const selectedMonitor = ref(null);
const editableMonitor = ref(null);
const monitorsLoaded = ref(false);
const infoModal = ref(null);
const editModal = ref(null);
const input = ref('');

// Toggle all checkboxes
const toggleCheckboxAll = () => {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    const newState = checkedMonitors.value.length !== monitors.value.length;

    checkedMonitors.value = newState
        ? [...Array(monitors.value.length).keys()]
        : [];

    checkboxes.forEach((checkbox) => {
        checkbox.checked = newState;
    });
};

// Toggle monitor selection
const toggleMonitorSelection = (index) => {
    const position = checkedMonitors.value.indexOf(index);
    if (position === -1) {
        checkedMonitors.value.push(index);
    } else {
        checkedMonitors.value.splice(position, 1);
    }
};

// Delete multiple selected monitors
const deleteToggleCheckboxAll = () => {
    const selectedMonitorIds = checkedMonitors.value.map(
        (index) => monitors.value[index].id,
    );

    if (selectedMonitorIds.length === 0) {
        console.log('No monitors selected');
        return;
    }

    axios
        .delete('/monitor/delete/massive', {
            data: { ids: selectedMonitorIds },
        })
        .then(() => {
            checkedMonitors.value = [];
            listMonitors();
        })
        .catch((error) => {
            console.error('Error deleting monitors:', error);
        });
};

// List all monitors
const listMonitors = () => {
    monitorsLoaded.value = false;
    axios
        .get('/api/monitor')
        .then((response) => {
            monitors.value = response.data;
            monitorsLoaded.value = true;
        })
        .catch((error) => {
            console.log(error);
        });
};

// Modal controls
const openInfoModal = (monitor) => {
    selectedMonitor.value = monitor;
    showInfoModal.value = true;
    nextTick(() => infoModal.value?.focus());
};

// Open edit modal
const openEditModal = (monitor) => {
    selectedMonitor.value = monitor;
    editableMonitor.value = JSON.parse(JSON.stringify(monitor));
    if (editableMonitor.value.birthday) {
        editableMonitor.value.birthday = formatDate(
            editableMonitor.value.birthday,
        );
    }
    if (editableMonitor.value.contract_start) {
        editableMonitor.value.contract_start = formatDate(
            editableMonitor.value.contract_start,
        );
    }
    if (editableMonitor.value.contract_end) {
        editableMonitor.value.contract_end = formatDate(
            editableMonitor.value.contract_end,
        );
    }
    showEditModal.value = true;
    nextTick(() => editModal.value?.focus());
};

// Close info modal
const closeInfoModal = () => {
    showInfoModal.value = false;
    selectedMonitor.value = null;
};

// Close edit modal
const closeEditModal = () => {
    showEditModal.value = false;
    selectedMonitor.value = null;
};

// Save monitor changes
const saveMonitorChanges = () => {
    axios
        .patch('/monitor/update', {
            monitor_id: editableMonitor.value.id,
            ...editableMonitor.value,
        })
        .then(() => {
            listMonitors();
            closeEditModal();
        })
        .catch((error) => {
            console.error('Error', error);
        });
};

// Delete a single monitor
const deleteMonitor = (monitor) => {
    axios
        .delete('/monitor/delete', { data: { id: monitor.id } })
        .then(() => {
            listMonitors();
        })
        .catch((error) => {
            console.error('Error:', error);
        });
};

// Format date
const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
};

// Computed properties for button visibility
const selectedMonitorsCount = computed(() => checkedMonitors.value.length);
const singleSelectedMonitor = computed(() => {
    return selectedMonitorsCount.value === 1
        ? monitors.value[checkedMonitors.value[0]]
        : null;
});

//Check what modal to open
const editSelectedMonitor = () => {
    if (singleSelectedMonitor.value) openEditModal(singleSelectedMonitor.value);
};

// Check what monitor to delete
const deleteSelectedMonitor = () => {
    if (singleSelectedMonitor.value) deleteMonitor(singleSelectedMonitor.value);
};

// Search function
const searchBarMonitor = () => {
    return monitors.value.filter((monitor) =>
        monitor.name.toLowerCase().includes(input.value.toLowerCase()),
    );
};

// Validation functions
const validateDNI = (dni) => /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$/i.test(dni);
const validateEmail = (email) =>
    /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{3,6}$/.test(email);
const validatePhoneNumber = (phonenumber) => /^[0-9]{9}$/.test(phonenumber);
const validateDirection = (direction) =>
    direction.length > 2 && direction.length < 50;
const validateName = (name) => name.length > 2 && name.length < 30;
const validateSurnames = (surnames) =>
    surnames.length > 2 && surnames.length < 80;
const validateContractStart = (contract_start) =>
    /^\d{4}-\d{2}-\d{2}$/.test(contract_start);
const validateContractEnd = (contract_end) => {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    const startDate = new Date(editableMonitor.value?.contract_start);
    const endDate = new Date(contract_end);
    return dateRegex.test(contract_end) && endDate > startDate;
};
const validateBirthday = (birthday) => {
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    const today = new Date().toISOString().split('T')[0];
    return dateRegex.test(birthday) && birthday < today;
};
const validateEntryYear = (entry_year) =>
    entry_year > 1899 && entry_year < 2025;

defineProps({ translations: Object });
onMounted(listMonitors);
</script>

<template>
    <Head title="Llista de monitors"></Head>
    <SidebarLayout>
        <div
            class="mx-auto mt-14 flex h-[720px] w-5/6 flex-col rounded-md bg-secondary p-6 md:h-[630px]"
        >
            <h1
                class="sticky top-0 z-10 flex w-full items-center justify-center bg-secondary pb-3 pt-5 text-center text-3xl font-light text-white"
            >
                LLISTA DE MONITORS
            </h1>
            <div
                class="sticky top-0 z-10 mb-4 items-center justify-center bg-secondary pb-3 pt-5 text-white md:flex"
            >
                <div class="flex flex-col items-center min-[1500px]:flex-row">
                    <button
                        @click="toggleCheckboxAll"
                        class="h-10 w-24 rounded-md bg-mclaren text-white transition-colors duration-75 ease-in-out hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        aria-label="Marcar o desmarcar tots els monitors"
                    >
                        {{
                            checkedMonitors.length === monitors.length
                                ? 'Desmarcar'
                                : 'Tots'
                        }}
                    </button>
                    <SearchBar
                        class="w-auto rounded-md text-black md:mb-0 md:mt-0"
                        type="text"
                        placeholder="Buscar monitors..."
                        v-model="input"
                        aria-label="Cercar monitors"
                    />
                    <div
                        class="my-3 flex flex-row items-center justify-center space-x-2 min-[1500px]:ml-2"
                        aria-live="polite"
                    >
                        <button
                            v-if="selectedMonitorsCount === 1"
                            @click="editSelectedMonitor"
                            class="h-10 w-24 rounded-md bg-mclaren text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        >
                            Editar
                        </button>
                        <button
                            v-if="selectedMonitorsCount === 1"
                            @click="deleteSelectedMonitor"
                            class="h-10 w-24 rounded-md bg-red-600 text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-red-600"
                        >
                            Eliminar
                        </button>
                        <button
                            v-if="selectedMonitorsCount > 1"
                            @click="deleteToggleCheckboxAll"
                            class="flex h-10 w-auto items-center rounded-md bg-red-600 px-4 text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-red-600"
                            aria-label="Eliminar monitors seleccionats"
                        >
                            <span>Eliminar ({{ selectedMonitorsCount }})</span>
                        </button>
                        <button
                            v-if="selectedMonitorsCount === 0"
                            disabled
                            class="h-10 w-24 rounded-md bg-gray-400 text-white"
                            aria-disabled="true"
                        >
                            Editar
                        </button>
                        <button
                            v-if="selectedMonitorsCount === 0"
                            disabled
                            class="h-10 w-24 rounded-md bg-gray-400 text-white"
                            aria-disabled="true"
                        >
                            Eliminar
                        </button>
                    </div>
                </div>
            </div>

            <LoadingAnimation
                v-if="!monitorsLoaded"
                aria-label="Carregant llista de monitors"
            />
            <div
                class="w-full overflow-y-auto overflow-x-hidden"
                v-if="monitorsLoaded"
                role="list"
                aria-label="Llista de monitors"
            >
                <div
                    v-for="(monitor, index) in searchBarMonitor()"
                    :key="monitor.id"
                    role="listitem"
                    class="mx-5 mb-2 grid items-center gap-4 rounded-md bg-white p-2"
                >
                    <div
                        class="mb-2 grid w-full grid-cols-6 items-center gap-4 rounded-md bg-white p-2 sm:grid-cols-6 xl:grid-cols-6"
                    >
                        <div class="flex items-center justify-center">
                            <input
                                type="checkbox"
                                :id="'monitor-' + index"
                                :checked="checkedMonitors.includes(index)"
                                @change="toggleMonitorSelection(index)"
                                class="h-5 w-5 rounded text-mclaren checked:bg-mclaren checked:ring-mclaren focus:ring-2 focus:ring-mclaren focus:ring-offset-0"
                                :aria-label="`Seleccionar ${monitor.name}`"
                            />
                        </div>
                        <div class="col-span-1">
                            <p class="font-semibold">{{ monitor.name }}</p>
                        </div>
                        <div class="col-span-2">
                            <p class="hidden font-semibold xl:flex">
                                {{ monitor.email }}
                            </p>
                        </div>
                        <div class="col-span-1">
                            <p class="hidden font-semibold capitalize sm:flex">
                                {{ monitor.role }}
                            </p>
                        </div>
                        <div class="col-span-1 flex justify-end space-x-2">
                            <svg
                                @click="openInfoModal(monitor)"
                                role="button"
                                :aria-label="`Veure informació de ${monitor.name}`"
                                tabindex="0"
                                @keydown.enter="openInfoModal(monitor)"
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="mr-2 mt-1 size-8 cursor-pointer stroke-mclaren hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-mclaren"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M12 4.5v15m7.5-7.5h-15"
                                />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Info Modal -->
        <div
            v-if="showInfoModal"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
            role="dialog"
            aria-modal="true"
            aria-labelledby="info-modal-title"
        >
            <div
                class="max-h-[80vh] w-full max-w-md overflow-auto rounded-lg bg-white p-8"
                tabindex="-1"
                ref="infoModal"
            >
                <div class="mb-6 flex items-center justify-between">
                    <h3
                        id="info-modal-title"
                        class="text-xl font-bold text-gray-800"
                    >
                        Informació adicional
                    </h3>
                    <button
                        @click="closeInfoModal"
                        @keydown.enter="closeInfoModal"
                        tabindex="0"
                        class="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                        aria-label="Tancar modal d'informació"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-6 w-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>
                <div v-if="selectedMonitor" class="space-y-4">
                    <div class="flex space-x-20">
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Nom</p>
                            <p class="font-semibold">
                                {{ selectedMonitor.name }}
                            </p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Cognoms</p>
                            <p class="font-semibold">
                                {{ selectedMonitor.surnames }}
                            </p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">DNI</p>
                            <p class="font-semibold">
                                {{ selectedMonitor.dni }}
                            </p>
                        </div>
                    </div>
                    <div class="border-b pb-2 sm:hidden">
                        <p class="text-sm text-gray-500">Rol</p>
                        <p class="font-semibold">{{ selectedMonitor.role }}</p>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Direcció</p>
                        <p class="font-semibold">
                            {{ selectedMonitor.direction }}
                        </p>
                    </div>
                    <div class="border-b pb-2 xl:hidden">
                        <p class="text-sm text-gray-500">Email</p>
                        <p class="font-semibold">{{ selectedMonitor.email }}</p>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Telèfon</p>
                        <p class="font-semibold">
                            {{ selectedMonitor.phonenumber }}
                        </p>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Aniversari</p>
                        <p class="font-semibold">
                            {{ formatDate(selectedMonitor.birthday) }}
                        </p>
                    </div>
                    <div class="flex space-x-20">
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Inici contracte</p>
                            <p class="font-semibold">
                                {{ formatDate(selectedMonitor.contract_start) }}
                            </p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">Fi contracte</p>
                            <p class="font-semibold">
                                {{ formatDate(selectedMonitor.contract_end) }}
                            </p>
                        </div>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Nivell d'estudi</p>
                        <p
                            class="font-semibold"
                            v-if="selectedMonitor.study_level === 0"
                        >
                            ESO
                        </p>
                        <p
                            class="font-semibold"
                            v-if="selectedMonitor.study_level === 1"
                        >
                            Batxillerat/CFGM
                        </p>
                        <p
                            class="font-semibold"
                            v-if="selectedMonitor.study_level === 2"
                        >
                            CFGS
                        </p>
                        <p
                            class="font-semibold"
                            v-if="selectedMonitor.study_level === 3"
                        >
                            Universitat
                        </p>
                        <p
                            class="font-semibold"
                            v-if="selectedMonitor.study_level === 4"
                        >
                            Altres
                        </p>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">Any d'entrada</p>
                        <p class="font-semibold">
                            {{ selectedMonitor.entry_year }}
                        </p>
                    </div>
                </div>
                <div class="mt-8 flex justify-end">
                    <button
                        @click="closeInfoModal"
                        class="rounded-md bg-mclaren px-4 py-2 text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        aria-label="Tancar modal d'informació"
                    >
                        Tancar
                    </button>
                </div>
            </div>
        </div>

        <!-- Edit Modal -->
        <div
            v-if="showEditModal"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
            role="dialog"
            aria-modal="true"
            aria-labelledby="edit-modal-title"
        >
            <div
                class="max-h-[80vh] w-full max-w-4xl overflow-auto rounded-lg bg-white p-8"
                tabindex="-1"
                ref="editModal"
            >
                <div class="mb-6 flex items-center justify-between">
                    <h3
                        id="edit-modal-title"
                        class="text-xl font-bold text-gray-800"
                    >
                        Editar monitor
                    </h3>
                    <button
                        @click="closeEditModal"
                        @keydown.enter="closeEditModal"
                        tabindex="0"
                        class="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                        aria-label="Tancar modal d'edició"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-6 w-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>
                <div v-if="editableMonitor" class="space-y-4">
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="name"
                                >Nom</label
                            >
                            <input
                                type="text"
                                v-model="editableMonitor.name"
                                class="w-full rounded-md border p-2"
                                id="name"
                                :aria-describedby="
                                    !validateName(editableMonitor.name)
                                        ? 'name-error'
                                        : null
                                "
                            />
                            <span
                                v-if="!validateName(editableMonitor.name)"
                                id="name-error"
                                class="text-red-500"
                            >
                                El nom ha de ser més gran de 2 caràcters i més
                                petit de 30
                            </span>
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="surname"
                                >Cognoms</label
                            >
                            <input
                                type="text"
                                v-model="editableMonitor.surnames"
                                class="w-full rounded-md border p-2"
                                id="surname"
                                :aria-describedby="
                                    !validateSurnames(editableMonitor.surnames)
                                        ? 'surname-error'
                                        : null
                                "
                            />
                            <span
                                v-if="
                                    !validateSurnames(editableMonitor.surnames)
                                "
                                id="surname-error"
                                class="text-red-500"
                            >
                                Els cognoms han de ser més grans de 2 caràcters
                                i més petits de 80
                            </span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="direction"
                                >Direcció</label
                            >
                            <input
                                type="text"
                                v-model="editableMonitor.direction"
                                class="w-full rounded-md border p-2"
                                id="direction"
                                :aria-describedby="
                                    !validateDirection(
                                        editableMonitor.direction,
                                    )
                                        ? 'direction-error'
                                        : null
                                "
                            />
                            <span
                                v-if="
                                    !validateDirection(
                                        editableMonitor.direction,
                                    )
                                "
                                id="direction-error"
                                class="text-red-500"
                            >
                                La direcció ha de ser més petit de 50 caràcters
                            </span>
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="phone"
                                >Telèfon</label
                            >
                            <input
                                type="text"
                                v-model="editableMonitor.phonenumber"
                                class="w-full rounded-md border p-2"
                                id="phone"
                                :aria-describedby="
                                    !validatePhoneNumber(
                                        editableMonitor.phonenumber,
                                    )
                                        ? 'phone-error'
                                        : null
                                "
                            />
                            <span
                                v-if="
                                    !validatePhoneNumber(
                                        editableMonitor.phonenumber,
                                    )
                                "
                                id="phone-error"
                                class="text-red-500"
                            >
                                El telèfon ha de ser de 9 números
                            </span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="email"
                                >Email</label
                            >
                            <input
                                type="email"
                                v-model="editableMonitor.email"
                                class="w-full rounded-md border p-2"
                                id="email"
                                :aria-describedby="
                                    !validateEmail(editableMonitor.email)
                                        ? 'email-error'
                                        : null
                                "
                            />
                            <span
                                v-if="!validateEmail(editableMonitor.email)"
                                id="email-error"
                                class="text-red-500"
                            >
                                El correu electrònic ha de ser vàlid
                            </span>
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="dni"
                                >DNI</label
                            >
                            <input
                                type="text"
                                v-model="editableMonitor.dni"
                                class="w-full rounded-md border p-2"
                                id="dni"
                                :aria-describedby="
                                    !validateDNI(editableMonitor.dni)
                                        ? 'dni-error'
                                        : null
                                "
                            />
                            <span
                                v-if="!validateDNI(editableMonitor.dni)"
                                id="dni-error"
                                class="text-red-500"
                            >
                                El DNI son 8 números y 1 lletra
                            </span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label
                                class="text-sm text-gray-500"
                                for="contract_start"
                                >Inici contracte</label
                            >
                            <input
                                type="date"
                                v-model="editableMonitor.contract_start"
                                class="w-full rounded-md border p-2"
                                id="contract_start"
                                :aria-describedby="
                                    !validateContractStart(
                                        editableMonitor.contract_start,
                                    )
                                        ? 'contract-start-error'
                                        : null
                                "
                            />
                            <span
                                v-if="
                                    !validateContractStart(
                                        editableMonitor.contract_start,
                                    )
                                "
                                id="contract-start-error"
                                class="text-red-500"
                            >
                                La data d'inici de contracte és obligatòria
                            </span>
                        </div>
                        <div class="border-b pb-2">
                            <label
                                class="text-sm text-gray-500"
                                for="contract_end"
                                >Fi contracte</label
                            >
                            <input
                                type="date"
                                v-model="editableMonitor.contract_end"
                                class="w-full rounded-md border p-2"
                                id="contract_end"
                                :aria-describedby="
                                    !validateContractEnd(
                                        editableMonitor.contract_end,
                                    )
                                        ? 'contract-end-error'
                                        : null
                                "
                            />
                            <span
                                v-if="
                                    !validateContractEnd(
                                        editableMonitor.contract_end,
                                    )
                                "
                                id="contract-end-error"
                                class="text-red-500"
                            >
                                La data de fi ha de ser posterior a la data
                                d'inici
                            </span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="birthday"
                                >Aniversari</label
                            >
                            <input
                                type="date"
                                v-model="editableMonitor.birthday"
                                class="w-full rounded-md border p-2"
                                id="birthday"
                                :aria-describedby="
                                    !validateBirthday(editableMonitor.birthday)
                                        ? 'birthday-error'
                                        : null
                                "
                            />
                            <span
                                v-if="
                                    !validateBirthday(editableMonitor.birthday)
                                "
                                id="birthday-error"
                                class="text-red-500"
                            >
                                La data d'aniversari ha de ser anterior a la
                                data actual
                            </span>
                        </div>
                        <div class="border-b pb-2">
                            <label
                                class="text-sm text-gray-500"
                                for="entry_year"
                                >Any d'entrada</label
                            >
                            <input
                                type="text"
                                v-model="editableMonitor.entry_year"
                                class="w-full rounded-md border p-2"
                                id="entry_year"
                                :aria-describedby="
                                    !validateEntryYear(
                                        editableMonitor.entry_year,
                                    )
                                        ? 'entry-year-error'
                                        : null
                                "
                            />
                            <span
                                v-if="
                                    !validateEntryYear(
                                        editableMonitor.entry_year,
                                    )
                                "
                                id="entry-year-error"
                                class="text-red-500"
                            >
                                L'any d'entrada ha de ser entre 1997 - 2025
                            </span>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label
                                class="text-sm text-gray-500"
                                for="study_level"
                                >Nivell d'estudis</label
                            >
                            <select
                                v-model="editableMonitor.study_level"
                                class="w-full rounded-md border p-2"
                                id="study_level"
                                aria-label="Nivell d'estudis"
                            >
                                <option value="0">ESO</option>
                                <option value="1">Batxillerat/CFGM</option>
                                <option value="2">CFGS</option>
                                <option value="3">Universitat</option>
                                <option value="4">Altres</option>
                            </select>
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="role"
                                >Rol</label
                            >
                            <select
                                v-model="editableMonitor.role"
                                class="w-full rounded-md border p-2"
                                id="role"
                                aria-label="Rol del monitor"
                            >
                                <option value="coordinator">Coordinador</option>
                                <option value="responsable">Responsable</option>
                                <option value="monitor">Monitor</option>
                                <option value="volunteer">Voluntari</option>
                            </select>
                        </div>
                    </div>
                    <div class="border-b pb-2">
                        <label class="text-sm text-gray-500" for="active"
                            >Actiu</label
                        >
                        <input
                            type="checkbox"
                            v-model="editableMonitor.active"
                            class="ms-2 rounded-md border p-2 text-mclaren checked:bg-mclaren checked:ring-mclaren focus:ring-2 focus:ring-mclaren focus:ring-offset-0"
                            id="active"
                            aria-label="Estat actiu del monitor"
                        />
                    </div>
                </div>
                <div class="mt-8 flex justify-end space-x-4">
                    <button
                        @click="closeEditModal"
                        class="rounded-md bg-gray-300 px-4 py-2 text-gray-800 hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300"
                    >
                        Cancel·lar
                    </button>
                    <button
                        @click="saveMonitorChanges"
                        class="rounded-md bg-mclaren px-4 py-2 text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-mclaren"
                    >
                        Editar
                    </button>
                </div>
            </div>
        </div>
    </SidebarLayout>
</template>
