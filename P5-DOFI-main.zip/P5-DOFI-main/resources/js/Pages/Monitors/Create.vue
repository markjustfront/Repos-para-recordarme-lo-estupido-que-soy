<!-- resources/js/Pages/Monitors/Create.vue -->
<script setup>
import FormButton from '@/Components/FormButton.vue';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { useForm, Head } from '@inertiajs/vue3';
import { ref, watch } from 'vue';
import axios from 'axios';

const form = useForm({
    dni: '',
    name: '',
    surnames: '',
    birthday: '',
    direction: '',
    entry_year: '',
    active: true,
    last_activity: null,
    study_level: '',
    monitor_permit: false,
    email: '',
    phonenumber: '',
    role: 'monitor',
    contract_start: '',
    contract_end: '',
    tutor_id: null,
});

const age = ref(null);
const tutors = ref([]);

// Fetch tutors using Axios
const fetchTutors = async () => {
    try {
        const response = await axios.get('/api/tutor/name');
        tutors.value = response.data;
    } catch (error) {
        console.error('Error fetching tutors:', error);
    }
};
fetchTutors();

// Calculate age based on birthday
const calculateAge = (birthday) => {
    if (!birthday) return null;
    const birthDate = new Date(birthday);
    const today = new Date();
    let calculatedAge = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (
        monthDiff < 0 ||
        (monthDiff === 0 && today.getDate() < birthDate.getDate())
    ) {
        calculatedAge--;
    }
    return calculatedAge;
};

watch(
    () => form.birthday,
    (newBirthday) => {
        age.value = calculateAge(newBirthday);
    },
);

// Submit form
const sendForm = () => {
    form.post(route('monitors.create'), {
        onSuccess: () => form.reset(),
        onError: () => console.log(form.errors),
    });
};
</script>

<template>
    <Head title="Afegir monitor"></Head>
    <SidebarLayout>
        <div class="container mx-auto mt-5 px-4 sm:px-6 lg:px-8">
            <div
                class="mx-auto w-full max-w-2xl rounded-lg bg-primary p-6 shadow-md"
            >
                <h1
                    class="mb-6 text-center text-2xl font-bold text-white sm:text-3xl md:text-4xl"
                >
                    AFEGIR MONITOR
                </h1>

                <form
                    @submit.prevent="sendForm"
                    class="flex flex-col gap-4"
                    enctype="multipart/form-data"
                    id="monitorForm"
                >
                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="flex flex-col">
                            <label
                                for="dni"
                                class="text-sm text-white sm:text-base"
                            >DNI:</label
                            >
                            <input
                                type="text"
                                id="dni"
                                v-model="form.dni"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.dni"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.dni }}</span
                            >
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="name"
                                class="text-sm text-white sm:text-base"
                            >Nom:</label
                            >
                            <input
                                type="text"
                                id="name"
                                v-model="form.name"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.name"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.name }}</span
                            >
                        </div>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="flex flex-col">
                            <label
                                for="surnames"
                                class="text-sm text-white sm:text-base"
                            >Cognoms:</label
                            >
                            <input
                                type="text"
                                id="surnames"
                                v-model="form.surnames"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.surnames"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.surnames }}</span
                            >
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="email"
                                class="text-sm text-white sm:text-base"
                            >Email:</label
                            >
                            <input
                                type="email"
                                id="email"
                                v-model="form.email"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.email"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.email }}</span
                            >
                        </div>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="flex flex-col">
                            <label
                                for="phonenumber"
                                class="text-sm text-white sm:text-base"
                            >Telèfon:</label
                            >
                            <input
                                type="tel"
                                id="phonenumber"
                                v-model="form.phonenumber"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.phonenumber"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.phonenumber }}</span
                            >
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="birthday"
                                class="text-sm text-white sm:text-base"
                            >Data de naixement:</label
                            >
                            <input
                                type="date"
                                id="birthday"
                                v-model="form.birthday"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.birthday"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.birthday }}</span
                            >
                            <span
                                v-if="age !== null"
                                class="mt-1 text-sm text-white"
                            >Tens {{ age }} anys</span
                            >
                        </div>
                    </div>

                    <div class="flex flex-col">
                        <label
                            for="direction"
                            class="text-sm text-white sm:text-base"
                        >Direcció:</label
                        >
                        <input
                            type="text"
                            id="direction"
                            v-model="form.direction"
                            class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                        />
                        <span
                            v-if="form.errors.direction"
                            class="mt-1 text-sm text-red-500"
                        >{{ form.errors.direction }}</span
                        >
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="flex flex-col">
                            <label
                                for="entry_year"
                                class="text-sm text-white sm:text-base"
                            >Any d’entrada:</label
                            >
                            <input
                                type="text"
                                id="entry_year"
                                v-model="form.entry_year"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.entry_year"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.entry_year }}</span
                            >
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="role"
                                class="text-sm text-white sm:text-base"
                            >Rol:</label
                            >
                            <select
                                id="role"
                                v-model="form.role"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            >
                                <option value="monitor">Monitor</option>
                                <option value="coordinator">Coordinador</option>
                                <option value="responsable">Responsable</option>
                                <option value="volunteer">Voluntari</option>
                            </select>
                            <span
                                v-if="form.errors.role"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.role }}</span
                            >
                        </div>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="flex flex-col">
                            <label
                                for="contract_start"
                                class="text-sm text-white sm:text-base"
                            >Inici del contracte:</label
                            >
                            <input
                                type="date"
                                id="contract_start"
                                v-model="form.contract_start"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.contract_start"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.contract_start }}</span
                            >
                        </div>
                        <div class="flex flex-col">
                            <label
                                for="contract_end"
                                class="text-sm text-white sm:text-base"
                            >Fi del contracte:</label
                            >
                            <input
                                type="date"
                                id="contract_end"
                                v-model="form.contract_end"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            />
                            <span
                                v-if="form.errors.contract_end"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.contract_end }}</span
                            >
                        </div>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="flex flex-col">
                            <label
                                for="study_level"
                                class="text-sm text-white sm:text-base"
                            >Nivell d’estudis:</label
                            >
                            <select
                                id="study_level"
                                v-model="form.study_level"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            >
                                <option value="0">ESO</option>
                                <option value="1">Batxillerat/CFGM</option>
                                <option value="2">CFGS</option>
                                <option value="3">Universitat</option>
                                <option value="4">Altres</option>
                            </select>
                            <span
                                v-if="form.errors.study_level"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.study_level }}</span
                            >
                        </div>
                        <div
                            v-if="age !== null && age < 18"
                            class="flex flex-col"
                        >
                            <label
                                for="tutor_id"
                                class="text-sm text-white sm:text-base"
                            >Tutor:</label
                            >
                            <select
                                id="tutor_id"
                                v-model="form.tutor_id"
                                class="w-full rounded-md border-gray-300 px-3 py-2 text-sm text-black shadow-sm focus:border-mclaren focus:ring-mclaren sm:text-base"
                            >
                                <option value="">Selecciona un tutor</option>
                                <option
                                    v-for="tutor in tutors"
                                    :value="tutor.id"
                                    :key="tutor.id"
                                >
                                    {{ tutor.name }}
                                </option>
                            </select>
                            <span
                                v-if="form.errors.tutor_id"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.tutor_id }}</span
                            >
                        </div>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                        <div class="flex flex-col">
                            <label
                                for="monitor_permit"
                                class="text-sm text-white sm:text-base"
                            >Permís de monitor:</label
                            >
                            <input
                                type="checkbox"
                                id="monitor_permit"
                                v-model="form.monitor_permit"
                                class="rounded-md border-gray-300 shadow-sm focus:border-mclaren focus:ring-mclaren"
                            />
                            <span
                                v-if="form.errors.monitor_permit"
                                class="mt-1 text-sm text-red-500"
                            >{{ form.errors.monitor_permit }}</span
                            >
                        </div>
                    </div>
                </form>
            </div>

            <div class="mt-6 flex justify-center">
                <FormButton
                    type="submit"
                    form="monitorForm"
                    class="hover:bg-mclaren-dark rounded-md bg-mclaren px-4 py-2 font-bold text-white transition-colors duration-200"
                >
                    Afegeix
                </FormButton>
            </div>
        </div>
    </SidebarLayout>
</template>
