<script setup>
import SidebarLayout from "@/Layouts/SidebarLayout.vue";
import { Link } from "@inertiajs/vue3";
</script>

<template>
    <SidebarLayout>
        <div 
            class="w-5/6 flex flex-row mt-20 mx-auto" 
            role="navigation" 
            aria-label="Opcions de gestió de reunions"
        >
            <Link 
                href="/meeting/add" 
                class="enabled-link focus:outline-none focus:ring-2 focus:ring-blue-500" 
                aria-label="Crear una nova reunió"
            >
                Crear
            </Link>
            <Link 
                href="#" 
                class="mx-8 disabled-link" 
                aria-label="Esborrar reunions (desactivat)" 
                aria-disabled="true" 
                @click.prevent
            >
                Esborrar
            </Link>
            <Link 
                href="#" 
                class="disabled-link" 
                aria-label="Llistar reunions (desactivat)" 
                aria-disabled="true" 
                @click.prevent
            >
                Llistar
            </Link>
        </div>
    </SidebarLayout>
</template>