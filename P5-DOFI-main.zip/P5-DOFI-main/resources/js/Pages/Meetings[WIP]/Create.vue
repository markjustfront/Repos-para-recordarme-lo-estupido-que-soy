<script setup>
import FormButton from '@/Components/FormButton.vue';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { useForm, Head } from '@inertiajs/vue3';
import { ref } from 'vue';

const form = useForm({
    type: '',
    route: '',
    assistants: '',
    observations: '',
    date: '',
    place: '',
});

const formStatus = ref('');
const sendForm = () => {
    form.post(route('reunions.store'), {
        onSuccess: () => formStatus.value = 'Reunió afegida amb èxit',
        onError: () => formStatus.value = 'Error en afegir la reunió'
    });
};

const openFileInput = () => {
    document.getElementById('route').click();
};
</script>

<template>
    <Head title="Afegir reunió"></Head>
    <SidebarLayout>
        <div>
            <form enctype="multipart/form-data" @submit.prevent="sendForm()">
                <div
                    class="mx-auto mt-5 flex w-fit min-w-96 flex-col items-center rounded-lg bg-secondary p-2 text-white shadow-md"
                >
                    <h1 class="text-4xl font-bold">REUNIONS</h1>
                    <div class="flex flex-col items-center">
                        <div class="form-field flex flex-col items-center">
                            <label for="type" class="font-light">Tipus de reunió</label>
                            <select
                                id="type"
                                name="type"
                                v-model="form.type"
                                class="rounded-md border-gray-300 text-black shadow-sm focus:border-mclaren focus:ring-mclaren"
                            >
                                <option value="" disabled selected>Selecciona un tipus</option>
                                <option value="1">Junta</option>
                                <option value="2">Soci</option>
                                <option value="3">Monitor</option>
                            </select>
                        </div>

                        <div class="form-field flex flex-col items-center">
                            <label for="route" class="font-light">Acta</label>
                            <input
                                type="file"
                                id="route"
                                name="route"
                                @input="form.route = $event.target.files[0]"
                                class="rounded-md border-gray-300 text-black shadow-sm focus:border-mclaren focus:ring-mclaren"
                                accept="application/pdf"
                            />
                        </div>

                        <div class="form-field flex flex-col items-center">
                            <label for="assistants" class="font-light">Assistents</label>
                            <input
                                type="text"
                                id="assistants"
                                name="assistants"
                                v-model="form.assistants"
                                class="rounded-md border-gray-300 text-black shadow-sm focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>

                        <div class="form-field flex flex-col items-center">
                            <label for="observations" class="font-light">Observacions</label>
                            <input
                                type="text"
                                id="observations"
                                name="observations"
                                v-model="form.observations"
                                class="rounded-md border-gray-300 text-black shadow-sm focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>

                        <div class="form-field flex flex-col items-center">
                            <label for="date" class="font-light">Data</label>
                            <input
                                type="date"
                                id="date"
                                name="date"
                                v-model="form.date"
                                class="rounded-md border-gray-300 text-black shadow-sm focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>

                        <div class="form-field flex flex-col items-center">
                            <label for="place" class="font-light">Lloc</label>
                            <input
                                type="text"
                                id="place"
                                name="place"
                                v-model="form.place"
                                class="rounded-md border-gray-300 text-black shadow-sm focus:border-mclaren focus:ring-mclaren"
                            />
                        </div>
                    </div>
                </div>
                <div class="mt-4 flex w-full flex-row justify-center">
                    <FormButton 
                        type="submit" 
                        class="focus:outline-none focus:ring-2 focus:ring-mclaren"
                    >
                        Afegeix reunió
                    </FormButton>
                </div>
                <div aria-live="polite" class="sr-only">{{ formStatus }}</div>
            </form>
        </div>
    </SidebarLayout>
</template>