<script setup>
import Checkbox from '@/Components/Checkbox.vue';
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';

defineProps({
    canResetPassword: {
        type: Boolean,
    },
    status: {
        type: String,
    },
});

const form = useForm({
    name: '',
    password: '',
    remember: false,
});

//Submit login form
const submit = () => {
    form.post(route('login'), {
        onFinish: () => form.reset('password'),
    });
};
</script>

<template>
    <GuestLayout>
        <Head title="Log in" />

        <div v-if="status" class="mb-4 text-sm font-medium text-green-600">
            {{ status }}
        </div>
        <div class="">
            <h1
                class="my-5 flex justify-center text-5xl font-semibold text-white"
            >
                ENTRA
            </h1>
        </div>

        <form @submit.prevent="submit">
            <div>
                <InputLabel for="name" value="USUARI" />

                <TextInput
                    id="name"
                    type="text"
                    class="mt-1 block w-full"
                    v-model="form.name"
                    required
                    autofocus
                    autocomplete="name"
                />

                <InputError class="mt-2" :message="form.errors.name" />
            </div>

            <div class="mt-4">
                <InputLabel for="password" value="CONTRASENYA" />

                <TextInput
                    id="password"
                    type="password"
                    class="mt-1 block w-full"
                    v-model="form.password"
                    required
                    autocomplete="current-password"
                />

                <InputError class="mt-2" :message="form.errors.password" />
            </div>

            <div class="mt-4 flex items-center justify-center">
                <PrimaryButton
                    class="ms-4 font-light"
                    id="submitlogin"
                    :class="{ 'opacity-25': form.processing }"
                    :disabled="form.processing"
                >
                    ENTRA
                </PrimaryButton>
            </div>
        </form>
        <div class="mx-auto mt-5 flex w-full flex-row justify-around">
            <a
                href="/auth/github"
                aria-label="login with github"
                class="rounded-md bg-purple-950 p-2 text-xl text-white transition-colors duration-200 ease-in-out hover:bg-white hover:text-black"
                >Github</a
            >
            <a
                href="/auth/x"
                aria-label="login with x"
                class="ms-1 rounded-md bg-black p-2 text-xl text-white transition-colors duration-200 ease-in-out hover:bg-white hover:text-black"
                >X</a
            >
            <a
                href="/login-google"
                aria-label="login with google"
                class="ms-1 rounded-md bg-red-600 p-2 text-xl text-white transition-colors duration-200 ease-in-out hover:bg-red-700 hover:text-black"
                >Google</a
            >
            <a
                href="/auth/reddit"
                aria-label="login with reddit"
                class="ms-1 rounded-md bg-orange-600 p-2 text-xl text-white transition-colors duration-200 ease-in-out hover:bg-orange-700 hover:text-black"
                >Reddit</a
            >
            <a href="/login-facebook"
                aria-label="login with facebook"
                class="ms-1 rounded-md bg-blue-600 p-2 text-xl text-white transition-colors duration-200 ease-in-out hover:bg-blue-700 hover:text-black"
                >Facebook</a
            >
        </div>
    </GuestLayout>
</template>
