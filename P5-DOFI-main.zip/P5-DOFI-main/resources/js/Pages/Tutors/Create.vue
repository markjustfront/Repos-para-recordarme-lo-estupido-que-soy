<script setup>
import PrimaryButton from '@/Components/FormButton.vue';
import Notification from '@/Components/Notification.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import TextInput from '@/Components/TextInput.vue';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';
import { ref } from 'vue';

const form = useForm({
    name: '',
    surname: '',
    email: '',
    phone: '',
    for: '',
});

const notification = ref(false);

// Close notification
const closeNotification = () => {
    notification.value = false;
};

// Submit form
const submit = () => {
    form.post(route('tutor.create'), {
        onSuccess: () => {
            form.reset();
            notification.value = true;
            setTimeout(() => {
                notification.value = false;
            }, 5000);
        },
    });
};
</script>

<template>
    <Head title="Formulari Tutor" />
    <SidebarLayout>
        <main aria-labelledby="tutor-form-title">
            <div class="flex flex-col items-center bg-white sm:justify-center">
                <Notification
                    bgColor="bg-green-500"
                    bgColorBar="bg-green-800"
                    textColor="text-black"
                    textLabel="Tutor registrat correctament"
                    v-if="notification"
                    @close="closeNotification"
                    aria-live="polite"
                />
                <div class="mt-20 w-auto overflow-hidden bg-secondary px-3 py-2 shadow-md sm:max-w-md rounded-3xl">
                    <div>
                        <h1 id="tutor-form-title" class="flex my-4 justify-center text-white font-semibold text-5xl">
                            Afegir Tutor
                        </h1>
                    </div>

                    <form @submit.prevent="submit" id="form" aria-labelledby="tutor-form-title">
                        <div class="my-2">
                            <InputLabel for="name" value="NOM" />
                            <TextInput
                                id="name"
                                class="mt-1 block w-full focus:outline-none focus:ring-2 focus:ring-mclaren"
                                v-model="form.name"
                                required
                                autofocus
                                :aria-describedby="form.errors.name ? 'name-error' : null"
                            />
                            <InputError class="mt-2" :message="form.errors.name" id="name-error" />
                        </div>
                        <div class="my-2">
                            <InputLabel for="surname" value="COGNOM" />
                            <TextInput
                                id="surname"
                                class="mt-1 block w-full focus:outline-none focus:ring-2 focus:ring-mclaren"
                                v-model="form.surname"
                                required
                                :aria-describedby="form.errors.surname ? 'surname-error' : null"
                            />
                            <InputError class="mt-2" :message="form.errors.surname" id="surname-error" />
                        </div>
                        <div class="my-2">
                            <InputLabel for="email" value="EMAIL" />
                            <TextInput
                                id="email"
                                type="email"
                                class="mt-1 block w-full focus:outline-none focus:ring-2 focus:ring-mclaren"
                                v-model="form.email"
                                required
                                :aria-describedby="form.errors.email ? 'email-error' : null"
                            />
                            <InputError class="mt-2" :message="form.errors.email" id="email-error" />
                        </div>
                        <div class="my-2">
                            <InputLabel for="phone" value="TELÈFON" />
                            <TextInput
                                id="phone"
                                class="mt-1 block w-full focus:outline-none focus:ring-2 focus:ring-mclaren"
                                v-model="form.phone"
                                required
                                :aria-describedby="form.errors.phone ? 'phone-error' : null"
                            />
                            <InputError class="mt-2" :message="form.errors.phone" id="phone-error" />
                        </div>
                        <div class="my-2">
                            <InputLabel for="type" value="TIPUS" />
                            <select
                                id="type"
                                class="mt-1 block w-full rounded-md focus:border-mclaren focus:ring-2 focus:ring-mclaren"
                                v-model="form.for"
                                required
                                :aria-describedby="form.errors.for ? 'type-error' : null"
                            >
                                <option value="participant">Participant</option>
                                <option value="monitor">Monitor</option>
                            </select>
                            <InputError class="mt-2" :message="form.errors.for" id="type-error" />
                        </div>
                    </form>
                </div>
                <div class="my-4">
                    <PrimaryButton
                        type="submit"
                        class="ms-4 font-light focus:outline-none focus:ring-2 focus:ring-mclaren"
                        form="form"
                    >
                        Afegir Tutor
                    </PrimaryButton>
                </div>
            </div>
        </main>
    </SidebarLayout>
</template>
