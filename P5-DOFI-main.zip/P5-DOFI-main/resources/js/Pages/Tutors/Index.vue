<script setup>
import { Head } from '@inertiajs/vue3';
import SidebarLayout from '@/Layouts/SidebarLayout.vue';
import axios from 'axios';
import { ref, onMounted, computed, nextTick } from 'vue';
import LoadingAnimation from '@/Components/LoadingAnimation.vue';
import SearchBar from '@/Components/SearchBar.vue';

const tutors = ref([]);
const checkedTutors = ref([]);
const showInfoModal = ref(false);
const showEditModal = ref(false);
const selectedTutor = ref(null);
const editableTutor = ref(null);
const tutorsLoaded = ref(false);
const infoModal = ref(null);
const editModal = ref(null);
const input = ref('');

// Toggle all checkboxes
const toggleCheckboxAll = () => {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    const newState = checkedTutors.value.length !== tutors.value.length;
    checkedTutors.value = newState
        ? [...Array(tutors.value.length).keys()]
        : [];
    checkboxes.forEach((checkbox) => (checkbox.checked = newState));
};

// Toggle tutor selected
const toggleTutorSelection = (index) => {
    const position = checkedTutors.value.indexOf(index);
    if (position === -1) checkedTutors.value.push(index);
    else checkedTutors.value.splice(position, 1);
};

// Delete all checked
const deleteToggleCheckboxAll = () => {
    const selectedTutorIds = checkedTutors.value.map(
        (index) => tutors.value[index].id,
    );
    if (selectedTutorIds.length === 0) {
        console.log('No tutors selected');
        return;
    }
    axios
        .delete('/tutor/delete/massive', { data: { ids: selectedTutorIds } })
        .then(() => {
            checkedTutors.value = [];
            listTutors();
        })
        .catch((error) => console.error('Error deleting tutors:', error));
};

// Get all tutors
const listTutors = () => {
    tutorsLoaded.value = false;
    axios
        .get('/api/tutor')
        .then((response) => {
            tutors.value = response.data;
            tutorsLoaded.value = true;
        })
        .catch((error) => console.log(error));
};

// Open info modal
const openInfoModal = (tutor) => {
    selectedTutor.value = tutor;
    showInfoModal.value = true;
    nextTick(() => infoModal.value?.focus());
};

// Open edit modal
const openEditModal = (tutor) => {
    selectedTutor.value = tutor;
    editableTutor.value = JSON.parse(JSON.stringify(tutor));
    showEditModal.value = true;
    nextTick(() => editModal.value?.focus());
};

// Close info modal
const closeInfoModal = () => {
    showInfoModal.value = false;
    selectedTutor.value = null;
};

// Close edit modal
const closeEditModal = () => {
    showEditModal.value = false;
    selectedTutor.value = null;
};

// Submit tutor edit form
const saveTutorChanges = () => {
    axios
        .patch('/tutor/update', {
            tutor_id: editableTutor.value.id,
            ...editableTutor.value,
        })
        .then(() => {
            listTutors();
            closeEditModal();
        })
        .catch((error) => console.error('Error', error));
};

// Delete tutor
const deleteTutor = (tutor) => {
    axios
        .delete('/tutor/delete', { data: { id: tutor.id } })
        .then(() => listTutors())
        .catch((error) => console.error('Error:', error));
};

// Count all selected
const selectedTutorsCount = computed(() => checkedTutors.value.length);

// Single select tutor
const singleSelectedTutor = computed(() => {
    return checkedTutors.value.length === 1
        ? tutors.value[checkedTutors.value[0]]
        : null;
});

// Edit selected tutor
const editSelectedTutor = () => {
    if (singleSelectedTutor.value) openEditModal(singleSelectedTutor.value);
};

// Delete selected tutor
const deleteSelectedTutor = () => {
    if (singleSelectedTutor.value) deleteTutor(singleSelectedTutor.value);
};

// Search on tutor object
const searchBarTutor = () => {
    return tutors.value.filter((tutor) =>
        tutor.name.toLowerCase().includes(input.value.toLowerCase()),
    );
};

onMounted(listTutors);
</script>

<template>
    <Head title="Llista de tutors" />
    <SidebarLayout>
        <div
            class="mx-auto mt-14 flex h-[720px] w-5/6 flex-col rounded-md bg-secondary p-6 md:h-[630px]"
            aria-labelledby="tutors-list-title"
        >
            <h1
                id="tutors-list-title"
                class="sticky top-0 z-10 flex w-full items-center justify-center bg-secondary pb-3 pt-5 text-center text-3xl font-light text-white"
            >
                LLISTA DE TUTORS
            </h1>
            <div
                class="sticky top-0 z-10 mb-4 items-center justify-center bg-secondary pb-3 pt-5 text-white md:flex"
            >
                <div class="flex flex-col items-center min-[1500px]:flex-row">
                    <button
                        @click="toggleCheckboxAll"
                        class="my-3 h-10 w-24 rounded-md bg-mclaren text-white hover:bg-orange-600 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        aria-label="Marcar o desmarcar tots els tutors"
                    >
                        {{
                            checkedTutors.length === tutors.length
                                ? 'Desmarcar'
                                : 'Tots'
                        }}
                    </button>
                    <SearchBar
                        class="w-auto rounded-md text-black md:mb-0 md:mt-0"
                        type="text"
                        placeholder="Buscar tutors..."
                        v-model="input"
                        aria-label="Cercar tutors"
                    />
                    <div
                        class="my-3 flex flex-row items-center justify-center space-x-2 min-[1500px]:ml-2"
                        aria-live="polite"
                    >
                        <button
                            v-if="selectedTutorsCount === 1"
                            @click="editSelectedTutor"
                            class="h-10 w-24 rounded-md bg-mclaren text-white focus:outline-none focus:ring-2 focus:ring-mclaren"
                        >
                            Editar
                        </button>
                        <button
                            v-if="selectedTutorsCount === 1"
                            @click="deleteSelectedTutor"
                            class="h-10 w-24 rounded-md bg-red-600 text-white focus:outline-none focus:ring-2 focus:ring-red-600"
                        >
                            Eliminar
                        </button>
                        <button
                            v-if="selectedTutorsCount > 1"
                            @click="deleteToggleCheckboxAll"
                            class="flex h-10 w-auto items-center rounded-md bg-red-600 px-4 text-white focus:outline-none focus:ring-2 focus:ring-red-600"
                            aria-label="Eliminar tutors seleccionats"
                        >
                            <span>Eliminar ({{ selectedTutorsCount }})</span>
                        </button>
                        <button
                            v-if="selectedTutorsCount === 0"
                            disabled
                            class="h-10 w-24 rounded-md bg-gray-400 text-white"
                            aria-disabled="true"
                        >
                            Editar
                        </button>
                        <button
                            v-if="selectedTutorsCount === 0"
                            disabled
                            class="h-10 w-24 rounded-md bg-gray-400 text-white"
                            aria-disabled="true"
                        >
                            Eliminar
                        </button>
                    </div>
                </div>
            </div>
            <LoadingAnimation
                v-if="!tutorsLoaded"
                aria-label="Carregant llista de tutors"
            />
            <div
                class="w-full overflow-y-auto overflow-x-hidden"
                v-if="tutorsLoaded"
                role="list"
                aria-label="Llista de tutors"
            >
                <div
                    v-for="(tutor, index) in searchBarTutor()"
                    :key="tutor.id"
                    role="listitem"
                    class="mb-2 grid w-full grid-cols-3 items-center gap-4 rounded-md bg-white p-2 sm:grid-cols-4 xl:grid-cols-6"
                >
                    <div class="flex items-center justify-center">
                        <input
                            type="checkbox"
                            :id="'tutor-' + index"
                            :checked="checkedTutors.includes(index)"
                            @change="toggleTutorSelection(index)"
                            class="h-5 w-5 rounded text-mclaren focus:ring-2 focus:ring-mclaren focus:ring-offset-0"
                            :aria-label="`Seleccionar ${tutor.name}`"
                        />
                    </div>
                    <p class="text-left font-semibold capitalize">
                        {{ tutor.name }}
                    </p>
                    <p
                        class="col-span-2 hidden text-left font-semibold xl:flex"
                    >
                        {{ tutor.email }}
                    </p>
                    <p
                        class="hidden text-right font-semibold capitalize sm:flex"
                    >
                        {{ tutor.for }}
                    </p>
                    <div class="col-span-1 flex justify-end space-x-2">
                        <button
                            @click="openInfoModal(tutor)"
                            @keydown.enter="openInfoModal(tutor)"
                            class="mr-2 mt-1 size-8 cursor-pointer hover:opacity-80 focus:outline-none focus:ring-2 focus:ring-mclaren"
                            :aria-label="`Veure informació de ${tutor.name}`"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="3"
                                class="stroke-mclaren"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M12 4.5v15m7.5-7.5h-15"
                                />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Info Modal -->
        <div
            v-if="showInfoModal"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
            role="dialog"
            aria-modal="true"
            aria-labelledby="info-modal-title"
        >
            <div
                class="max-h-[80vh] w-full max-w-md overflow-auto rounded-lg bg-white p-8"
                tabindex="-1"
                ref="infoModal"
            >
                <div class="mb-6 flex items-center justify-between">
                    <h2
                        id="info-modal-title"
                        class="text-xl font-bold text-gray-800"
                    >
                        Informació adicional
                    </h2>
                    <button
                        @click="closeInfoModal"
                        @keydown.enter="closeInfoModal"
                        class="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                        aria-label="Tancar modal d'informació"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-6 w-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>
                <div v-if="selectedTutor" class="space-y-4">
                    <div class="flex space-x-20">
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">NOM</p>
                            <p class="font-semibold">
                                {{ selectedTutor.name }}
                            </p>
                        </div>
                        <div class="border-b pb-2">
                            <p class="text-sm text-gray-500">COGNOM</p>
                            <p class="font-semibold">
                                {{ selectedTutor.surname }}
                            </p>
                        </div>
                    </div>
                    <div class="border-b pb-2 xl:hidden">
                        <p class="text-sm text-gray-500">EMAIL</p>
                        <p class="font-semibold">{{ selectedTutor.email }}</p>
                    </div>
                    <div class="border-b pb-2 sm:hidden">
                        <p class="text-sm text-gray-500">TUTOR DE</p>
                        <p class="font-semibold">{{ selectedTutor.for }}</p>
                    </div>
                    <div class="border-b pb-2">
                        <p class="text-sm text-gray-500">TELÈFON</p>
                        <p class="font-semibold">{{ selectedTutor.phone }}</p>
                    </div>
                </div>
                <div class="mt-8 flex justify-end">
                    <button
                        @click="closeInfoModal"
                        class="rounded-md bg-mclaren px-4 py-2 text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-mclaren"
                        aria-label="Tancar modal d'informació"
                    >
                        Tancar
                    </button>
                </div>
            </div>
        </div>

        <!-- Edit Modal -->
        <div
            v-if="showEditModal"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
            role="dialog"
            aria-modal="true"
            aria-labelledby="edit-modal-title"
        >
            <div
                class="max-h-[80vh] w-full max-w-4xl overflow-auto rounded-lg bg-white p-8"
                tabindex="-1"
                ref="editModal"
            >
                <div class="mb-6 flex items-center justify-between">
                    <h2
                        id="edit-modal-title"
                        class="text-xl font-bold text-gray-800"
                    >
                        Editar tutor
                    </h2>
                    <button
                        @click="closeEditModal"
                        @keydown.enter="closeEditModal"
                        class="text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
                        aria-label="Tancar modal d'edició"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="h-6 w-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>
                <div v-if="editableTutor" class="space-y-4">
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="name"
                                >NOM</label
                            >
                            <input
                                type="text"
                                v-model="editableTutor.name"
                                class="w-full rounded-md border p-2 focus:outline-none focus:ring-2 focus:ring-mclaren"
                                id="name"
                                :aria-describedby="
                                    editableTutor.name.length < 3
                                        ? 'name-error'
                                        : null
                                "
                            />
                            <span
                                v-if="editableTutor.name.length < 3"
                                id="name-error"
                                class="text-red-500"
                                >El nom ha de tenir almenys 3 caràcters</span
                            >
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="surname"
                                >COGNOM</label
                            >
                            <input
                                type="text"
                                v-model="editableTutor.surname"
                                class="w-full rounded-md border p-2 focus:outline-none focus:ring-2 focus:ring-mclaren"
                                id="surname"
                                :aria-describedby="
                                    editableTutor.surname.length < 3
                                        ? 'surname-error'
                                        : null
                                "
                            />
                            <span
                                v-if="editableTutor.surname.length < 3"
                                id="surname-error"
                                class="text-red-500"
                                >El cognom ha de tenir almenys 3 caràcters</span
                            >
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="email"
                                >EMAIL</label
                            >
                            <input
                                type="email"
                                v-model="editableTutor.email"
                                class="w-full rounded-md border p-2 focus:outline-none focus:ring-2 focus:ring-mclaren"
                                id="email"
                            />
                        </div>
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="phone"
                                >TELÈFON</label
                            >
                            <input
                                type="text"
                                v-model="editableTutor.phone"
                                class="w-full rounded-md border p-2 focus:outline-none focus:ring-2 focus:ring-mclaren"
                                id="phone"
                            />
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="border-b pb-2">
                            <label class="text-sm text-gray-500" for="for"
                                >RELACIÓ</label
                            >
                            <select
                                v-model="editableTutor.for"
                                class="w-full rounded-md border p-2 focus:outline-none focus:ring-2 focus:ring-mclaren"
                                id="for"
                                aria-label="Tutor de..."
                            >
                                <option value="participant">Participant</option>
                                <option value="monitor">Monitor</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mt-8 flex justify-end space-x-4">
                    <button
                        @click="closeEditModal"
                        class="rounded-md bg-gray-300 px-4 py-2 text-gray-800 hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300"
                    >
                        Cancel·lar
                    </button>
                    <button
                        @click="saveTutorChanges"
                        class="rounded-md bg-mclaren px-4 py-2 text-white hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-mclaren"
                    >
                        Editar
                    </button>
                </div>
            </div>
        </div>
    </SidebarLayout>
</template>
