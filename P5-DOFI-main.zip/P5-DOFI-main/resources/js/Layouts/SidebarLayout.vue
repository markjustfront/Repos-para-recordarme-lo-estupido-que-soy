<script setup>
import { ref } from 'vue';
import { Link } from '@inertiajs/vue3';
import SidebarButton from '@/Components/SidebarButton.vue';

const isSidebarOpen = ref(false);

// Toggle sidebar
const toggleSidebar = () => {
    isSidebarOpen.value = !isSidebarOpen.value;
};

//Close sidebar function
const closeSidebar = () => {
    isSidebarOpen.value = false;
};
</script>

<template>
    <div class="relative flex h-screen">
        <!-- Overlay to close the sidebar if it is clicked outside -->
        <div
            v-if="isSidebarOpen"
            @click="closeSidebar"
            class="fixed inset-0 z-40 bg-black bg-opacity-50 md:hidden"
        ></div>

        <!-- Sidebar -->
        <aside
            :class="[
                'fixed z-50 flex h-screen w-64 flex-col bg-secondary transition-all duration-300 md:fixed md:bg-primary md:bg-opacity-20',
                isSidebarOpen
                    ? 'translate-x-0'
                    : '-translate-x-full md:translate-x-0',
            ]"
        >
            <Link :href="route('dashboard')" class="h-28 bg-primary">
                <img
                    src="/img/dofi_header.png"
                    alt="Logo"
                    class="max-h-28 min-h-28 min-w-64 max-w-64"
                />
            </Link>

            <!-- Sidebar -->
            <nav class="mt-4 flex flex-col text-lg">
                <SidebarButton
                    content="HOME"
                    alt="Home"
                    link="dashboard"
                    :inside="true"
                ></SidebarButton>
                <SidebarButton
                    content="ACTIVITATS"
                    alt="activitats"
                    link="activity.index"
                    :inside="true"
                ></SidebarButton>
                <SidebarButton
                    content="PARTICIPANTS"
                    alt="participants"
                    link="participant.index"
                    :inside="true"
                ></SidebarButton>
                <SidebarButton
                    content="TUTORS"
                    alt="tutors"
                    link="tutor.index"
                    :inside="true"
                ></SidebarButton>
                <SidebarButton
                    content="MONITORS"
                    alt="monitors"
                    link="monitor.index"
                    :inside="true"
                ></SidebarButton>
                <!--<SidebarButton
                    content="REUNIONS"
                    alt="reunions"
                    link="meeting.index"
                    :inside="true"
                ></SidebarButton>-->
                <SidebarButton
                    content="TRESORERIA"
                    alt="tresoreria"
                    link="defaulter.index"
                    :inside="true"
                ></SidebarButton>
                <!--<SidebarButton
                    content="INCIDÈNCIES"
                    alt="incidències"
                    link="incidence.index"
                    :inside="true"
                ></SidebarButton>-->
            </nav>
            <div class="flex flex-row justify-end">
                <a
                    href="/logout"
                    aria-label="logout"
                    class="me-4 min-h-11 w-1/2 cursor-pointer rounded-md bg-primary p-2 text-center text-2xl font-light text-white shadow-md hover:bg-white hover:text-primary"
                >
                    SURT
                </a>
            </div>
        </aside>
        <main class="relative mr-0 h-fit min-h-screen w-full bg-white md:ml-64">
            <slot></slot>
        </main>
        <!-- Button for small screens -->
        <button
            v-if="!isSidebarOpen"
            @click="toggleSidebar"
            aria-label="Open sidebar on mobile"
            class="fixed right-9 top-5 z-50 rounded-md bg-mclaren p-3 text-black opacity-75 shadow-lg transition-all duration-200 hover:bg-opacity-80 md:hidden"
        >
            <i class="fas fa-bars text-2xl"></i>
        </button>
    </div>
</template>

<style lang="scss">
@import '../../../node_modules/@fortawesome/fontawesome-free/css/all.css';
</style>
