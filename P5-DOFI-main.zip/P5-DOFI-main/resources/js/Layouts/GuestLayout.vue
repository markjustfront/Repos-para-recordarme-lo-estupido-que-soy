<script setup>

</script>

<template>
    <div
        class="flex min-h-screen flex-col items-center bg-white pt-6 sm:justify-center sm:pt-0"
    >

        <div
            class="mt-6 w-auto overflow-hidden bg-secondary px-3 py-4 shadow-md sm:max-w-md rounded-3xl"
        >
            <slot />
        </div>
    </div>
</template>
