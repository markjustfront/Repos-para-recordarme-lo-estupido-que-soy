/**
 * @author: Mateo
 *
 */
import { expect, test } from '@playwright/test';

// This test inputs text in the searchbar and checks if the searchbar has that text
test.describe('tutor search bar', () => {
    test('should type in the search input on /tutors page', async ({
        page,
    }) => {
        await page.goto('http://localhost/login');

        await page.fill('#name', 'admin');
        await page.fill('#password', 'E1D0F1@2025*');

        await page.click('#submitlogin');

        await page.waitForURL('**/dashboard');

        await page.goto('http://localhost/tutors');
        const input = await page.locator('#searchinput');
        await input.fill('test input');
        await expect(input).toHaveValue('test input');
    });
});
