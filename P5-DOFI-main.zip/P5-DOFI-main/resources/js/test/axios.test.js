/**
 * @author: Mateo
 *
 */
import axios from 'axios';
import { expect, test } from 'vitest';

// This test gets a no from an api and checks if it gets the no from the api ;)
test('result is no', async () => {
    const response = await axios.get('https://yesno.wtf/api?force=no');
    expect(response.data.answer).toBe('no');
});
