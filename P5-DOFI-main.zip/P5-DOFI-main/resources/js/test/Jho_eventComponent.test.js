/**
 * @author: Jho
 *@vitest-environment jsdom
 *
 */
import SearchBar from '@/Components/SearchBar.vue';
import { mount } from '@vue/test-utils';
import { describe, expect, it } from 'vitest';

// This test checks if the component searchbar emits the event searching
describe('SearchBar.vue', () => {
    it('emits "searching" event on input', async () => {
        const wrapper = mount(SearchBar, {
            props: {
                placeholder: 'test',
            },
        });

        const input = wrapper.get('input');

        await input.setValue('test search');

        expect(wrapper.emitted()).toHaveProperty('searching');

        expect(wrapper.emitted('searching')?.length).toBe(1);
    });
});
