/*
 * @author: Jho
 */
import axios from 'axios';
import { expect, test } from 'vitest';

// This test gets a json from an api and checks if the title matches expected
test('title = delectus', async () => {
    const response = await axios.get(
        'https://jsonplaceholder.typicode.com/todos/1',
    );
    expect(response.data.title).toBe('delectus aut autem');
});
