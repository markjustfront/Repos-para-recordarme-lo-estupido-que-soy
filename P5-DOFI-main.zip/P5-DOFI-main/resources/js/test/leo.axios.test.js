/**
 * @author: Leo
 *
 */
import axios from 'axios';
import { expect, test } from 'vitest';

// This api gets a pokemon capture rate and check to match expected
test('result is 45', async () => {
    const response = await axios.get(
        'https://pokeapi.co/api/v2/pokemon-species/aegislash',
    );
    expect(response.data.capture_rate).toBe(45);
});
