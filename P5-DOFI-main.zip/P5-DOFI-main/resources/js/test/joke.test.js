/**
 * @author: markjustfront
 */
import axios from 'axios';
import { expect, test } from 'vitest';

// This function checks if the joke api returns a setup and a punchline
test('returns a valid joke', async () => {
    const response = await axios.get(
        'https://official-joke-api.appspot.com/random_joke',
    );
    expect(response.data).toHaveProperty('setup');
    expect(response.data).toHaveProperty('punchline');
    expect(typeof response.data.setup).toBe('string');
    expect(typeof response.data.punchline).toBe('string');
    expect(response.data.setup).not.toBe('');
    expect(response.data.punchline).not.toBe('');
});
