<script setup>
import { Link } from '@inertiajs/vue3';
const props = defineProps({
    content: {
        type: String,
        required: true,
    },
    inside: {
        type: Boolean,
        required: true,
    },
    link: {
        type: String,
        required: true,
    },
    alt: {
        type: String,
        required: true,
    },
});
</script>

<template>
    <Link
        :href="route(props.link)"
        v-if="props.inside"
        class="mx-auto mb-3 min-h-11 w-5/6 min-w-52 max-w-52 rounded-md bg-primary p-2 text-center text-2xl font-light tracking-widest text-white shadow-md transition-colors duration-300 ease-in-out hover:bg-white hover:text-primary focus:bg-white focus:text-primary"
        :alt="props.alt"
    >
        {{ props.content }}
    </Link>
    <a
        :href="props.link"
        v-if="!props.inside"
        class="mx-auto mb-3 min-h-11 w-5/6 min-w-52 max-w-52 rounded-md bg-primary p-2 text-center text-2xl font-light tracking-widest text-white shadow-md transition-colors duration-300 ease-in-out hover:bg-white hover:text-primary focus:bg-white focus:text-primary"
        :aria-label="props.alt"
    >
        {{ props.content }}
    </a>
</template>

<style scoped lang="scss"></style>
