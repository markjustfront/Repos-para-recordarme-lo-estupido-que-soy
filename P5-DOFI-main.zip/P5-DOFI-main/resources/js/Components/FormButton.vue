<script setup></script>
<template>
    <button
        class="mb-2 me-2 rounded-lg bg-mclaren px-5 py-3 text-sm font-medium text-white transition-colors duration-300 ease-in-out hover:bg-orange-600 focus:outline-none focus:ring-4 focus:ring-mclaren"
    >
        <slot></slot>
    </button>
</template>
