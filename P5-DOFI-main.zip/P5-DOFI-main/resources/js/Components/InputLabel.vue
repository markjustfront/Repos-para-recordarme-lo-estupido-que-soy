<script setup>
defineProps({
    value: {
        type: String,
    },
});
</script>

<template>
    <label class="flex justify-center text-2xl font-sans text-white">
        <span v-if="value">{{ value }}</span>
        <span v-else><slot /></span>
    </label>
</template>
