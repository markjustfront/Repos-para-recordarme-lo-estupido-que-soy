<script setup>
import { ref, defineProps, defineEmits } from 'vue';

const emit = defineEmits(['close']);


const closeNotification = () => {
    emit('close');
};
const props = defineProps({
    bgColor: {
        type: String,
        required: true,
    },
    bgColorBar: {
        type: String,
        required: true,
    },
    textColor: {
        type: String,
        required: true,
    },
    textLabel: {
        type: String,
        required: true,
    },
});



</script>           
<template>
    <div class="absolute top-2 mx-auto rounded-lg w-auto min-h-16 opacity-70" v-bind:class="props.bgColor">
        <div class="rounded-t-lg Progressive_Bar h-1.5" v-bind:class="props.bgColorBar"></div>
        <div>
            <label class="flex">
                <span class="text-lg font-medium px-12 mt-5"
                 v-bind:class="props.textColor">{{ props.textLabel }}</span>
            
                <i class="fas fa-close m-2 cursor-pointer text-xl text-black hover:text-white transition-colors duration-300 ease-in-out" @click="closeNotification"></i>
            </label>
        </div>
        </div>
</template>
<style scoped>
.Progressive_Bar {
    width: 0%;
    animation: progress 5s linear forwards;
}

@keyframes progress {
    0% {
        width: 0%;
    }
    100% {
        width: 100%;
    }
}
</style>
<style lang="scss">
@import '../../../node_modules/@fortawesome/fontawesome-free/css/all.css';
</style>