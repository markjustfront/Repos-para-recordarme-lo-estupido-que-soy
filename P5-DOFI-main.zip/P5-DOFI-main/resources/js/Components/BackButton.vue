<script setup>
import { Link } from '@inertiajs/vue3';

const props = defineProps({
    url: {
        required: true,
        type: String,
    },
});
</script>

<template>
    <Link
        :href="props.url"
        class="absolute left-5 top-5 w-2/5 rounded-md bg-secondary p-2 font-light text-white transition-all duration-200 ease-in-out hover:bg-primary hover:shadow-md focus:bg-mclaren focus:ring-mclaren md:w-1/12"
        >Tornar enrere</Link
    >
</template>
