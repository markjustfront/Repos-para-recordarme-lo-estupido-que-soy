<script setup>
const emit = defineEmits(['searching']);
const props = defineProps({
    placeholder: {
        required: true,
        type: String,
    },
});
</script>

<template>
    <input
        aria-label="buscador"
        class="ml-0 w-[300px] rounded-md text-black focus:border-mclaren focus:ring-mclaren md:ml-2 md:w-[420px] min-[1080px]:w-[670px]"
        type="text"
        id="searchinput"
        :placeholder="props.placeholder"
        v-model="input"
        @input="emit('searching')"
    />
</template>

<style scoped></style>
