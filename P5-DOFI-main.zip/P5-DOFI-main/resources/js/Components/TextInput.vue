<script setup>
import { onMounted, ref } from 'vue';

const model = defineModel({
    type: String,
    required: true,
});

const input = ref(null);

onMounted(() => {
    if (input.value.hasAttribute('autofocus')) {
        input.value.focus();
    }
});

defineExpose({ focus: () => input.value.focus() });
</script>

<template>
    <input
        class="rounded-lg text-center text-xl border-primary shadow-sm focus:border-mclaren py-3 focus:ring-mclaren"
        v-model="model"
        ref="input"
    />
</template>
