{{-- @extends('errors::minimal')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('Not Found')) --}}

{{-- @extends('errors::minimal')

@section('title', __('Not Found'))
@section('code', '404')
@section('message', __('Not Found')) --}}

{{-- @section('message') --}}

{{-- @endsection --}}

<!DOCTYPE html>
<html lang="ca">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>404</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:700,900" rel="stylesheet">
    <style type="text/css">
        body {
            background-color: #dbedec;
            /* background-color: #fff; */
        }

        .notfound-img {
            display: block;
            text-align: center;
            padding-top: 2em;
            padding-bottom: 2em
        }

        .notfound-text {
            font-family: 'Montserrat', sans-serif;
            font-size: 22px;
            font-weight: 700;
            text-transform: uppercase;
            color: #0a4249;
            margin-top: 10px;
            margin-bottom: 15px;
            left: 50%;
            top: 50%;
            text-align: center
        }

        .btn {
            /* font-family: 'Montserrat', sans-serif; */
            /* font-weight: 700; */
            /* text-decoration: none; */
            /* text-transform: uppercase; */
            /* font-size: 18px; */
            display: inline;
            background-color: transparent;
            border: 2px solid transparent;
            padding: 13px 25px;
            border-radius: 40px;
            margin: 7px;
            -webkit-transition: 0.2s all;
            transition: 0.2s all;
        }

        .btn:hover {
            cursor: pointer;
        }

        .btn-block {
            margin-top: 40px;
            text-align: center;
        }

        .home-btn:hover,
        .contact-btn:hover {
            opacity: 0.9;
        }

        .home-btn {
            color: #dbedec;
            background: #0a4249;
        }

        /* .contact-btn {
            border: 2px solid rgba(255, 255, 255, 0.9);
            color: #286067;
            background: #0a4249;
        } */

        @media only screen and (max-width: 480px) {
            body {
                height: 146px;
            }

            .notfoudn-text h2 {
                font-size: 16px;
            }

            .btn {
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <div class="notfound-img">
        <img src="/img/NBG-DOFI.png" alt="404" />
    </div>
    <div class="notfound-text">
        La pàgina que estàs buscant no existeix </div>
    <div class="btn-block">
        <button alt="Enrere" type="button" onclick="window.location='/'" class="btn home-btn">
            <i class="fas fa-house-user" style="color: #dbedec; font-size: 3em;"></i>
        </button>
    </div>
</body>

</html>
