<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;

class TutorController extends Controller
{
    public function tutorForm()
    {
       return Inertia::render('Tutors/Create');
    }

    public function tutorsList()
    {
       return Inertia::render('Tutors/Index');
    }

}
