<?php

namespace App\Http\Controllers\CRUD;


use App\Http\Controllers\Controller;
use App\Models\Documentation;
use App\Models\Participant;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Http\Requests\DocumentationCreateRequest;
use App\Http\Requests\DocumentationUpdateRequest;


class DocumentationCrudController extends Controller
{
    /*
     * This function will render a view with all documentations as props
     */
    public function index() :Response
    {
        $documentations = Documentation::all();
        return Inertia::render("Dashboard", [
            "documentations" => $documentations,
        ]);
    }
    /*
     * This function will return a collection of all the documentations
     */
    public function read() :Collection
    {
        return Documentation::all();
    }

    /*
     * This function will delete a selected documentations
     */
    public function delete(Request $request) :string {
        $deletableDocumentation = $request->get('id');
        Documentation::destroy($deletableDocumentation);
        return "Documentation deleted";
    }

    /*
     * This function will create a documentation
     */
    public function create(DocumentationCreateRequest $request) :string {
        $validated = $request->validated();

        Documentation::create([
            'for' => $validated['for'],
            'type' => $validated['type'],
            'route' => $validated['route'],
            'participant_id' => $validated['participant_id'],
            'monitor_id' => $validated['monitor_id'],
        ]);

        return "Documentation created";
    }
    /*
     * This function will update a selected documentation
     */

    public function update(DocumentationUpdateRequest $request) :string
    {
        $validated = $request->validated();
        $updatableDocumentation = Documentation::find($validated['documentation_id']);

        $updatableDocumentation::update([
        'for' => $validated['for'],
        'type' => $validated['type'],
        'route' => $validated['route'],
        'participant_id' => $validated['participant_id'],
        'monitor_id' => $validated['monitor_id'],
        ]);

        return "Documentation updated";
    }
}
