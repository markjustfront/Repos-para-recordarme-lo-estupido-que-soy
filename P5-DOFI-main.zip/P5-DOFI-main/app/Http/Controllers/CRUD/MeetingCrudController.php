<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Collection;
use Inertia\Inertia;
use App\Models\Meeting;
use App\Http\Requests\MeetingCreateRequest;
use App\Http\Requests\MeetingUpdateRequest;
use Inertia\Response;


class MeetingCrudController extends Controller
{
    //Resources of the MeetingController
    public function index() : Response
    {
        $meeting = Meeting::all();
        return Inertia::render('Meeting/Index', [
            'meeting' => $meeting,
        ]);
    }

    // Create a new meeting
    public function create(MeetingCreateRequest $request): string
    {
        $validated = $request->validated();

        Meeting::create([
        'type' => $validated['type'],
        'route' => $validated['route'],
        'assistants' => $validated['assistants'],
        'observations' => $validated['observations'],
        'date' => $validated['date'],
        'place' => $validated['place'],
        ]);

        return "Reunio creada";
    }

    // Read a meeting
    public function read($id) : Collection
    {
        return Meeting::all();
    }

    // Update a meeting
    public function update(MeetingUpdateRequest $request): string
    {
        $validated = $request->validated();
        $updateMeeting = Meeting::find($validated['meeting_id']);

        $updateMeeting::update([
        'type' => $validated['type'],
        'route' => $validated['route'],
        'assistants' => $validated['assistants'],
        'observations' => $validated['observations'],
        'date' => $validated['date'],
        'place' => $validated['place'],
        ]);

        return "Reunió actualizada";
    }

    // Delete a meeting
    public function delete($id): string
    {
        $meeting = Meeting::find($id);
        $meeting->delete();
        return "Reunió eliminada";
    }
}
