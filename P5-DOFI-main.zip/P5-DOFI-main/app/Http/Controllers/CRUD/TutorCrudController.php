<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Http\Requests\TutorCreateRequest;
use App\Http\Requests\TutorUpdateRequest;
use App\Models\Tutor;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;



class TutorCrudController extends Controller
{
    /*
     * This function will render a view with all tutors as props
     */
    public function index() : Collection
    {
        $tutors = Tutor::all();
        return $tutors;
    }


    /*
     * This function will return a collection of all the tutors
     */
    public function read() :Collection
    {
        return Tutor::all();
    }

    /*
     * This function will delete a selected tutor
     */
    public function delete(Request $request) :string {
        $deletableTutor = $request->get('id');
        Tutor::destroy($deletableTutor);
        return "Tutor deleted";
    }

    /*
     * This function will create a tutor
     */
    public function create(TutorCreateRequest $request) :RedirectResponse
    {
        $validated = $request->validated();

        Tutor::create([
            'name' => $validated['name'],
            'surname' => $validated['surname'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'for' => $validated['for'],
        ]);

        return redirect()->back();
    }
  
    /*
     * This function will update a selected tutor
     */
    public function update(TutorUpdateRequest $request) : string
    {   
        $validated = $request->validated();
        $updatableTutor = Tutor::findOrFail($validated['tutor_id']);


        $updatableTutor->update([
            'name' => $validated['name'],
            'surname' => $validated['surname'],
            'email' => $validated['email'],
            'phone' => $validated['phone'],
            'for' => $validated['for'],
        ]);

        return "Tutor updated";
    }

    /**
     * API endpoint to fetch tutors via Axios
     */
    public function tutors()
    {
        $tutors = Tutor::all(['id', 'name']); // Fetch only id and name for efficiency
        return $tutors;
    }

    // Function to delete massive tutors
    public function deleteAllCheckbox() :string {
        $deletableTutor = Tutor::whereIn('id', request('ids'));
        $deletableTutor->delete();
        return "Tutor deleted";
    }
}
