<?php

namespace App\Http\Controllers\CRUD;


use App\Http\Controllers\Controller;
use App\Models\Documentation;
use App\Models\BankData;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Http\Requests\BankDataCreateRequest;
use App\Http\Requests\BankDataUpdateRequest;


class BankDataCrudController extends Controller
{
    /*
     * This function will render a view with all bankData as props
     */
    public function index() :Response
    {
        $bankData = BankData::all();
        return Inertia::render("Dashboard", [
            "bankData" => $bankData,
        ]);
    }
    /*
     * This function will return a collection of all the bankData
     */
    public function read() :Collection
    {
        return BankData::all();
    }

    /*
     * This function will delete a selected bankData
     */
    public function delete(Request $request) :string {
        $deletableBankData = $request->get('id');
        BankData::destroy($deletableBankData);
        return "BankData deleted";
    }

    /*
     * This function will create a bankData
     */
    public function create(BankDataCreateRequest $request) :string {
        $validated = $request->validated();

        BankData::create([
            'for' => $validated['for'],
            'iban' => $validated['iban'],
            'name' => $validated['name'],
            'nass' => $validated['nass'],
            'participant_id' => $validated['participant_id'],
            'monitor_id' => $validated['monitor_id'],
        ]);

        return "BankData created";
    }
    /*
     * This function will update a selected bankData
     */

    public function update(BankDataUpdateRequest $request) :string
    {
        $validated = $request->validated();
        $updatableBankData = BankData::find($validated['bankData_id']);

        $updatableBankData::update([
            'for' => $validated['for'],
            'iban' => $validated['iban'],
            'name' => $validated['name'],
            'nass' => $validated['nass'],
            'participant_id' => $validated['participant_id'],
            'monitor_id' => $validated['monitor_id'],
        ]);

        return "BankData updated";
    }
}
