<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Models\Defaulter;
use App\Models\Participant;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Http\Requests\DefaulterCreateRequest;
use App\Http\Requests\DefaulterUpdateRequest;


class DefaulterCrudController extends Controller
{
    /*
     * This function will render a view with all defaulters as props
     */
    public function index() :Collection
    {
        return Defaulter::all();
    }

    /*
     * This function will return a collection of all the defaulters
     */
    public function read()
    {
        $id = Defaulter::all()->pluck('participant_id');
        return Participant::find($id);
    }


    /*
     * This function will delete a selected defaulter
     */
    public function delete(Request $request) :string {
        $deletableDefaulter = $request->get('id');
        Participant::destroy($deletableDefaulter);
        return "Defaulter deleted";
    }

    /*
    * This function will create a new participant
    */
    public function create(DefaulterCreateRequest $request) :string {
        $validated = $request->validated();

        Defaulter::create([
            'participant_id' => $validated['participant_id'],
        ]);

        return "Defaulter created";
    }

    /*
     * This function will update a selected defaulter
     */
    public function update(DefaulterUpdateRequest $request) :string
    {
        $validated = $request->validated();

        $updatableDefaulter = Defaulter::find($validated['defaulter_id']);

        $updatableDefaulter::update([
            'participant_id' => $validated['participant_id'],
        ]);

        return "Defaulter updated";
    }
}
