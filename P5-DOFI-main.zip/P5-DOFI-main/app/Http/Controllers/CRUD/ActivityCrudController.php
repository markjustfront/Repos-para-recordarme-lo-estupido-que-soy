<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Http\Requests\ActivityCreateRequest;
use App\Http\Requests\ActivityUpdateRequest;
use App\Models\Activity;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class ActivityCrudController extends Controller
{
    /*
     * This function will load a view with the props needed
     */
    public function index(): Collection
    {
        return Activity::all();
    }

    /*
     * This function will return a collection of each activity
     */
    public static function read($id): Activity
    {
        return Activity::find($id);
    }

    /*
     * This function will delete the selected activity
     */
    public function delete(Request $request): string
    {
        $deletableActivity = $request->get('id');
        Activity::destroy($deletableActivity);
        return "Activity deleted";
    }

    /*
     * This function will create a new activity
     */
    public function create(ActivityCreateRequest $request): string
    {
        $validated = $request->validated();

        Activity::create([
            'name' => $validated['name'],
            'start_time' => $validated['start_time'],
            'end_time' => $validated['end_time'],
            'place' => $validated['place'],
            'member_price' => $validated['member_price'],
            'nonmember_price' => $validated['nonmember_price'],
            'monitor_salary' => $validated['monitor_salary'],
            'participants_id' => $validated['participants_id'],
            'monitors_info' => $validated['monitors_info'],
            'collaborations' => $validated['collaborations'],
        ]);

        return "Activity created";
    }

    /*
     * This function will update the selected activity
     */
    public function update(ActivityUpdateRequest $request): string
    {
        $validated = $request->validated();

        $updatableActivity = Activity::find($validated['activity_id']);

        $updatableActivity::update([
            'name' => $validated['name'],
            'start_time' => $validated['start_time'],
            'end_time' => $validated['end_time'],
            'place' => $validated['place'],
            'member_price' => $validated['member_price'],
            'nonmember_price' => $validated['nonmember_price'],
            'monitor_salary' => $validated['monitor_salary'],
            'participants_id' => $validated['participants_id'],
            'monitors_info' => $validated['monitors_info'],
            'collaborations' => $validated['collaborations'],
        ]);


        return "Activity updated";
    }

    // Function to delete massive tutors
    public function deleteAllCheckbox() :string {
        $deletableActivities = Activity::whereIn('id', request('ids'));
        $deletableActivities->delete();
        return "Activities deleted";
    }
}
