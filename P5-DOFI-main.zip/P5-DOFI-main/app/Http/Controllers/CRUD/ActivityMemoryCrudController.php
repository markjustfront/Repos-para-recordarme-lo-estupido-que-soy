<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Http\Requests\ActivityMemoryCreateRequest;
use App\Http\Requests\ActivityMemoryUpdateRequest;
use App\Models\ActivityMemory;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class ActivityMemoryCrudController extends Controller
{
    /*
     * This function will load a view with the props needed
     */
    public function index(): Response
    {
        $activityMemory = ActivityMemory::all();
        return Inertia::render("Dashboard", [
            "activityMemory" => $activityMemory,
        ]);
    }

    /*
     * This function will return a collection of each memory
     */
    public function read(): Collection
    {
        return ActivityMemory::all();
    }

    /*
     * This function will delete the selected memory
     */
    public function delete(Request $request): string
    {
        $deletableActivityMemory = $request->get('id');
        ActivityMemory::destroy($deletableActivityMemory);
        return "Memory deleted";
    }

    /*
     * This function will create a new memory
     */
    public function create(ActivityMemoryCreateRequest $request): string
    {
        $validated = $request->validated();

        ActivityMemory::create([
            'route' => $validated['route'],
        ]);

        return "Memory created";
    }

    /*
     * This function will update the selected memory
     */
    public function update(ActivityMemoryUpdateRequest $request): string
    {
        $validated = $request->validated();

        $activityMemory = ActivityMemory::find($validated['activitymemory_id']);

        $activityMemory->route = $validated['route'];
        $activityMemory->save();

        return "Memory updated";
    }
}
