<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Http\Requests\ParticipantUpdateRequest;
use App\Models\Participant;
use App\Models\Defaulter;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Http\Requests\ParticipantCreateRequest;

class ParticipantCrudController extends Controller
{
    /*
     * This function will load a view with the props needed
     */
    public function index() : Collection
    {
        $participants = Participant::all();

        $change = false;
        $endDate = Carbon::parse(now());
        foreach ($participants as $participant) {
            if (!$participant->active) {
                $startDate = Carbon::parse($participant->last_activity);
                $diff = $startDate->diffInYears($endDate);
                if ($diff >= 2) {
                    $participant->delete();
                    $change = true;
                }
            }
        }
        if ($change) {
            $participants = Participant::all();
        }

        return $participants;
    }

    /*
     * This function will return a collection of each participant
     */
    public function read($id) :Collection
    {
        return Participant::find($id);
    }

    public function getParticipantsNotDefaulters() :Collection
    {
        $id = Defaulter::all()->pluck('participant_id');
        $notDefaulters = Participant::whereNotIn('id', $id)->get();
        return $notDefaulters;
    }

    /*
     * This function will delete the selected participant
     */
    public function delete(Request $request) :string {
        $deletableParticipant = $request->get('id');
        Participant::destroy($deletableParticipant);
        return "Participants deleted";
    }

    /*
     * This function will create a new participant
     */
    public function create(ParticipantCreateRequest $request) :string {
        $validated = $request->validated();
        Participant::create([
            'name' => $validated['name'],
            'surnames' => $validated['surnames'],
            'dni' => $validated['dni'],
            'birthday' => $validated['birthday'],
            'direction' => $validated['direction'],
            'entry_year' => $validated['entry_year'],
            'member' => $validated['member'],
            'active' => true,
            'cash' => $validated['cash'],
            'educational_sheet' => $validated['educational_sheet'],
            'relationship' => $validated['relationship'],
            'tutor_id' => $validated['tutor_id'],
        ]);

        return "Participants created";
    }

    /*
     * This function will update an existing participant
     */
    public function update(ParticipantUpdateRequest $request) :string
    {
        $validated = $request->validated();

        $updatableParticipant = Participant::find($validated['participant_id']);

        if (!$validated["active"] && $updatableParticipant->active) {
            $validated["last_activity"] = date("Y-m-d H:i:s", time());
        } else if ($validated["active"] && !$updatableParticipant->active) {
            $validated["last_activity"] = null;
        }

        if (!$validated["active"] && $updatableParticipant->active) {
            $validated["last_activity"] = date("Y-m-d H:i:s", time());
        } else if ($validated["active"] && !$updatableParticipant->active) {
            $validated["last_activity"] = null;
        }

        $updatableParticipant->update([
            'name' => $validated['name'],
            'surnames' => $validated['surnames'],
            'dni' => $validated['dni'],
            'birthday' => $validated['birthday'],
            'direction' => $validated['direction'],
            'entry_year' => $validated['entry_year'],
            'member' => $validated['member'],
            'active' => $validated['active'],
            'cash' => $validated['cash'],
            'educational_sheet' => $validated['educational_sheet'],
            'tutor_id' => $validated['tutor_id'],
        ]);

        return "Participants updated";
    }

    public function getParticipants()
    {
        return Participant::all();
    }

    // Function to delete multiple selected participants
    public function deleteAllCheckboxedParticipants() :string {
        $deletableParticipants = Participant::whereIn('id', request('ids'));
        $deletableParticipants->delete();
        return "Participants deleted";
    }
}
