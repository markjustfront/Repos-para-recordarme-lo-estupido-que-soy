<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Http\Requests\IncidencesCreateRequest;
use App\Http\Requests\IncidencesUpdateRequest;
use App\Models\Incidence;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;


class IncidencesCrudController extends Controller
{
    //Resources of the IncidencesController
    public function index(): Collection
    {
        return Incidence::all();
    }

    // Create a new incidence
    public function create(IncidencesCreateRequest $request) : RedirectResponse
    {
        $validated = $request->validated();

        Incidence::create([
            'type' => $validated['type'],
            'description' => $validated['description'],
            'actuation' => $validated['actuation'],
            'monitor_id' => $validated['monitor_id'],
            'participant_id' => $validated['participant_id'],
            'date' => $validated['date'],
            'time' => $validated['time'],
        ]);

        return to_route('dashboard');
    }

    // Read a incidence
    public function read($id): collection
    {
        return Incidence::find($id);
    }

    // Update a incidence
    public function update(IncidencesUpdateRequest $request): string
    {
        $validated = $request->validated();
        $updateMeeting = Incidence::find($validated['incidences_id']);

        $updateMeeting::update([
            'type' => $validated['type'],
            'description' => $validated['description'],
            'actuation' => $validated['actuation'],
            'monitor_id' => $validated['monitor_id'],
            'participant_id' => $validated['participant_id'],
        ]);

        return "Incidència actualitzada correctament";
    }

    // Delete a incidence
    public function delete(Request $request): string
    {
        $id = $request->get('id');
        $incidence = Incidence::find($id);
        $incidence->delete();

        return "Incidència eliminada correctament";
    }
}
