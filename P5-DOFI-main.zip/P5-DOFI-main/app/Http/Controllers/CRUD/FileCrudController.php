<?php

namespace App\Http\Controllers\CRUD;


use App\Http\Controllers\Controller;
use App\Models\File;
use App\Models\Participant;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Http\Requests\FileCreateRequest;
use App\Http\Requests\FileUpdateRequest;


class FileCrudController extends Controller
{
    /*
     * Makes a view for the Files
     */
    public function index() :Response
    {
        $File = Files::all();
        return Inertia::render("Dashboard", [
            "File" => $File,
        ]);
    }
    /*
     * Collects the Files
     */
    public function read() :Collection
    {
        return Files::all();
    }

    /*
     * File Deletion
     */
    public function delete(Request $request) :string {
        $fileDelete = $request->get('id');
        Files::destroy($fileDelete);
        return "File deleted";
    }

    /*
     * File Creation
     */
    public function create(FileCreateRequest $request) :string {
        $validated = $request->validated();

        Files::create([
            'for' => $validated['for'],
            'type' => $validated['type'],
            'route' => $validated['route'],
            'participant_id' => $validated['participant_id'],
            'monitor_id' => $validated['monitor_id'],
        ]);

        return "File created";
    }
    /*
     * File Updation
     */

    public function update(FileUpdateRequest $request) :string
    {
        $validated = $request->validated();
        $fileUpdated = Files::find($validated['file_id']);

        $fileUpdated::update([
        'for' => $validated['for'],
        'type' => $validated['type'],
        'route' => $validated['route'],
        'participant_id' => $validated['participant_id'],
        'monitor_id' => $validated['monitor_id'],
        ]);

        return "File updated";
    }
}
