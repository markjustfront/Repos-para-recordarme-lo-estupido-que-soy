<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Http\Requests\MedicalDataCreateRequest;
use App\Http\Requests\MedicalDataUpdateRequest;
use App\Models\MedicalData;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Collection;
use Inertia\Inertia;
use Inertia\Response;

class MedicalDataCrudController extends Controller
{
    /*
     * This function will load all medical data from the selected user
     */
    public function index(Request $request) : Response
    {
        $medicalData = MedicalData::all()->where('participant_id', $request->get('participant_id'));
        return Inertia::render('Dashboard', [
            'medicalData' => $medicalData,
        ]);
    }

    /*
     * This function will create a new Medical Data for the user
     */
    public function create(MedicalDataCreateRequest $request) : string
    {
        $validated = $request->validated();

        MedicalData::create([
            'type' => $validated['type'],
            'description' => $validated['description'],
            'participant_id' => $validated['participant_id'],
        ]);

        return "Medical Data Created";
    }

    /*
     * This function will read all the medical data of a user
     */
    public function read(Request $request) : Collection
    {
        return MedicalData::all()->where('participant_id', $request->get('participant_id'));
    }

    /*
     * This function will update the given data
     */
    public function update(MedicalDataUpdateRequest $request) : string
    {
        $validated = $request->validated();

        $updatableMedicalData = MedicalData::find($validated['medical_data_id']);
        $updatableMedicalData->update([
            'type' => $validated['type'],
            'description' => $validated['description'],
            'participant_id' => $validated['participant_id'],
        ]);

        return "Medical Data Updated";
    }

    /*
     * This function will delete a medical data
     */

    public function delete(Request $request) : string
    {
        $deletableMedicalData = $request->get('id');
        MedicalData::destroy($deletableMedicalData);
        return "Medical Data Deleted";
    }
}
