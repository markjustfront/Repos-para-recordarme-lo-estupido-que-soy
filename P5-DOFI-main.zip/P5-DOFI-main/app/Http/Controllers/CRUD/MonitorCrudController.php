<?php

namespace App\Http\Controllers\CRUD;

use App\Http\Controllers\Controller;
use App\Http\Requests\MonitorUpdateRequest;
use App\Http\Requests\MonitorCreateRequest;
use App\Models\Monitor;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Tutor;


class MonitorCrudController extends Controller
{

    public function create(MonitorCreateRequest $request) :RedirectResponse {
        $validated = $request->validated();

        Monitor::create([
            "dni" => $validated["dni"],
            "name" => $validated["name"],
            "surnames" => $validated["surnames"],
            "birthday" => $validated["birthday"],
            "direction" => $validated["direction"],
            "entry_year" => $validated["entry_year"],
            "active" => $validated["active"],
            "last_activity" => $validated["last_activity"] ?? null,
            "study_level" => $validated["study_level"] ?? null,
            "monitor_permit" => $validated["monitor_permit"],
            "email" => $validated["email"],
            "phonenumber" => $validated["phonenumber"],
            "role" => $validated["role"],
            "contract_start" => $validated["contract_start"],
            "contract_end" => $validated["contract_end"],
            "tutor_id" => $validated["tutor_id"] ?? null, // Optional tutor_id
        ]);

        return redirect()->route('monitors.show')->with('success', 'Monitor afegit correctament!');
    }

    public function index()
    {
        $monitors = Monitor::all();

        $change = false;
        $endDate = Carbon::parse(now());
        foreach ($monitors as $monitor) {
            if (!$monitor->active) {
                $startDate = Carbon::parse($monitor->last_activity);
                $diff = $startDate->diffInYears($endDate);
                if ($diff >= 2) {
                    $monitor->delete();
                    $change = true;
                }
            }
        }

        if ($change) {
            $monitors = Monitor::all();
        }

        return $monitors;
    }

    public function read($id) :Collection
    {
        return Monitor::find($id);
    }

    public function update(MonitorUpdateRequest $request): string
    {
        $validated = $request->validated();

        $updatableMonitor = Monitor::findOrFail($validated["monitor_id"]);

        if (!$validated["active"] && $updatableMonitor->active) {
            $validated["last_activity"] = date("Y-m-d H:i:s", time());
        } else if ($validated["active"] && !$updatableMonitor->active) {
            $validated["last_activity"] = null;
        }

        $updatableMonitor->update([
            "dni" => $validated["dni"],
            "name" => $validated["name"],
            "surnames" => $validated["surnames"],
            "birthday" => $validated["birthday"],
            "direction" => $validated["direction"],
            "entry_year" => $validated["entry_year"],
            "active" => $validated["active"],
            "last_activity" => $validated["last_activity"] ?? null,
            "study_level" => $validated["study_level"] ?? null,
            "monitor_permit" => $validated["monitor_permit"],
            "email" => $validated["email"],
            "phonenumber" => $validated["phonenumber"],
            "role" => $validated["role"],
            "contract_start" => $validated["contract_start"],
            "contract_end" => $validated["contract_end"],
            "tutor_id" => $validated["tutor_id"] ?? null,
        ]);

        return "Monitor updated";
    }

    public function delete(Request $request) {
        $deletableMonitor = $request->get('id');
        Monitor::destroy($deletableMonitor);
        return "Monitor deleted";
    }

    // Function to delete
    public function deleteAllCheckbox() :string {
        $deletableMonitors = Monitor::whereIn('id', request('ids'));
        $deletableMonitors->delete();
        return "Monitors deleted";
    }
}
