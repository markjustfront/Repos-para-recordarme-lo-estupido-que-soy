<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Tutor;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Models\Participant;

class ParticipantController extends Controller

{
    public function index(): \Inertia\Response
    {
        return Inertia::render('Participants/Index');
    }

    public function createForm() : \Inertia\Response
    {
        return Inertia::render('Participants/Create');
    }

    public function show($id): \Inertia\Response
    {
        $participant = Participant::find($id);
        return Inertia::render('Participants/Show', [
            'participant' => $participant,
        ]);
    }
}




