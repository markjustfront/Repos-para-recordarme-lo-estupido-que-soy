<?php

namespace App\Http\Controllers;

use App\Http\Controllers\CRUD\ActivityCrudController;
use App\Models\Activity;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ActivityController extends Controller
{
    public function create()
    {
        return Inertia::render('Activities/Create');
    }

    public function index()
    {
        return Inertia::render('Activities/Index');
    }

    public function show($id)
    {
        $activity = ActivityCrudController::read($id);
        $startTime = \DateTime::createFromFormat('Y-m-d H:i:s', $activity->start_time);
        $endTime = \DateTime::createFromFormat('Y-m-d H:i:s', $activity->end_time);
        $activity->start_time = date_format($startTime, 'd-m-Y');
        $activity->end_time = date_format($endTime, 'd-m-Y');
        return Inertia::render('Activities/Show', [
            'activity' => $activity,
        ]);
    }
}
