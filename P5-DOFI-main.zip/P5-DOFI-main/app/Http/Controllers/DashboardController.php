<?php

namespace App\Http\Controllers;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Monitor;

class DashboardController extends Controller
{
    public function index() : Response
    {
        $isAuthenticated = auth()->check();
        return Inertia::render('Dashboard', [
            'isAuthenticated' => $isAuthenticated,
        ]);
    }
}
