<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Inertia\Inertia;
use Inertia\Response;
use App\Models\Tutor;

class MonitorController extends Controller
{
    /**
     * Render the MonitorForm view
     */
    public function show()
    {
        // Simply render the MonitorForm view without passing tutors
        return Inertia::render('Monitors/Create');
    }

    public function index() :Response{
        return Inertia::render("Monitors/Index", [
            'translations' => [
                'monitors_list' => __('Monitors List'),
            ],
        ]);
    }

}
