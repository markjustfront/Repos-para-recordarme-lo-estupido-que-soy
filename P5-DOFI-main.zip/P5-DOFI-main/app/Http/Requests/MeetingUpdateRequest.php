<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Meeting;

class MeetingUpdateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request..
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'meeting_id' => ['required', 'exists:App\Models\Meeting, id'],
            'type' => ['required|string|max:255'],
            'route' => ['required|string|max:255'],
            'assistants' => ['required|array'],
            'observations' => ['required|string|max:255'],
            'date' => ['required|datetime'],
            'place' => ['required|string|max:150'],
        ];
    }
}
