<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class MonitorCreateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'dni' => 'required|unique:App\Models\Monitor,dni|size:9',
            'name' => 'required|string|min:2|max:30',
            'surnames' => 'required|string|min:2|max:80',
            'birthday' => 'required|date|before:today',
            'direction' => 'required|string|min:2|max:60',
            'entry_year' => 'required|numeric|min:1900|max:2100',
            'active' => 'required|boolean',
            'last_activity' => 'nullable|date',
            'study_level' => 'nullable|numeric|min:0|max:4',
            'monitor_permit' => 'required|boolean',
            'email' => 'required|email:rfc',
            'phonenumber' => 'required|numeric|digits:9',
            'role' => 'required|string|in:monitor,coordinator,responsable,volunteer',
            'contract_start' => 'required|date',
            'contract_end' => 'required|date|after:contract_start',
            'tutor_id' => 'nullable|exists:App\Models\Tutor,id',
        ];
    }
}
