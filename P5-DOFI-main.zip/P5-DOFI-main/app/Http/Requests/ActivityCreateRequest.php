<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ActivityCreateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {

        return [
            'name' => 'required|min:2|max:30',
            'description' => 'required|min:20|max:1500',
            'start_time' => 'required|date',
            'end_time' => 'required|date|after:start_time',
            'place' => 'required|min:2|max:80',
            'member_price' => 'required|numeric|min:0',
            'nonmember_price' => 'required|numeric|min:0',
            'monitor_salary' => 'required|numeric|min:0',
            'participants_id' => 'required|json',
            'monitors_info' => 'required|json',
            'collaborations' => 'json',
            'image' => 'required|image|mimes:png',
        ];
    }
}
