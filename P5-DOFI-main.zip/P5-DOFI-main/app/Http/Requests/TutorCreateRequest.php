<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class TutorCreateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|min:2|max:20',
            'surname' => 'required|min:2|max:80',
            'email' => 'required|email:rfc',
            'phone' => 'required|digits:9',
            'for' => 'required|in:monitor,participant'
        ];
    }
}
