<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ParticipantUpdateRequest extends FormRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'participant_id' => 'required|integer|exists:App\Models\Participant,id',
            'dni' => 'required|min:9|max:9|unique:participants,dni,' . $this->input('participant_id'),
            'name' => 'required|min:2|max:30',
            'surnames' => 'required|min:2|max:80',
            'birthday' => 'required|date|before:today',
            'direction' => 'required|min:2|max:80',
            'entry_year' => 'required|numeric|min:1900',
            'member' => 'required',
            'cash' => 'required',
            'educational_sheet' => 'required|min:2|max:1000',
            'tutor_id' => 'required|numeric|min:1|exists:App\Models\Tutor,id',
            'active' => 'required|boolean',
        ];
    }
}
