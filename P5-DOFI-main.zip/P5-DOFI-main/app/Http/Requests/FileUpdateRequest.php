<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FileUpdateRequest extends FormRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'file_id' => 'required|exists:App\Models\File,id',
            'for' => 'required|in:monitor,participant,board',
            'type' => 'required|min:2|max:99',
            'route' => 'required',
            'participant_id' => 'exists:App\Models\Participant,id',
            'monitor_id' => 'exists:App\Models\Monitor,id',
        ];
    }
}
