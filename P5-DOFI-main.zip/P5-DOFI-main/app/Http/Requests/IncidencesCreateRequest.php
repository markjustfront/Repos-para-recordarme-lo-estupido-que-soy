<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class IncidencesCreateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule','array<mixed>','string>
     */
    public function rules(): array
    {
        return [
            'type' => ['required','string','in:Crisis epilèptiques,Alteració conductual,Altres'],
            'description' => ['required','string','max:255', 'min:3'],
            'actuation' => ['required','string','max:255', 'min:3'],
            'monitor_id' => ['required','integer', 'exists:monitors,id'],
            'participant_id' => ['required','integer', 'exists:participants,id'],
            'date' => ['required','date'],
            'time' => ['required','string'],
        ];
    }
}
