<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BankDataCreateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'for' => 'required|in:monitor,participant,board',
            'iban' => 'required|min:24|max:24',
            'name' => 'required',
            'nass' => 'min:12|max:12',
            'participant_id' => 'exists:App\Models\Participant,id',
            'monitor_id' => 'exists:App\Models\Monitor,id',
        ];
    }
}
