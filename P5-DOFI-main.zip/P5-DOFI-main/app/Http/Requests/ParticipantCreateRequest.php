<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ParticipantCreateRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'dni' => 'required|unique:App\Models\Participant,dni|min:9|max:9',
            'name' => 'required|min:2|max:30',
            'surnames' => 'required|min:2|max:80',
            'birthday' => 'required|date|before:today',
            'direction' => 'required|min:2|max:80',
            'entry_year' => 'required|integer|min:1900|max:2125',
            'member' => 'required|boolean',
            'cash' => 'required|boolean',
            'educational_sheet' => 'required|min:2|max:1000',
            'tutor_id' => 'required|numeric|min:1|exists:App\Models\Tutor,id',
            'relationship' => 'required|min:2|max:80',
            'active' => 'boolean',
        ];
    }
}
