<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Incidence extends Model
{
    /** @use HasFactory<\Database\Factories\IncidenceFactory> */
    use HasFactory;

    protected $fillable = [
        'type',
        'description',
        'actuation',
        'monitor_id',
        'participant_id',
        'date',
        'time',
    ];

    public function monitors() : BelongsTo
    {
        return $this->belongsTo(Monitor::class, 'id', 'monitor_id');
    }

    public function participants() : BelongsTo
    {
        return $this->belongsTo(Participant::class, 'id', 'participant_id');
    }

}
