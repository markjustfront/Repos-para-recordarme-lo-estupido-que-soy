<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Participant extends Model
{
    /** @use HasFactory<\Database\Factories\ParticipantFactory> */

    use HasFactory;
    protected $fillable = [
        'name',
        'surnames',
        'dni',
        'birthday',
        'direction',
        'entry_year',
        'member',
        'active',
        'cash',
        'relationship',
        'tutor_id',
        'educational_sheet'
    ];

    public function tutors(): BelongsTo
    {
        return $this->belongsTo(Tutor::class);
    }

    public function defaulters(): HasOne
    {
        return $this->hasOne(Defaulter::class);
    }

    public function incidences(): HasMany
    {
        return $this->hasMany(Incidence::class);
    }
}
