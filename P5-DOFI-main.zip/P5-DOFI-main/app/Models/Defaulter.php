<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Defaulter extends Model
{
    /** @use HasFactory<\Database\Factories\DefaulterFactory> */
    use HasFactory;

    protected $fillable = [
        'participant_id',
    ];

    public function participants(): BelongsTo
    {
        return $this->belongsTo(Participant::class);
    }
}
