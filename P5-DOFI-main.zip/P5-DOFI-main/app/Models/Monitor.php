<?php
// app/Models/Monitor.php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Facades\Storage;

class Monitor extends Model
{
    use HasFactory;

    protected $fillable = [
        'dni',
        'name',
        'surnames',
        'birthday',
        'direction',
        'entry_year',
        'active',
        'last_activity',
        'study_level',
        'monitor_permit',
        'email',
        'phonenumber',
        'role',
        'contract_start',
        'contract_end',
        'tutor_id',
    ];

    protected $casts = [
        'birthday' => 'datetime',
        'last_activity' => 'datetime',
        'active' => 'boolean',
        'monitor_permit' => 'boolean',
        'contract_start' => 'datetime',
        'contract_end' => 'datetime',
        'role' => 'string',
    ];

    public function tutors() : HasOne
    {
        return $this->hasOne(Tutor::class);
    }

    public function incidences() : HasMany
    {
        return $this->hasMany(Incidence::class);
    }
}
