<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MedicalData extends Model
{
    /** @use HasFactory<\Database\Factories\MedicalDataFactory> */
    use HasFactory;
    protected $casts = [
        'description' => 'encrypted',
    ];
}
