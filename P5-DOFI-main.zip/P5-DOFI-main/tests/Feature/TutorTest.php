<?php

use App\Models\Tutor;
use App\Models\User;

test('tutor form page is displayed', function () {
  $user = User::factory()->create();
  $user->role = 'admin';
  $user->save();

  $response = $this
    ->actingAs($user)
    ->get('/tutors');

  $response->assertStatus(200);
});

test('Add tutor', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $response = $this->actingAs($user)->post('/tutor/add', [
        'name' => 'Tutor 1',
        'surname' => 'Tutor 1',
        'email' => 'tutor@tutor.com',
        'phone' => 123368779,
        'for' => 'monitor',
    ]);


    $tutor = Tutor::all()->first();
    $this->assertSame('123368779', $tutor->phone);
    $this->assertSame('Tutor 1', $tutor->name);
});

test('Edit Tutor', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $tutorId = Tutor::factory()->create()->id;


    $response = $this->actingAs($user)->patch('/tutor/update', [
        'tutor_id' => $tutorId,
        'name' => 'Tutor 2',
        'surname' => 'Tutor 2',
        'email' => 'tutor2@tutor.com',
        'phone' => 987654321,
        'for' => 'monitor',

    ]);

    $newTutor = Tutor::find($tutorId);

    $this->assertSame('Tutor 2', $newTutor->name);
});

test('Delete Tutor', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $tutorId = Tutor::factory()->create()->id;
    $response = $this->actingAs($user)->delete('/tutor/delete', [
        'id' => $tutorId,
    ]);

    $tutors = Tutor::all()->first();
    $this->assertNull($tutors);
});