<?php

test('la página principal carga correctamente', function () {
    $response = $this->get('/dashboard');

    $response->assertStatus(200);
});