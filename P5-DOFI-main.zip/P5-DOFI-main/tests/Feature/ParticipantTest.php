<?php
use App\Models\Participant;
use App\Models\User;
use App\Models\Tutor;

test('participant page is dispalyed', function (){
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();
    $response = $this
        ->actingAs($user)
        ->get('/participants');
    $response->assertStatus(200);
});

test('Add participant', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $tutorID = Tutor::factory()->create()->id;

    $response = $this->actingAs($user)->post('/participant/add',[
        'dni' => '12345678B',
        'name' => 'Pop',
        'surnames' => 'Popy',
        'birthday' => '1985-06-13',
        'direction' => 'Carrer Pop',
        'entry_year' => 2000,
        'member' => true,
        'cash' => true,
        'educational_sheet' => 'Test de prova goty',
        'tutor_id' => $tutorID,
        'relationship' => 'Pare',
        'active' => true,
    ]);
    
    $participant = Participant::all()->first();
    $this->assertSame('Pop', $participant->name);
});

test('Edit participant', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $participantId = Participant::factory()->create()->id;
    $tutorID = Tutor::factory()->create()->id;

    $response = $this->actingAs($user)->patch('/participant/update', [
        'participant_id' => $participantId,
        'dni' => '12345678B',
        'name' => 'Popa',
        'surnames' => 'Popy',
        'birthday' => '1985-06-13',
        'direction' => 'Carrer Pop',
        'entry_year' => 2000,
        'member' => true,
        'cash' => true,
        'educational_sheet' => 'Test de prova goty',
        'tutor_id' => $tutorID,
        'relationship' => 'Pare',
        'active' => true,
    ]);
    
    $participant = Participant::find($participantId);
    $this->assertSame('Popa', $participant->name);
});

test('Delete participant', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $participantId = Participant::factory()->create()->id;

    $response = $this->actingAs($user)->delete('/participant/delete', [
        'id' => $participantId,
    ]);
    
    $participant = Participant::all()->first();
    $this->assertNull($participant);
});