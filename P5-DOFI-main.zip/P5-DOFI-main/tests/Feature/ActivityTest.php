<?php

use App\Models\Activity;
use App\Models\User;

test('activity form is shown', function () {
  $user = User::factory()->create();
  $user->role = 'admin';
  $user->save();

  $response = $this
    ->actingAs($user)
    ->get('/activities');

  $response->assertStatus(200);
});

test('Add activity', function () {
  $user = User::factory()->create();
  $user->role = 'admin';
  $user->save();

  $response = $this->actingAs($user)->post('/activity/add', [
    'name' => 'Paco',
    'start_time' => '17:14',
    'end_time' => '18:14',
    'place' => 'Figueres',
    'member_price' => '15,70',
    'nonmember_price' => '20,70',
    'monitor_salary' => '20',
    'participants_id' => '1',
    'monitors_info' => '',
    'collaborations' => '',
  ]);
});
