<?php
use App\Models\Defaulter;
use App\Models\Participant;
use App\Models\User;

test('defaulters page is ok', function() {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $response = $this
        ->actingAs($user)
        ->get('/defaulters');

    $response->assertStatus(200);
});

test('Create defaulter', function() {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $participantID = Participant::factory()->create()->id;

    $response = $this->actingAs($user)->post('/defaulter/add', [
        'participant_id' => $participantID,
    ]);

    $defaulter = Defaulter::all()->first();
    $this->assertSame($participantID, $defaulter->participant_id);
});

test('Delete defaulter', function() {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $defaulterID = Defaulter::factory()->create()->id;

    $response = $this->actingAs($user)->delete('/defaulter/delete', [
        'id' => $defaulterID,
    ]);
    $defaulter = Defaulter::all()->first();
    $this->assertNull($defaulter);
});
