<?php

use App\Models\Incidence;
use App\Models\Monitor;
use App\Models\Participant;
use App\Models\User;

test('Incidence route loads?', function () {

    $user = User::factory()->create();

    $response = $this
        ->actingAs($user)
        ->get('/incidence/add');

    $response->assertStatus(200);
});

test('Add Incidence', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $monitorId = Monitor::factory()->create()->id;
    $participantId = Participant::factory()->create()->id;

    $response = $this->actingAs($user)->post('/incidence/add', [
        'type' => 'Crisis epilèptiques',
        'description' => 'A description',
        'actuation' => 'Aaa',
        'monitor_id' => $monitorId,
        'participant_id' => $participantId,
        'date' => '2025-10-10',
        'time' => '17:40',
    ]);
    // dd($response);
    $incidence = Incidence::all()->first();
    $this->assertSame('A description', $incidence->description);

});

test('Delete Incidence', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $incidence = Incidence::factory()->create()->id;
    $response = $this->actingAs($user)->delete('/incidence/delete', [
        'id' => $incidence,
    ]);
    $incidence = Incidence::all()->first();
    $this->assertNull($incidence);
});
