<?php

use App\Models\Monitor;
use App\Models\User;

test('monitor form page is displayed', function () {
  $user = User::factory()->create();
  $user->role = 'admin';
  $user->save();

  $response = $this
    ->actingAs($user)
    ->get('/monitors');

  $response->assertStatus(200);
});

test('Add monitor', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $response = $this->actingAs($user)->post('/monitor/add', [
        'dni' => '41528736Q',
        'name' => 'Monitor 1',
        'surnames' => 'Monitor 1',
        'birthday' => '1990-01-01',
        'direction' => 'Direction',
        'entry_year' => 2004,
        'active' => true,
        'study_level' => 2,
        'monitor_permit' => true,
        'email' => 'monitor@monitor.com',
        'phonenumber' => 987654321,
        'role' => 'responsable',
        'contract_start' => '2000-01-01',
        'contract_end' => '2000-12-31',
    ]);

    $monitor = Monitor::all()->first();
    $this->assertSame('41528736Q', $monitor->dni);
    $this->assertSame('Monitor 1', $monitor->name);
});

test('Edit Monitor', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $monitorId = Monitor::factory()->create()->id;


    $response = $this->actingAs($user)->patch('/monitor/update', [
        'monitor_id' => $monitorId,
        'dni' => '45128736Q',
        'name' => 'Monitor 2',
        'surnames' => 'Monitor 2',
        'birthday' => '1990-01-01',
        'direction' => 'Direction',
        'entry_year' => 2004,
        'active' => true,
        'study_level' => 2,
        'monitor_permit' => true,
        'email' => 'monitor2@monitor.com',
        'phonenumber' => 987654321,
        'role' => 'responsable',
        'contract_start' => '2000-01-01',
        'contract_end' => '2000-12-31',

    ]);

    $newMonitor = Monitor::find($monitorId);

    $this->assertSame('Monitor 2', $newMonitor->name);
});

test('Delete Monitor', function () {
    $user = User::factory()->create();
    $user->role = 'admin';
    $user->save();

    $monitorId = Monitor::factory()->create()->id;
    $response = $this->actingAs($user)->delete('/monitor/delete', [
        'id' => $monitorId,
    ]);

    $monitors = Monitor::all()->first();
    $this->assertNull($monitors);
});
